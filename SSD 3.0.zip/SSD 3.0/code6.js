gdjs.lvl4Code = {};
gdjs.lvl4Code.GDSheikhSpeedObjects1_1final = [];

gdjs.lvl4Code.GDSheikhSpeedObjects1= [];
gdjs.lvl4Code.GDSheikhSpeedObjects2= [];
gdjs.lvl4Code.GDSheikhSpeedObjects3= [];
gdjs.lvl4Code.GDCoinObjects1= [];
gdjs.lvl4Code.GDCoinObjects2= [];
gdjs.lvl4Code.GDCoinObjects3= [];
gdjs.lvl4Code.GDScoreObjects1= [];
gdjs.lvl4Code.GDScoreObjects2= [];
gdjs.lvl4Code.GDScoreObjects3= [];
gdjs.lvl4Code.GDHaramPointObjects1= [];
gdjs.lvl4Code.GDHaramPointObjects2= [];
gdjs.lvl4Code.GDHaramPointObjects3= [];
gdjs.lvl4Code.GDExitButtonObjects1= [];
gdjs.lvl4Code.GDExitButtonObjects2= [];
gdjs.lvl4Code.GDExitButtonObjects3= [];
gdjs.lvl4Code.GDGroundObjects1= [];
gdjs.lvl4Code.GDGroundObjects2= [];
gdjs.lvl4Code.GDGroundObjects3= [];
gdjs.lvl4Code.GDladderObjects1= [];
gdjs.lvl4Code.GDladderObjects2= [];
gdjs.lvl4Code.GDladderObjects3= [];
gdjs.lvl4Code.GDdirtLeftObjects1= [];
gdjs.lvl4Code.GDdirtLeftObjects2= [];
gdjs.lvl4Code.GDdirtLeftObjects3= [];
gdjs.lvl4Code.GDDoor2Objects1= [];
gdjs.lvl4Code.GDDoor2Objects2= [];
gdjs.lvl4Code.GDDoor2Objects3= [];
gdjs.lvl4Code.GDtopOfdoorObjects1= [];
gdjs.lvl4Code.GDtopOfdoorObjects2= [];
gdjs.lvl4Code.GDtopOfdoorObjects3= [];
gdjs.lvl4Code.GDbridgelogsObjects1= [];
gdjs.lvl4Code.GDbridgelogsObjects2= [];
gdjs.lvl4Code.GDbridgelogsObjects3= [];
gdjs.lvl4Code.GDcrookObjects1= [];
gdjs.lvl4Code.GDcrookObjects2= [];
gdjs.lvl4Code.GDcrookObjects3= [];
gdjs.lvl4Code.GDenemyrightObjects1= [];
gdjs.lvl4Code.GDenemyrightObjects2= [];
gdjs.lvl4Code.GDenemyrightObjects3= [];
gdjs.lvl4Code.GDenemyLefyObjects1= [];
gdjs.lvl4Code.GDenemyLefyObjects2= [];
gdjs.lvl4Code.GDenemyLefyObjects3= [];
gdjs.lvl4Code.GDNewObject2Objects1= [];
gdjs.lvl4Code.GDNewObject2Objects2= [];
gdjs.lvl4Code.GDNewObject2Objects3= [];
gdjs.lvl4Code.GDbackButtonObjects1= [];
gdjs.lvl4Code.GDbackButtonObjects2= [];
gdjs.lvl4Code.GDbackButtonObjects3= [];
gdjs.lvl4Code.GDcoinGoldObjects1= [];
gdjs.lvl4Code.GDcoinGoldObjects2= [];
gdjs.lvl4Code.GDcoinGoldObjects3= [];
gdjs.lvl4Code.GDbackgroundObjects1= [];
gdjs.lvl4Code.GDbackgroundObjects2= [];
gdjs.lvl4Code.GDbackgroundObjects3= [];
gdjs.lvl4Code.GDgameoverObjects1= [];
gdjs.lvl4Code.GDgameoverObjects2= [];
gdjs.lvl4Code.GDgameoverObjects3= [];
gdjs.lvl4Code.GDendlessScoreObjects1= [];
gdjs.lvl4Code.GDendlessScoreObjects2= [];
gdjs.lvl4Code.GDendlessScoreObjects3= [];
gdjs.lvl4Code.GDgamestartObjects1= [];
gdjs.lvl4Code.GDgamestartObjects2= [];
gdjs.lvl4Code.GDgamestartObjects3= [];
gdjs.lvl4Code.GDRestartObjects1= [];
gdjs.lvl4Code.GDRestartObjects2= [];
gdjs.lvl4Code.GDRestartObjects3= [];
gdjs.lvl4Code.GDbridgeObjects1= [];
gdjs.lvl4Code.GDbridgeObjects2= [];
gdjs.lvl4Code.GDbridgeObjects3= [];
gdjs.lvl4Code.GDCandyLandLeftObjects1= [];
gdjs.lvl4Code.GDCandyLandLeftObjects2= [];
gdjs.lvl4Code.GDCandyLandLeftObjects3= [];
gdjs.lvl4Code.GDCandyMidObjects1= [];
gdjs.lvl4Code.GDCandyMidObjects2= [];
gdjs.lvl4Code.GDCandyMidObjects3= [];
gdjs.lvl4Code.GDCandyRightObjects1= [];
gdjs.lvl4Code.GDCandyRightObjects2= [];
gdjs.lvl4Code.GDCandyRightObjects3= [];
gdjs.lvl4Code.GDcandyCoinObjects1= [];
gdjs.lvl4Code.GDcandyCoinObjects2= [];
gdjs.lvl4Code.GDcandyCoinObjects3= [];
gdjs.lvl4Code.GDcandycane1Objects1= [];
gdjs.lvl4Code.GDcandycane1Objects2= [];
gdjs.lvl4Code.GDcandycane1Objects3= [];
gdjs.lvl4Code.GDcandycane2Objects1= [];
gdjs.lvl4Code.GDcandycane2Objects2= [];
gdjs.lvl4Code.GDcandycane2Objects3= [];
gdjs.lvl4Code.GDcandybgObjects1= [];
gdjs.lvl4Code.GDcandybgObjects2= [];
gdjs.lvl4Code.GDcandybgObjects3= [];
gdjs.lvl4Code.GDangledleftcnadyObjects1= [];
gdjs.lvl4Code.GDangledleftcnadyObjects2= [];
gdjs.lvl4Code.GDangledleftcnadyObjects3= [];
gdjs.lvl4Code.GDMIDDLECLEARObjects1= [];
gdjs.lvl4Code.GDMIDDLECLEARObjects2= [];
gdjs.lvl4Code.GDMIDDLECLEARObjects3= [];
gdjs.lvl4Code.GDANGLEDLEFTSQUAREObjects1= [];
gdjs.lvl4Code.GDANGLEDLEFTSQUAREObjects2= [];
gdjs.lvl4Code.GDANGLEDLEFTSQUAREObjects3= [];
gdjs.lvl4Code.GDCANDYMID_95NOT_95TILEDObjects1= [];
gdjs.lvl4Code.GDCANDYMID_95NOT_95TILEDObjects2= [];
gdjs.lvl4Code.GDCANDYMID_95NOT_95TILEDObjects3= [];
gdjs.lvl4Code.GDangledrightcandytriangleObjects1= [];
gdjs.lvl4Code.GDangledrightcandytriangleObjects2= [];
gdjs.lvl4Code.GDangledrightcandytriangleObjects3= [];
gdjs.lvl4Code.GDNewObjectObjects1= [];
gdjs.lvl4Code.GDNewObjectObjects2= [];
gdjs.lvl4Code.GDNewObjectObjects3= [];
gdjs.lvl4Code.GDlockObjects1= [];
gdjs.lvl4Code.GDlockObjects2= [];
gdjs.lvl4Code.GDlockObjects3= [];
gdjs.lvl4Code.GDkeyObjects1= [];
gdjs.lvl4Code.GDkeyObjects2= [];
gdjs.lvl4Code.GDkeyObjects3= [];
gdjs.lvl4Code.GDdownArrowObjects1= [];
gdjs.lvl4Code.GDdownArrowObjects2= [];
gdjs.lvl4Code.GDdownArrowObjects3= [];
gdjs.lvl4Code.GDarrowUpObjects1= [];
gdjs.lvl4Code.GDarrowUpObjects2= [];
gdjs.lvl4Code.GDarrowUpObjects3= [];
gdjs.lvl4Code.GDplatform_95candyObjects1= [];
gdjs.lvl4Code.GDplatform_95candyObjects2= [];
gdjs.lvl4Code.GDplatform_95candyObjects3= [];
gdjs.lvl4Code.GDcount_95of_95keysObjects1= [];
gdjs.lvl4Code.GDcount_95of_95keysObjects2= [];
gdjs.lvl4Code.GDcount_95of_95keysObjects3= [];
gdjs.lvl4Code.GDkey_95hudObjects1= [];
gdjs.lvl4Code.GDkey_95hudObjects2= [];
gdjs.lvl4Code.GDkey_95hudObjects3= [];
gdjs.lvl4Code.GDsecretdoor1Objects1= [];
gdjs.lvl4Code.GDsecretdoor1Objects2= [];
gdjs.lvl4Code.GDsecretdoor1Objects3= [];
gdjs.lvl4Code.GDsecretObjects1= [];
gdjs.lvl4Code.GDsecretObjects2= [];
gdjs.lvl4Code.GDsecretObjects3= [];
gdjs.lvl4Code.GDopendoor1Objects1= [];
gdjs.lvl4Code.GDopendoor1Objects2= [];
gdjs.lvl4Code.GDopendoor1Objects3= [];
gdjs.lvl4Code.GDopendoor2Objects1= [];
gdjs.lvl4Code.GDopendoor2Objects2= [];
gdjs.lvl4Code.GDopendoor2Objects3= [];
gdjs.lvl4Code.GDNewObject3Objects1= [];
gdjs.lvl4Code.GDNewObject3Objects2= [];
gdjs.lvl4Code.GDNewObject3Objects3= [];
gdjs.lvl4Code.GDNewObject4Objects1= [];
gdjs.lvl4Code.GDNewObject4Objects2= [];
gdjs.lvl4Code.GDNewObject4Objects3= [];
gdjs.lvl4Code.GDCheckpointObjects1= [];
gdjs.lvl4Code.GDCheckpointObjects2= [];
gdjs.lvl4Code.GDCheckpointObjects3= [];

gdjs.lvl4Code.conditionTrue_0 = {val:false};
gdjs.lvl4Code.condition0IsTrue_0 = {val:false};
gdjs.lvl4Code.condition1IsTrue_0 = {val:false};
gdjs.lvl4Code.condition2IsTrue_0 = {val:false};
gdjs.lvl4Code.conditionTrue_1 = {val:false};
gdjs.lvl4Code.condition0IsTrue_1 = {val:false};
gdjs.lvl4Code.condition1IsTrue_1 = {val:false};
gdjs.lvl4Code.condition2IsTrue_1 = {val:false};


gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects1});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDHaramPointObjects1Objects = Hashtable.newFrom({"HaramPoint": gdjs.lvl4Code.GDHaramPointObjects1});gdjs.lvl4Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HaramPoint"), gdjs.lvl4Code.GDHaramPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDHaramPointObjects1Objects, false, runtimeScene, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDSheikhSpeedObjects1 */
{gdjs.evtTools.sound.playMusic(runtimeScene, "life lost sound.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl4", false);
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects1});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.lvl4Code.GDDoor2Objects1});gdjs.lvl4Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.lvl4Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.lvl4Code.GDExitButtonObjects1});gdjs.lvl4Code.eventsList2 = function(runtimeScene) {

{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.lvl4Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.lvl4Code.GDExitButtonObjects1);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDExitButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.lvl4Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.lvl4Code.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.lvl4Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.lvl4Code.GDSheikhSpeedObjects1[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.lvl4Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.lvl4Code.GDSheikhSpeedObjects1[0].getPointY("")), 0.1), "", 0);
}}

}


};gdjs.lvl4Code.eventsList5 = function(runtimeScene) {

{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].flipX(false);
}
}}

}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects2);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.lvl4Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( !(gdjs.lvl4Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.lvl4Code.condition0IsTrue_0.val = true;
        gdjs.lvl4Code.GDSheikhSpeedObjects2[k] = gdjs.lvl4Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDSheikhSpeedObjects2.length = k;}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);
{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects2});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.lvl4Code.GDCoinObjects2});gdjs.lvl4Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.lvl4Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects2);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects2Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDCoinObjects2Objects, false, runtimeScene, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDCoinObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.lvl4Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.lvl4Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDScoreObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects1});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDcandyCoinObjects1Objects = Hashtable.newFrom({"candyCoin": gdjs.lvl4Code.GDcandyCoinObjects1});gdjs.lvl4Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);
gdjs.copyArray(runtimeScene.getObjects("candyCoin"), gdjs.lvl4Code.GDcandyCoinObjects1);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDcandyCoinObjects1Objects, false, runtimeScene, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDcandyCoinObjects1 */
{for(var i = 0, len = gdjs.lvl4Code.GDcandyCoinObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDcandyCoinObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


};gdjs.lvl4Code.eventsList8 = function(runtimeScene) {

{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("arrowUp"), gdjs.lvl4Code.GDarrowUpObjects2);
gdjs.copyArray(runtimeScene.getObjects("downArrow"), gdjs.lvl4Code.GDdownArrowObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDdownArrowObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDdownArrowObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.lvl4Code.GDarrowUpObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDarrowUpObjects2[i].hide();
}
}}

}


{


{
}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects2});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.lvl4Code.GDcrookObjects2});gdjs.lvl4Code.eventsList9 = function(runtimeScene) {

{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enemyLefy"), gdjs.lvl4Code.GDenemyLefyObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.lvl4Code.GDenemyrightObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDenemyrightObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDenemyrightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.lvl4Code.GDenemyLefyObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDenemyLefyObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.lvl4Code.GDcrookObjects2);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.lvl4Code.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDcrookObjects2[i].getVariableString(gdjs.lvl4Code.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Left" ) {
        gdjs.lvl4Code.condition0IsTrue_0.val = true;
        gdjs.lvl4Code.GDcrookObjects2[k] = gdjs.lvl4Code.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDcrookObjects2.length = k;}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDcrookObjects2[i].addForce(-(40), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.lvl4Code.GDcrookObjects2);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.lvl4Code.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDcrookObjects2[i].getVariableString(gdjs.lvl4Code.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Right" ) {
        gdjs.lvl4Code.condition0IsTrue_0.val = true;
        gdjs.lvl4Code.GDcrookObjects2[k] = gdjs.lvl4Code.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDcrookObjects2.length = k;}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}}

}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.lvl4Code.GDcrookObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDcrookObjects2[i].flipX(true);
}
}{/* Unknown object - skipped. */}}

}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.lvl4Code.GDcrookObjects2);
{for(var i = 0, len = gdjs.lvl4Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDcrookObjects2[i].flipX(false);
}
}{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.lvl4Code.GDcrookObjects2);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
gdjs.lvl4Code.condition1IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects2Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDcrookObjects2Objects, false, runtimeScene, true);
}if ( gdjs.lvl4Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.lvl4Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.lvl4Code.condition1IsTrue_0.val = true;
        gdjs.lvl4Code.GDSheikhSpeedObjects2[k] = gdjs.lvl4Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.lvl4Code.condition1IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl4", false);
}}

}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDbridgeObjects1Objects = Hashtable.newFrom({"bridge": gdjs.lvl4Code.GDbridgeObjects1});gdjs.lvl4Code.eventsList10 = function(runtimeScene) {

{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "bridgecount");
}}

}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 4, "bridgecount");
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.lvl4Code.GDbridgeObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDbridgeObjects1Objects, 4256, 944, "");
}{for(var i = 0, len = gdjs.lvl4Code.GDbridgeObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDbridgeObjects1[i].addForce(0, -(100), 1);
}
}{for(var i = 0, len = gdjs.lvl4Code.GDbridgeObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDbridgeObjects1[i].setHeight(192);
}
}{for(var i = 0, len = gdjs.lvl4Code.GDbridgeObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDbridgeObjects1[i].setWidth(352);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "bridgecount");
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects1});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDCheckpointObjects1Objects = Hashtable.newFrom({"Checkpoint": gdjs.lvl4Code.GDCheckpointObjects1});gdjs.lvl4Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.lvl4Code.GDCheckpointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDCheckpointObjects1Objects, false, runtimeScene, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl4Code.GDCheckpointObjects1 */
{runtimeScene.getVariables().get("checkpointX").setNumber((( gdjs.lvl4Code.GDCheckpointObjects1.length === 0 ) ? 0 :gdjs.lvl4Code.GDCheckpointObjects1[0].getPointX("")));
}{runtimeScene.getVariables().get("checkpointY").setNumber(0);
}}

}


};gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.lvl4Code.GDSheikhSpeedObjects1});gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.lvl4Code.GDDoor2Objects1});gdjs.lvl4Code.eventsList12 = function(runtimeScene) {

{


gdjs.lvl4Code.eventsList0(runtimeScene);
}


{


gdjs.lvl4Code.eventsList1(runtimeScene);
}


{


gdjs.lvl4Code.eventsList3(runtimeScene);
}


{


gdjs.lvl4Code.eventsList4(runtimeScene);
}


{


gdjs.lvl4Code.eventsList5(runtimeScene);
}


{


gdjs.lvl4Code.eventsList6(runtimeScene);
}


{


gdjs.lvl4Code.eventsList7(runtimeScene);
}


{


gdjs.lvl4Code.eventsList8(runtimeScene);
}


{


gdjs.lvl4Code.eventsList9(runtimeScene);
}


{


gdjs.lvl4Code.eventsList10(runtimeScene);
}


{


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("doorcount")) == 1;
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);
{for(var i = 0, len = gdjs.lvl4Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.lvl4Code.GDSheikhSpeedObjects1[i].setPosition(5632,600);
}
}}

}


{


gdjs.lvl4Code.eventsList11(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.lvl4Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects1);

gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
gdjs.lvl4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDSheikhSpeedObjects1Objects, gdjs.lvl4Code.mapOfGDgdjs_46lvl4Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}}

}


{

gdjs.lvl4Code.GDSheikhSpeedObjects1.length = 0;


gdjs.lvl4Code.condition0IsTrue_0.val = false;
{
{gdjs.lvl4Code.conditionTrue_1 = gdjs.lvl4Code.condition0IsTrue_0;
gdjs.lvl4Code.GDSheikhSpeedObjects1_1final.length = 0;gdjs.lvl4Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.lvl4Code.GDSheikhSpeedObjects2);
for(var i = 0, k = 0, l = gdjs.lvl4Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.lvl4Code.GDSheikhSpeedObjects2[i].getY() >= 1200 ) {
        gdjs.lvl4Code.condition0IsTrue_1.val = true;
        gdjs.lvl4Code.GDSheikhSpeedObjects2[k] = gdjs.lvl4Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.lvl4Code.GDSheikhSpeedObjects2.length = k;if( gdjs.lvl4Code.condition0IsTrue_1.val ) {
    gdjs.lvl4Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.lvl4Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.lvl4Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.lvl4Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.lvl4Code.GDSheikhSpeedObjects1_1final.push(gdjs.lvl4Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.lvl4Code.GDSheikhSpeedObjects1_1final, gdjs.lvl4Code.GDSheikhSpeedObjects1);
}
}
}if (gdjs.lvl4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl4", false);
}}

}


{


{
}

}


};

gdjs.lvl4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl4Code.GDSheikhSpeedObjects1.length = 0;
gdjs.lvl4Code.GDSheikhSpeedObjects2.length = 0;
gdjs.lvl4Code.GDSheikhSpeedObjects3.length = 0;
gdjs.lvl4Code.GDCoinObjects1.length = 0;
gdjs.lvl4Code.GDCoinObjects2.length = 0;
gdjs.lvl4Code.GDCoinObjects3.length = 0;
gdjs.lvl4Code.GDScoreObjects1.length = 0;
gdjs.lvl4Code.GDScoreObjects2.length = 0;
gdjs.lvl4Code.GDScoreObjects3.length = 0;
gdjs.lvl4Code.GDHaramPointObjects1.length = 0;
gdjs.lvl4Code.GDHaramPointObjects2.length = 0;
gdjs.lvl4Code.GDHaramPointObjects3.length = 0;
gdjs.lvl4Code.GDExitButtonObjects1.length = 0;
gdjs.lvl4Code.GDExitButtonObjects2.length = 0;
gdjs.lvl4Code.GDExitButtonObjects3.length = 0;
gdjs.lvl4Code.GDGroundObjects1.length = 0;
gdjs.lvl4Code.GDGroundObjects2.length = 0;
gdjs.lvl4Code.GDGroundObjects3.length = 0;
gdjs.lvl4Code.GDladderObjects1.length = 0;
gdjs.lvl4Code.GDladderObjects2.length = 0;
gdjs.lvl4Code.GDladderObjects3.length = 0;
gdjs.lvl4Code.GDdirtLeftObjects1.length = 0;
gdjs.lvl4Code.GDdirtLeftObjects2.length = 0;
gdjs.lvl4Code.GDdirtLeftObjects3.length = 0;
gdjs.lvl4Code.GDDoor2Objects1.length = 0;
gdjs.lvl4Code.GDDoor2Objects2.length = 0;
gdjs.lvl4Code.GDDoor2Objects3.length = 0;
gdjs.lvl4Code.GDtopOfdoorObjects1.length = 0;
gdjs.lvl4Code.GDtopOfdoorObjects2.length = 0;
gdjs.lvl4Code.GDtopOfdoorObjects3.length = 0;
gdjs.lvl4Code.GDbridgelogsObjects1.length = 0;
gdjs.lvl4Code.GDbridgelogsObjects2.length = 0;
gdjs.lvl4Code.GDbridgelogsObjects3.length = 0;
gdjs.lvl4Code.GDcrookObjects1.length = 0;
gdjs.lvl4Code.GDcrookObjects2.length = 0;
gdjs.lvl4Code.GDcrookObjects3.length = 0;
gdjs.lvl4Code.GDenemyrightObjects1.length = 0;
gdjs.lvl4Code.GDenemyrightObjects2.length = 0;
gdjs.lvl4Code.GDenemyrightObjects3.length = 0;
gdjs.lvl4Code.GDenemyLefyObjects1.length = 0;
gdjs.lvl4Code.GDenemyLefyObjects2.length = 0;
gdjs.lvl4Code.GDenemyLefyObjects3.length = 0;
gdjs.lvl4Code.GDNewObject2Objects1.length = 0;
gdjs.lvl4Code.GDNewObject2Objects2.length = 0;
gdjs.lvl4Code.GDNewObject2Objects3.length = 0;
gdjs.lvl4Code.GDbackButtonObjects1.length = 0;
gdjs.lvl4Code.GDbackButtonObjects2.length = 0;
gdjs.lvl4Code.GDbackButtonObjects3.length = 0;
gdjs.lvl4Code.GDcoinGoldObjects1.length = 0;
gdjs.lvl4Code.GDcoinGoldObjects2.length = 0;
gdjs.lvl4Code.GDcoinGoldObjects3.length = 0;
gdjs.lvl4Code.GDbackgroundObjects1.length = 0;
gdjs.lvl4Code.GDbackgroundObjects2.length = 0;
gdjs.lvl4Code.GDbackgroundObjects3.length = 0;
gdjs.lvl4Code.GDgameoverObjects1.length = 0;
gdjs.lvl4Code.GDgameoverObjects2.length = 0;
gdjs.lvl4Code.GDgameoverObjects3.length = 0;
gdjs.lvl4Code.GDendlessScoreObjects1.length = 0;
gdjs.lvl4Code.GDendlessScoreObjects2.length = 0;
gdjs.lvl4Code.GDendlessScoreObjects3.length = 0;
gdjs.lvl4Code.GDgamestartObjects1.length = 0;
gdjs.lvl4Code.GDgamestartObjects2.length = 0;
gdjs.lvl4Code.GDgamestartObjects3.length = 0;
gdjs.lvl4Code.GDRestartObjects1.length = 0;
gdjs.lvl4Code.GDRestartObjects2.length = 0;
gdjs.lvl4Code.GDRestartObjects3.length = 0;
gdjs.lvl4Code.GDbridgeObjects1.length = 0;
gdjs.lvl4Code.GDbridgeObjects2.length = 0;
gdjs.lvl4Code.GDbridgeObjects3.length = 0;
gdjs.lvl4Code.GDCandyLandLeftObjects1.length = 0;
gdjs.lvl4Code.GDCandyLandLeftObjects2.length = 0;
gdjs.lvl4Code.GDCandyLandLeftObjects3.length = 0;
gdjs.lvl4Code.GDCandyMidObjects1.length = 0;
gdjs.lvl4Code.GDCandyMidObjects2.length = 0;
gdjs.lvl4Code.GDCandyMidObjects3.length = 0;
gdjs.lvl4Code.GDCandyRightObjects1.length = 0;
gdjs.lvl4Code.GDCandyRightObjects2.length = 0;
gdjs.lvl4Code.GDCandyRightObjects3.length = 0;
gdjs.lvl4Code.GDcandyCoinObjects1.length = 0;
gdjs.lvl4Code.GDcandyCoinObjects2.length = 0;
gdjs.lvl4Code.GDcandyCoinObjects3.length = 0;
gdjs.lvl4Code.GDcandycane1Objects1.length = 0;
gdjs.lvl4Code.GDcandycane1Objects2.length = 0;
gdjs.lvl4Code.GDcandycane1Objects3.length = 0;
gdjs.lvl4Code.GDcandycane2Objects1.length = 0;
gdjs.lvl4Code.GDcandycane2Objects2.length = 0;
gdjs.lvl4Code.GDcandycane2Objects3.length = 0;
gdjs.lvl4Code.GDcandybgObjects1.length = 0;
gdjs.lvl4Code.GDcandybgObjects2.length = 0;
gdjs.lvl4Code.GDcandybgObjects3.length = 0;
gdjs.lvl4Code.GDangledleftcnadyObjects1.length = 0;
gdjs.lvl4Code.GDangledleftcnadyObjects2.length = 0;
gdjs.lvl4Code.GDangledleftcnadyObjects3.length = 0;
gdjs.lvl4Code.GDMIDDLECLEARObjects1.length = 0;
gdjs.lvl4Code.GDMIDDLECLEARObjects2.length = 0;
gdjs.lvl4Code.GDMIDDLECLEARObjects3.length = 0;
gdjs.lvl4Code.GDANGLEDLEFTSQUAREObjects1.length = 0;
gdjs.lvl4Code.GDANGLEDLEFTSQUAREObjects2.length = 0;
gdjs.lvl4Code.GDANGLEDLEFTSQUAREObjects3.length = 0;
gdjs.lvl4Code.GDCANDYMID_95NOT_95TILEDObjects1.length = 0;
gdjs.lvl4Code.GDCANDYMID_95NOT_95TILEDObjects2.length = 0;
gdjs.lvl4Code.GDCANDYMID_95NOT_95TILEDObjects3.length = 0;
gdjs.lvl4Code.GDangledrightcandytriangleObjects1.length = 0;
gdjs.lvl4Code.GDangledrightcandytriangleObjects2.length = 0;
gdjs.lvl4Code.GDangledrightcandytriangleObjects3.length = 0;
gdjs.lvl4Code.GDNewObjectObjects1.length = 0;
gdjs.lvl4Code.GDNewObjectObjects2.length = 0;
gdjs.lvl4Code.GDNewObjectObjects3.length = 0;
gdjs.lvl4Code.GDlockObjects1.length = 0;
gdjs.lvl4Code.GDlockObjects2.length = 0;
gdjs.lvl4Code.GDlockObjects3.length = 0;
gdjs.lvl4Code.GDkeyObjects1.length = 0;
gdjs.lvl4Code.GDkeyObjects2.length = 0;
gdjs.lvl4Code.GDkeyObjects3.length = 0;
gdjs.lvl4Code.GDdownArrowObjects1.length = 0;
gdjs.lvl4Code.GDdownArrowObjects2.length = 0;
gdjs.lvl4Code.GDdownArrowObjects3.length = 0;
gdjs.lvl4Code.GDarrowUpObjects1.length = 0;
gdjs.lvl4Code.GDarrowUpObjects2.length = 0;
gdjs.lvl4Code.GDarrowUpObjects3.length = 0;
gdjs.lvl4Code.GDplatform_95candyObjects1.length = 0;
gdjs.lvl4Code.GDplatform_95candyObjects2.length = 0;
gdjs.lvl4Code.GDplatform_95candyObjects3.length = 0;
gdjs.lvl4Code.GDcount_95of_95keysObjects1.length = 0;
gdjs.lvl4Code.GDcount_95of_95keysObjects2.length = 0;
gdjs.lvl4Code.GDcount_95of_95keysObjects3.length = 0;
gdjs.lvl4Code.GDkey_95hudObjects1.length = 0;
gdjs.lvl4Code.GDkey_95hudObjects2.length = 0;
gdjs.lvl4Code.GDkey_95hudObjects3.length = 0;
gdjs.lvl4Code.GDsecretdoor1Objects1.length = 0;
gdjs.lvl4Code.GDsecretdoor1Objects2.length = 0;
gdjs.lvl4Code.GDsecretdoor1Objects3.length = 0;
gdjs.lvl4Code.GDsecretObjects1.length = 0;
gdjs.lvl4Code.GDsecretObjects2.length = 0;
gdjs.lvl4Code.GDsecretObjects3.length = 0;
gdjs.lvl4Code.GDopendoor1Objects1.length = 0;
gdjs.lvl4Code.GDopendoor1Objects2.length = 0;
gdjs.lvl4Code.GDopendoor1Objects3.length = 0;
gdjs.lvl4Code.GDopendoor2Objects1.length = 0;
gdjs.lvl4Code.GDopendoor2Objects2.length = 0;
gdjs.lvl4Code.GDopendoor2Objects3.length = 0;
gdjs.lvl4Code.GDNewObject3Objects1.length = 0;
gdjs.lvl4Code.GDNewObject3Objects2.length = 0;
gdjs.lvl4Code.GDNewObject3Objects3.length = 0;
gdjs.lvl4Code.GDNewObject4Objects1.length = 0;
gdjs.lvl4Code.GDNewObject4Objects2.length = 0;
gdjs.lvl4Code.GDNewObject4Objects3.length = 0;
gdjs.lvl4Code.GDCheckpointObjects1.length = 0;
gdjs.lvl4Code.GDCheckpointObjects2.length = 0;
gdjs.lvl4Code.GDCheckpointObjects3.length = 0;

gdjs.lvl4Code.eventsList12(runtimeScene);
return;

}

gdjs['lvl4Code'] = gdjs.lvl4Code;
