gdjs.End_32SceneCode = {};

gdjs.End_32SceneCode.conditionTrue_0 = {val:false};
gdjs.End_32SceneCode.condition0IsTrue_0 = {val:false};


gdjs.End_32SceneCode.eventsList0 = function(runtimeScene) {

};

gdjs.End_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.End_32SceneCode.eventsList0(runtimeScene);
return;

}

gdjs['End_32SceneCode'] = gdjs.End_32SceneCode;
