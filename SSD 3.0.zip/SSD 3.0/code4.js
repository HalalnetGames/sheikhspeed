gdjs.level3Code = {};
gdjs.level3Code.GDSheikhSpeedObjects1_1final = [];

gdjs.level3Code.GDSheikhSpeedObjects1= [];
gdjs.level3Code.GDSheikhSpeedObjects2= [];
gdjs.level3Code.GDSheikhSpeedObjects3= [];
gdjs.level3Code.GDCoinObjects1= [];
gdjs.level3Code.GDCoinObjects2= [];
gdjs.level3Code.GDCoinObjects3= [];
gdjs.level3Code.GDScoreObjects1= [];
gdjs.level3Code.GDScoreObjects2= [];
gdjs.level3Code.GDScoreObjects3= [];
gdjs.level3Code.GDHaramPointObjects1= [];
gdjs.level3Code.GDHaramPointObjects2= [];
gdjs.level3Code.GDHaramPointObjects3= [];
gdjs.level3Code.GDExitButtonObjects1= [];
gdjs.level3Code.GDExitButtonObjects2= [];
gdjs.level3Code.GDExitButtonObjects3= [];
gdjs.level3Code.GDGroundObjects1= [];
gdjs.level3Code.GDGroundObjects2= [];
gdjs.level3Code.GDGroundObjects3= [];
gdjs.level3Code.GDladderObjects1= [];
gdjs.level3Code.GDladderObjects2= [];
gdjs.level3Code.GDladderObjects3= [];
gdjs.level3Code.GDdirtLeftObjects1= [];
gdjs.level3Code.GDdirtLeftObjects2= [];
gdjs.level3Code.GDdirtLeftObjects3= [];
gdjs.level3Code.GDDoor2Objects1= [];
gdjs.level3Code.GDDoor2Objects2= [];
gdjs.level3Code.GDDoor2Objects3= [];
gdjs.level3Code.GDtopOfdoorObjects1= [];
gdjs.level3Code.GDtopOfdoorObjects2= [];
gdjs.level3Code.GDtopOfdoorObjects3= [];
gdjs.level3Code.GDbridgelogsObjects1= [];
gdjs.level3Code.GDbridgelogsObjects2= [];
gdjs.level3Code.GDbridgelogsObjects3= [];
gdjs.level3Code.GDcrookObjects1= [];
gdjs.level3Code.GDcrookObjects2= [];
gdjs.level3Code.GDcrookObjects3= [];
gdjs.level3Code.GDenemyrightObjects1= [];
gdjs.level3Code.GDenemyrightObjects2= [];
gdjs.level3Code.GDenemyrightObjects3= [];
gdjs.level3Code.GDenemyLefyObjects1= [];
gdjs.level3Code.GDenemyLefyObjects2= [];
gdjs.level3Code.GDenemyLefyObjects3= [];
gdjs.level3Code.GDNewObject2Objects1= [];
gdjs.level3Code.GDNewObject2Objects2= [];
gdjs.level3Code.GDNewObject2Objects3= [];
gdjs.level3Code.GDbackButtonObjects1= [];
gdjs.level3Code.GDbackButtonObjects2= [];
gdjs.level3Code.GDbackButtonObjects3= [];
gdjs.level3Code.GDcoinGoldObjects1= [];
gdjs.level3Code.GDcoinGoldObjects2= [];
gdjs.level3Code.GDcoinGoldObjects3= [];
gdjs.level3Code.GDbackgroundObjects1= [];
gdjs.level3Code.GDbackgroundObjects2= [];
gdjs.level3Code.GDbackgroundObjects3= [];
gdjs.level3Code.GDgameoverObjects1= [];
gdjs.level3Code.GDgameoverObjects2= [];
gdjs.level3Code.GDgameoverObjects3= [];
gdjs.level3Code.GDendlessScoreObjects1= [];
gdjs.level3Code.GDendlessScoreObjects2= [];
gdjs.level3Code.GDendlessScoreObjects3= [];
gdjs.level3Code.GDgamestartObjects1= [];
gdjs.level3Code.GDgamestartObjects2= [];
gdjs.level3Code.GDgamestartObjects3= [];
gdjs.level3Code.GDRestartObjects1= [];
gdjs.level3Code.GDRestartObjects2= [];
gdjs.level3Code.GDRestartObjects3= [];
gdjs.level3Code.GDbridgeObjects1= [];
gdjs.level3Code.GDbridgeObjects2= [];
gdjs.level3Code.GDbridgeObjects3= [];
gdjs.level3Code.GDSnowObjects1= [];
gdjs.level3Code.GDSnowObjects2= [];
gdjs.level3Code.GDSnowObjects3= [];
gdjs.level3Code.GDNewObject2Objects1= [];
gdjs.level3Code.GDNewObject2Objects2= [];
gdjs.level3Code.GDNewObject2Objects3= [];
gdjs.level3Code.GDlevel3IntroBoxObjects1= [];
gdjs.level3Code.GDlevel3IntroBoxObjects2= [];
gdjs.level3Code.GDlevel3IntroBoxObjects3= [];
gdjs.level3Code.GDgoldcoin_95boxObjects1= [];
gdjs.level3Code.GDgoldcoin_95boxObjects2= [];
gdjs.level3Code.GDgoldcoin_95boxObjects3= [];
gdjs.level3Code.GDNewObjectObjects1= [];
gdjs.level3Code.GDNewObjectObjects2= [];
gdjs.level3Code.GDNewObjectObjects3= [];
gdjs.level3Code.GDNewObject3Objects1= [];
gdjs.level3Code.GDNewObject3Objects2= [];
gdjs.level3Code.GDNewObject3Objects3= [];
gdjs.level3Code.GDSecretDoor1Objects1= [];
gdjs.level3Code.GDSecretDoor1Objects2= [];
gdjs.level3Code.GDSecretDoor1Objects3= [];
gdjs.level3Code.GDNewObject4Objects1= [];
gdjs.level3Code.GDNewObject4Objects2= [];
gdjs.level3Code.GDNewObject4Objects3= [];
gdjs.level3Code.GDsecretDoor2Objects1= [];
gdjs.level3Code.GDsecretDoor2Objects2= [];
gdjs.level3Code.GDsecretDoor2Objects3= [];

gdjs.level3Code.conditionTrue_0 = {val:false};
gdjs.level3Code.condition0IsTrue_0 = {val:false};
gdjs.level3Code.condition1IsTrue_0 = {val:false};
gdjs.level3Code.condition2IsTrue_0 = {val:false};
gdjs.level3Code.conditionTrue_1 = {val:false};
gdjs.level3Code.condition0IsTrue_1 = {val:false};
gdjs.level3Code.condition1IsTrue_1 = {val:false};
gdjs.level3Code.condition2IsTrue_1 = {val:false};


gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects2});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.level3Code.GDCoinObjects2});gdjs.level3Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.level3Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects2Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDCoinObjects2Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDCoinObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.level3Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.level3Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDScoreObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.level3Code.eventsList1 = function(runtimeScene) {

};gdjs.level3Code.eventsList2 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.level3Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.level3Code.GDSheikhSpeedObjects1[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.level3Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.level3Code.GDSheikhSpeedObjects1[0].getPointY("")), 0.1), "", 0);
}}

}


};gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.level3Code.GDDoor2Objects1});gdjs.level3Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.level3Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}}

}


};gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.level3Code.GDcrookObjects2});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDenemyrightObjects2Objects = Hashtable.newFrom({"enemyright": gdjs.level3Code.GDenemyrightObjects2});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects2});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.level3Code.GDcrookObjects2});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects2});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.level3Code.GDcrookObjects2});gdjs.level3Code.eventsList4 = function(runtimeScene) {

{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.level3Code.GDenemyrightObjects2);
{for(var i = 0, len = gdjs.level3Code.GDenemyrightObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDenemyrightObjects2[i].hide();
}
}{/* Unknown object - skipped. */}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level3Code.GDcrookObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level3Code.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.level3Code.GDcrookObjects2[i].getVariableString(gdjs.level3Code.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Left" ) {
        gdjs.level3Code.condition0IsTrue_0.val = true;
        gdjs.level3Code.GDcrookObjects2[k] = gdjs.level3Code.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.level3Code.GDcrookObjects2.length = k;}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].addForce(-(40), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level3Code.GDcrookObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level3Code.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.level3Code.GDcrookObjects2[i].getVariableString(gdjs.level3Code.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Right" ) {
        gdjs.level3Code.condition0IsTrue_0.val = true;
        gdjs.level3Code.GDcrookObjects2[k] = gdjs.level3Code.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.level3Code.GDcrookObjects2.length = k;}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].addForce(40, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level3Code.GDcrookObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.level3Code.GDenemyrightObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcrookObjects2Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDenemyrightObjects2Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].flipX(true);
}
}{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].returnVariable(gdjs.level3Code.GDcrookObjects2[i].getVariables().getFromIndex(0)).setString("Right");
}
}}

}


{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
/* Unknown object - skipped. */}if (gdjs.level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level3Code.GDcrookObjects2);
{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].flipX(false);
}
}{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].returnVariable(gdjs.level3Code.GDcrookObjects2[i].getVariables().getFromIndex(0)).setString("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level3Code.GDcrookObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
gdjs.level3Code.condition1IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects2Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcrookObjects2Objects, false, runtimeScene, false);
}if ( gdjs.level3Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.level3Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.level3Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.level3Code.condition1IsTrue_0.val = true;
        gdjs.level3Code.GDSheikhSpeedObjects2[k] = gdjs.level3Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level3Code.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.level3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level2", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level3Code.GDcrookObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
gdjs.level3Code.condition1IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects2Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcrookObjects2Objects, false, runtimeScene, false);
}if ( gdjs.level3Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.level3Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.level3Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.level3Code.condition1IsTrue_0.val = true;
        gdjs.level3Code.GDSheikhSpeedObjects2[k] = gdjs.level3Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level3Code.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.level3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level3Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDcrookObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
}

}


};gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDHaramPointObjects1Objects = Hashtable.newFrom({"HaramPoint": gdjs.level3Code.GDHaramPointObjects1});gdjs.level3Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HaramPoint"), gdjs.level3Code.GDHaramPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDHaramPointObjects1Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDSheikhSpeedObjects1 */
{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "level3");
}}

}


};gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcoinGoldObjects1Objects = Hashtable.newFrom({"coinGold": gdjs.level3Code.GDcoinGoldObjects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.level3Code.GDExitButtonObjects1});gdjs.level3Code.eventsList6 = function(runtimeScene) {

{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.level3Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.level3Code.GDExitButtonObjects1);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDExitButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.level3Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.level3Code.eventsList8 = function(runtimeScene) {

{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].flipX(false);
}
}}

}


{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level3Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( !(gdjs.level3Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.level3Code.condition0IsTrue_0.val = true;
        gdjs.level3Code.GDSheikhSpeedObjects2[k] = gdjs.level3Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level3Code.GDSheikhSpeedObjects2.length = k;}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.level3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);
{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level3Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.level3Code.GDDoor2Objects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDbridgeObjects1Objects = Hashtable.newFrom({"bridge": gdjs.level3Code.GDbridgeObjects1});gdjs.level3Code.eventsList9 = function(runtimeScene) {

{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "bridgecount");
}}

}


{


gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "bridgecount");
}if (gdjs.level3Code.condition0IsTrue_0.val) {
gdjs.level3Code.GDbridgeObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDbridgeObjects1Objects, 4130, 600, "");
}{for(var i = 0, len = gdjs.level3Code.GDbridgeObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDbridgeObjects1[i].addForce(0, -(200), 1);
}
}{for(var i = 0, len = gdjs.level3Code.GDbridgeObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDbridgeObjects1[i].setHeight(192);
}
}{for(var i = 0, len = gdjs.level3Code.GDbridgeObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDbridgeObjects1[i].setWidth(352);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "bridgecount");
}}

}


};gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level3Code.GDSheikhSpeedObjects1});gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSecretDoor1Objects1Objects = Hashtable.newFrom({"SecretDoor1": gdjs.level3Code.GDSecretDoor1Objects1});gdjs.level3Code.eventsList10 = function(runtimeScene) {

{


gdjs.level3Code.eventsList0(runtimeScene);
}


{


gdjs.level3Code.eventsList1(runtimeScene);
}


{


gdjs.level3Code.eventsList2(runtimeScene);
}


{


gdjs.level3Code.eventsList3(runtimeScene);
}


{


gdjs.level3Code.eventsList4(runtimeScene);
}


{


gdjs.level3Code.eventsList5(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);
gdjs.copyArray(runtimeScene.getObjects("coinGold"), gdjs.level3Code.GDcoinGoldObjects1);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDcoinGoldObjects1Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level3Code.GDcoinGoldObjects1 */
{for(var i = 0, len = gdjs.level3Code.GDcoinGoldObjects1.length ;i < len;++i) {
    gdjs.level3Code.GDcoinGoldObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}}

}


{


{
}

}


{


{
}

}


{


gdjs.level3Code.eventsList7(runtimeScene);
}


{


gdjs.level3Code.eventsList8(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.level3Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}}

}


{

gdjs.level3Code.GDSheikhSpeedObjects1.length = 0;


gdjs.level3Code.condition0IsTrue_0.val = false;
{
{gdjs.level3Code.conditionTrue_1 = gdjs.level3Code.condition0IsTrue_0;
gdjs.level3Code.GDSheikhSpeedObjects1_1final.length = 0;gdjs.level3Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects2);
for(var i = 0, k = 0, l = gdjs.level3Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.level3Code.GDSheikhSpeedObjects2[i].getY() >= 1300 ) {
        gdjs.level3Code.condition0IsTrue_1.val = true;
        gdjs.level3Code.GDSheikhSpeedObjects2[k] = gdjs.level3Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level3Code.GDSheikhSpeedObjects2.length = k;if( gdjs.level3Code.condition0IsTrue_1.val ) {
    gdjs.level3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.level3Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.level3Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.level3Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.level3Code.GDSheikhSpeedObjects1_1final.push(gdjs.level3Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level3Code.GDSheikhSpeedObjects1_1final, gdjs.level3Code.GDSheikhSpeedObjects1);
}
}
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level3", false);
}}

}


{


{
}

}


{


gdjs.level3Code.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("SecretDoor1"), gdjs.level3Code.GDSecretDoor1Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level3Code.GDSheikhSpeedObjects1);

gdjs.level3Code.condition0IsTrue_0.val = false;
{
gdjs.level3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSheikhSpeedObjects1Objects, gdjs.level3Code.mapOfGDgdjs_46level3Code_46GDSecretDoor1Objects1Objects, false, runtimeScene, false);
}if (gdjs.level3Code.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl3_secret", false);
}}

}


{


{
}

}


};

gdjs.level3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level3Code.GDSheikhSpeedObjects1.length = 0;
gdjs.level3Code.GDSheikhSpeedObjects2.length = 0;
gdjs.level3Code.GDSheikhSpeedObjects3.length = 0;
gdjs.level3Code.GDCoinObjects1.length = 0;
gdjs.level3Code.GDCoinObjects2.length = 0;
gdjs.level3Code.GDCoinObjects3.length = 0;
gdjs.level3Code.GDScoreObjects1.length = 0;
gdjs.level3Code.GDScoreObjects2.length = 0;
gdjs.level3Code.GDScoreObjects3.length = 0;
gdjs.level3Code.GDHaramPointObjects1.length = 0;
gdjs.level3Code.GDHaramPointObjects2.length = 0;
gdjs.level3Code.GDHaramPointObjects3.length = 0;
gdjs.level3Code.GDExitButtonObjects1.length = 0;
gdjs.level3Code.GDExitButtonObjects2.length = 0;
gdjs.level3Code.GDExitButtonObjects3.length = 0;
gdjs.level3Code.GDGroundObjects1.length = 0;
gdjs.level3Code.GDGroundObjects2.length = 0;
gdjs.level3Code.GDGroundObjects3.length = 0;
gdjs.level3Code.GDladderObjects1.length = 0;
gdjs.level3Code.GDladderObjects2.length = 0;
gdjs.level3Code.GDladderObjects3.length = 0;
gdjs.level3Code.GDdirtLeftObjects1.length = 0;
gdjs.level3Code.GDdirtLeftObjects2.length = 0;
gdjs.level3Code.GDdirtLeftObjects3.length = 0;
gdjs.level3Code.GDDoor2Objects1.length = 0;
gdjs.level3Code.GDDoor2Objects2.length = 0;
gdjs.level3Code.GDDoor2Objects3.length = 0;
gdjs.level3Code.GDtopOfdoorObjects1.length = 0;
gdjs.level3Code.GDtopOfdoorObjects2.length = 0;
gdjs.level3Code.GDtopOfdoorObjects3.length = 0;
gdjs.level3Code.GDbridgelogsObjects1.length = 0;
gdjs.level3Code.GDbridgelogsObjects2.length = 0;
gdjs.level3Code.GDbridgelogsObjects3.length = 0;
gdjs.level3Code.GDcrookObjects1.length = 0;
gdjs.level3Code.GDcrookObjects2.length = 0;
gdjs.level3Code.GDcrookObjects3.length = 0;
gdjs.level3Code.GDenemyrightObjects1.length = 0;
gdjs.level3Code.GDenemyrightObjects2.length = 0;
gdjs.level3Code.GDenemyrightObjects3.length = 0;
gdjs.level3Code.GDenemyLefyObjects1.length = 0;
gdjs.level3Code.GDenemyLefyObjects2.length = 0;
gdjs.level3Code.GDenemyLefyObjects3.length = 0;
gdjs.level3Code.GDNewObject2Objects1.length = 0;
gdjs.level3Code.GDNewObject2Objects2.length = 0;
gdjs.level3Code.GDNewObject2Objects3.length = 0;
gdjs.level3Code.GDbackButtonObjects1.length = 0;
gdjs.level3Code.GDbackButtonObjects2.length = 0;
gdjs.level3Code.GDbackButtonObjects3.length = 0;
gdjs.level3Code.GDcoinGoldObjects1.length = 0;
gdjs.level3Code.GDcoinGoldObjects2.length = 0;
gdjs.level3Code.GDcoinGoldObjects3.length = 0;
gdjs.level3Code.GDbackgroundObjects1.length = 0;
gdjs.level3Code.GDbackgroundObjects2.length = 0;
gdjs.level3Code.GDbackgroundObjects3.length = 0;
gdjs.level3Code.GDgameoverObjects1.length = 0;
gdjs.level3Code.GDgameoverObjects2.length = 0;
gdjs.level3Code.GDgameoverObjects3.length = 0;
gdjs.level3Code.GDendlessScoreObjects1.length = 0;
gdjs.level3Code.GDendlessScoreObjects2.length = 0;
gdjs.level3Code.GDendlessScoreObjects3.length = 0;
gdjs.level3Code.GDgamestartObjects1.length = 0;
gdjs.level3Code.GDgamestartObjects2.length = 0;
gdjs.level3Code.GDgamestartObjects3.length = 0;
gdjs.level3Code.GDRestartObjects1.length = 0;
gdjs.level3Code.GDRestartObjects2.length = 0;
gdjs.level3Code.GDRestartObjects3.length = 0;
gdjs.level3Code.GDbridgeObjects1.length = 0;
gdjs.level3Code.GDbridgeObjects2.length = 0;
gdjs.level3Code.GDbridgeObjects3.length = 0;
gdjs.level3Code.GDSnowObjects1.length = 0;
gdjs.level3Code.GDSnowObjects2.length = 0;
gdjs.level3Code.GDSnowObjects3.length = 0;
gdjs.level3Code.GDNewObject2Objects1.length = 0;
gdjs.level3Code.GDNewObject2Objects2.length = 0;
gdjs.level3Code.GDNewObject2Objects3.length = 0;
gdjs.level3Code.GDlevel3IntroBoxObjects1.length = 0;
gdjs.level3Code.GDlevel3IntroBoxObjects2.length = 0;
gdjs.level3Code.GDlevel3IntroBoxObjects3.length = 0;
gdjs.level3Code.GDgoldcoin_95boxObjects1.length = 0;
gdjs.level3Code.GDgoldcoin_95boxObjects2.length = 0;
gdjs.level3Code.GDgoldcoin_95boxObjects3.length = 0;
gdjs.level3Code.GDNewObjectObjects1.length = 0;
gdjs.level3Code.GDNewObjectObjects2.length = 0;
gdjs.level3Code.GDNewObjectObjects3.length = 0;
gdjs.level3Code.GDNewObject3Objects1.length = 0;
gdjs.level3Code.GDNewObject3Objects2.length = 0;
gdjs.level3Code.GDNewObject3Objects3.length = 0;
gdjs.level3Code.GDSecretDoor1Objects1.length = 0;
gdjs.level3Code.GDSecretDoor1Objects2.length = 0;
gdjs.level3Code.GDSecretDoor1Objects3.length = 0;
gdjs.level3Code.GDNewObject4Objects1.length = 0;
gdjs.level3Code.GDNewObject4Objects2.length = 0;
gdjs.level3Code.GDNewObject4Objects3.length = 0;
gdjs.level3Code.GDsecretDoor2Objects1.length = 0;
gdjs.level3Code.GDsecretDoor2Objects2.length = 0;
gdjs.level3Code.GDsecretDoor2Objects3.length = 0;

gdjs.level3Code.eventsList10(runtimeScene);
return;

}

gdjs['level3Code'] = gdjs.level3Code;
