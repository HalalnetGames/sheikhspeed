gdjs.CreditsCode = {};
gdjs.CreditsCode.GDSheikhSpeedObjects1= [];
gdjs.CreditsCode.GDSheikhSpeedObjects2= [];
gdjs.CreditsCode.GDCoinObjects1= [];
gdjs.CreditsCode.GDCoinObjects2= [];
gdjs.CreditsCode.GDScoreObjects1= [];
gdjs.CreditsCode.GDScoreObjects2= [];
gdjs.CreditsCode.GDHaramPointObjects1= [];
gdjs.CreditsCode.GDHaramPointObjects2= [];
gdjs.CreditsCode.GDExitButtonObjects1= [];
gdjs.CreditsCode.GDExitButtonObjects2= [];
gdjs.CreditsCode.GDGroundObjects1= [];
gdjs.CreditsCode.GDGroundObjects2= [];
gdjs.CreditsCode.GDladderObjects1= [];
gdjs.CreditsCode.GDladderObjects2= [];
gdjs.CreditsCode.GDdirtLeftObjects1= [];
gdjs.CreditsCode.GDdirtLeftObjects2= [];
gdjs.CreditsCode.GDDoor2Objects1= [];
gdjs.CreditsCode.GDDoor2Objects2= [];
gdjs.CreditsCode.GDtopOfdoorObjects1= [];
gdjs.CreditsCode.GDtopOfdoorObjects2= [];
gdjs.CreditsCode.GDbridgelogsObjects1= [];
gdjs.CreditsCode.GDbridgelogsObjects2= [];
gdjs.CreditsCode.GDcrookObjects1= [];
gdjs.CreditsCode.GDcrookObjects2= [];
gdjs.CreditsCode.GDenemyrightObjects1= [];
gdjs.CreditsCode.GDenemyrightObjects2= [];
gdjs.CreditsCode.GDenemyLefyObjects1= [];
gdjs.CreditsCode.GDenemyLefyObjects2= [];
gdjs.CreditsCode.GDNewObject2Objects1= [];
gdjs.CreditsCode.GDNewObject2Objects2= [];
gdjs.CreditsCode.GDbackButtonObjects1= [];
gdjs.CreditsCode.GDbackButtonObjects2= [];
gdjs.CreditsCode.GDcoinGoldObjects1= [];
gdjs.CreditsCode.GDcoinGoldObjects2= [];
gdjs.CreditsCode.GDbackgroundObjects1= [];
gdjs.CreditsCode.GDbackgroundObjects2= [];
gdjs.CreditsCode.GDgameoverObjects1= [];
gdjs.CreditsCode.GDgameoverObjects2= [];
gdjs.CreditsCode.GDendlessScoreObjects1= [];
gdjs.CreditsCode.GDendlessScoreObjects2= [];
gdjs.CreditsCode.GDgamestartObjects1= [];
gdjs.CreditsCode.GDgamestartObjects2= [];
gdjs.CreditsCode.GDRestartObjects1= [];
gdjs.CreditsCode.GDRestartObjects2= [];
gdjs.CreditsCode.GDbridgeObjects1= [];
gdjs.CreditsCode.GDbridgeObjects2= [];
gdjs.CreditsCode.GDCredits_95bgObjects1= [];
gdjs.CreditsCode.GDCredits_95bgObjects2= [];

gdjs.CreditsCode.conditionTrue_0 = {val:false};
gdjs.CreditsCode.condition0IsTrue_0 = {val:false};
gdjs.CreditsCode.condition1IsTrue_0 = {val:false};


gdjs.CreditsCode.mapOfGDgdjs_46CreditsCode_46GDbackButtonObjects1Objects = Hashtable.newFrom({"backButton": gdjs.CreditsCode.GDbackButtonObjects1});gdjs.CreditsCode.eventsList0 = function(runtimeScene) {

{


gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
gdjs.CreditsCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.CreditsCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.CreditsCode.GDbackButtonObjects1);

gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
gdjs.CreditsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.CreditsCode.mapOfGDgdjs_46CreditsCode_46GDbackButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.CreditsCode.GDbackButtonObjects1 */
{for(var i = 0, len = gdjs.CreditsCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDbackButtonObjects1[i].setAnimation(0);
}
}
{ //Subevents
gdjs.CreditsCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.CreditsCode.eventsList2 = function(runtimeScene) {

{


gdjs.CreditsCode.eventsList1(runtimeScene);
}


{


{
}

}


};

gdjs.CreditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CreditsCode.GDSheikhSpeedObjects1.length = 0;
gdjs.CreditsCode.GDSheikhSpeedObjects2.length = 0;
gdjs.CreditsCode.GDCoinObjects1.length = 0;
gdjs.CreditsCode.GDCoinObjects2.length = 0;
gdjs.CreditsCode.GDScoreObjects1.length = 0;
gdjs.CreditsCode.GDScoreObjects2.length = 0;
gdjs.CreditsCode.GDHaramPointObjects1.length = 0;
gdjs.CreditsCode.GDHaramPointObjects2.length = 0;
gdjs.CreditsCode.GDExitButtonObjects1.length = 0;
gdjs.CreditsCode.GDExitButtonObjects2.length = 0;
gdjs.CreditsCode.GDGroundObjects1.length = 0;
gdjs.CreditsCode.GDGroundObjects2.length = 0;
gdjs.CreditsCode.GDladderObjects1.length = 0;
gdjs.CreditsCode.GDladderObjects2.length = 0;
gdjs.CreditsCode.GDdirtLeftObjects1.length = 0;
gdjs.CreditsCode.GDdirtLeftObjects2.length = 0;
gdjs.CreditsCode.GDDoor2Objects1.length = 0;
gdjs.CreditsCode.GDDoor2Objects2.length = 0;
gdjs.CreditsCode.GDtopOfdoorObjects1.length = 0;
gdjs.CreditsCode.GDtopOfdoorObjects2.length = 0;
gdjs.CreditsCode.GDbridgelogsObjects1.length = 0;
gdjs.CreditsCode.GDbridgelogsObjects2.length = 0;
gdjs.CreditsCode.GDcrookObjects1.length = 0;
gdjs.CreditsCode.GDcrookObjects2.length = 0;
gdjs.CreditsCode.GDenemyrightObjects1.length = 0;
gdjs.CreditsCode.GDenemyrightObjects2.length = 0;
gdjs.CreditsCode.GDenemyLefyObjects1.length = 0;
gdjs.CreditsCode.GDenemyLefyObjects2.length = 0;
gdjs.CreditsCode.GDNewObject2Objects1.length = 0;
gdjs.CreditsCode.GDNewObject2Objects2.length = 0;
gdjs.CreditsCode.GDbackButtonObjects1.length = 0;
gdjs.CreditsCode.GDbackButtonObjects2.length = 0;
gdjs.CreditsCode.GDcoinGoldObjects1.length = 0;
gdjs.CreditsCode.GDcoinGoldObjects2.length = 0;
gdjs.CreditsCode.GDbackgroundObjects1.length = 0;
gdjs.CreditsCode.GDbackgroundObjects2.length = 0;
gdjs.CreditsCode.GDgameoverObjects1.length = 0;
gdjs.CreditsCode.GDgameoverObjects2.length = 0;
gdjs.CreditsCode.GDendlessScoreObjects1.length = 0;
gdjs.CreditsCode.GDendlessScoreObjects2.length = 0;
gdjs.CreditsCode.GDgamestartObjects1.length = 0;
gdjs.CreditsCode.GDgamestartObjects2.length = 0;
gdjs.CreditsCode.GDRestartObjects1.length = 0;
gdjs.CreditsCode.GDRestartObjects2.length = 0;
gdjs.CreditsCode.GDbridgeObjects1.length = 0;
gdjs.CreditsCode.GDbridgeObjects2.length = 0;
gdjs.CreditsCode.GDCredits_95bgObjects1.length = 0;
gdjs.CreditsCode.GDCredits_95bgObjects2.length = 0;

gdjs.CreditsCode.eventsList2(runtimeScene);
return;

}

gdjs['CreditsCode'] = gdjs.CreditsCode;
