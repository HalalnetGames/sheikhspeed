gdjs.shooter_40maybe_41Code = {};
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1_1final = [];

gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1= [];
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2= [];
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects3= [];
gdjs.shooter_40maybe_41Code.GDCoinObjects1= [];
gdjs.shooter_40maybe_41Code.GDCoinObjects2= [];
gdjs.shooter_40maybe_41Code.GDCoinObjects3= [];
gdjs.shooter_40maybe_41Code.GDScoreObjects1= [];
gdjs.shooter_40maybe_41Code.GDScoreObjects2= [];
gdjs.shooter_40maybe_41Code.GDScoreObjects3= [];
gdjs.shooter_40maybe_41Code.GDHaramPointObjects1= [];
gdjs.shooter_40maybe_41Code.GDHaramPointObjects2= [];
gdjs.shooter_40maybe_41Code.GDHaramPointObjects3= [];
gdjs.shooter_40maybe_41Code.GDExitButtonObjects1= [];
gdjs.shooter_40maybe_41Code.GDExitButtonObjects2= [];
gdjs.shooter_40maybe_41Code.GDExitButtonObjects3= [];
gdjs.shooter_40maybe_41Code.GDGroundObjects1= [];
gdjs.shooter_40maybe_41Code.GDGroundObjects2= [];
gdjs.shooter_40maybe_41Code.GDGroundObjects3= [];
gdjs.shooter_40maybe_41Code.GDladderObjects1= [];
gdjs.shooter_40maybe_41Code.GDladderObjects2= [];
gdjs.shooter_40maybe_41Code.GDladderObjects3= [];
gdjs.shooter_40maybe_41Code.GDdirtLeftObjects1= [];
gdjs.shooter_40maybe_41Code.GDdirtLeftObjects2= [];
gdjs.shooter_40maybe_41Code.GDdirtLeftObjects3= [];
gdjs.shooter_40maybe_41Code.GDDoor2Objects1= [];
gdjs.shooter_40maybe_41Code.GDDoor2Objects2= [];
gdjs.shooter_40maybe_41Code.GDDoor2Objects3= [];
gdjs.shooter_40maybe_41Code.GDtopOfdoorObjects1= [];
gdjs.shooter_40maybe_41Code.GDtopOfdoorObjects2= [];
gdjs.shooter_40maybe_41Code.GDtopOfdoorObjects3= [];
gdjs.shooter_40maybe_41Code.GDbridgelogsObjects1= [];
gdjs.shooter_40maybe_41Code.GDbridgelogsObjects2= [];
gdjs.shooter_40maybe_41Code.GDbridgelogsObjects3= [];
gdjs.shooter_40maybe_41Code.GDcrookObjects1= [];
gdjs.shooter_40maybe_41Code.GDcrookObjects2= [];
gdjs.shooter_40maybe_41Code.GDcrookObjects3= [];
gdjs.shooter_40maybe_41Code.GDenemyrightObjects1= [];
gdjs.shooter_40maybe_41Code.GDenemyrightObjects2= [];
gdjs.shooter_40maybe_41Code.GDenemyrightObjects3= [];
gdjs.shooter_40maybe_41Code.GDenemyLefyObjects1= [];
gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2= [];
gdjs.shooter_40maybe_41Code.GDenemyLefyObjects3= [];
gdjs.shooter_40maybe_41Code.GDNewObject2Objects1= [];
gdjs.shooter_40maybe_41Code.GDNewObject2Objects2= [];
gdjs.shooter_40maybe_41Code.GDNewObject2Objects3= [];
gdjs.shooter_40maybe_41Code.GDbackButtonObjects1= [];
gdjs.shooter_40maybe_41Code.GDbackButtonObjects2= [];
gdjs.shooter_40maybe_41Code.GDbackButtonObjects3= [];
gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1= [];
gdjs.shooter_40maybe_41Code.GDcoinGoldObjects2= [];
gdjs.shooter_40maybe_41Code.GDcoinGoldObjects3= [];
gdjs.shooter_40maybe_41Code.GDbackgroundObjects1= [];
gdjs.shooter_40maybe_41Code.GDbackgroundObjects2= [];
gdjs.shooter_40maybe_41Code.GDbackgroundObjects3= [];
gdjs.shooter_40maybe_41Code.GDgameoverObjects1= [];
gdjs.shooter_40maybe_41Code.GDgameoverObjects2= [];
gdjs.shooter_40maybe_41Code.GDgameoverObjects3= [];
gdjs.shooter_40maybe_41Code.GDendlessScoreObjects1= [];
gdjs.shooter_40maybe_41Code.GDendlessScoreObjects2= [];
gdjs.shooter_40maybe_41Code.GDendlessScoreObjects3= [];
gdjs.shooter_40maybe_41Code.GDgamestartObjects1= [];
gdjs.shooter_40maybe_41Code.GDgamestartObjects2= [];
gdjs.shooter_40maybe_41Code.GDgamestartObjects3= [];
gdjs.shooter_40maybe_41Code.GDRestartObjects1= [];
gdjs.shooter_40maybe_41Code.GDRestartObjects2= [];
gdjs.shooter_40maybe_41Code.GDRestartObjects3= [];
gdjs.shooter_40maybe_41Code.GDbridgeObjects1= [];
gdjs.shooter_40maybe_41Code.GDbridgeObjects2= [];
gdjs.shooter_40maybe_41Code.GDbridgeObjects3= [];
gdjs.shooter_40maybe_41Code.GDNewObjectObjects1= [];
gdjs.shooter_40maybe_41Code.GDNewObjectObjects2= [];
gdjs.shooter_40maybe_41Code.GDNewObjectObjects3= [];
gdjs.shooter_40maybe_41Code.GDNewObject3Objects1= [];
gdjs.shooter_40maybe_41Code.GDNewObject3Objects2= [];
gdjs.shooter_40maybe_41Code.GDNewObject3Objects3= [];
gdjs.shooter_40maybe_41Code.GDshroommidObjects1= [];
gdjs.shooter_40maybe_41Code.GDshroommidObjects2= [];
gdjs.shooter_40maybe_41Code.GDshroommidObjects3= [];
gdjs.shooter_40maybe_41Code.GDNewObject4Objects1= [];
gdjs.shooter_40maybe_41Code.GDNewObject4Objects2= [];
gdjs.shooter_40maybe_41Code.GDNewObject4Objects3= [];
gdjs.shooter_40maybe_41Code.GDshroomrightObjects1= [];
gdjs.shooter_40maybe_41Code.GDshroomrightObjects2= [];
gdjs.shooter_40maybe_41Code.GDshroomrightObjects3= [];
gdjs.shooter_40maybe_41Code.GDstem_95topObjects1= [];
gdjs.shooter_40maybe_41Code.GDstem_95topObjects2= [];
gdjs.shooter_40maybe_41Code.GDstem_95topObjects3= [];
gdjs.shooter_40maybe_41Code.GDbulletObjects1= [];
gdjs.shooter_40maybe_41Code.GDbulletObjects2= [];
gdjs.shooter_40maybe_41Code.GDbulletObjects3= [];
gdjs.shooter_40maybe_41Code.GDalienObjects1= [];
gdjs.shooter_40maybe_41Code.GDalienObjects2= [];
gdjs.shooter_40maybe_41Code.GDalienObjects3= [];
gdjs.shooter_40maybe_41Code.GDNewObject5Objects1= [];
gdjs.shooter_40maybe_41Code.GDNewObject5Objects2= [];
gdjs.shooter_40maybe_41Code.GDNewObject5Objects3= [];
gdjs.shooter_40maybe_41Code.GDOpening_95messaging_95boxObjects1= [];
gdjs.shooter_40maybe_41Code.GDOpening_95messaging_95boxObjects2= [];
gdjs.shooter_40maybe_41Code.GDOpening_95messaging_95boxObjects3= [];

gdjs.shooter_40maybe_41Code.conditionTrue_0 = {val:false};
gdjs.shooter_40maybe_41Code.condition0IsTrue_0 = {val:false};
gdjs.shooter_40maybe_41Code.condition1IsTrue_0 = {val:false};
gdjs.shooter_40maybe_41Code.condition2IsTrue_0 = {val:false};
gdjs.shooter_40maybe_41Code.condition3IsTrue_0 = {val:false};
gdjs.shooter_40maybe_41Code.conditionTrue_1 = {val:false};
gdjs.shooter_40maybe_41Code.condition0IsTrue_1 = {val:false};
gdjs.shooter_40maybe_41Code.condition1IsTrue_1 = {val:false};
gdjs.shooter_40maybe_41Code.condition2IsTrue_1 = {val:false};
gdjs.shooter_40maybe_41Code.condition3IsTrue_1 = {val:false};


gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.shooter_40maybe_41Code.GDCoinObjects2});gdjs.shooter_40maybe_41Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.shooter_40maybe_41Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects2Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDCoinObjects2Objects, false, runtimeScene, false);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDCoinObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.shooter_40maybe_41Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDScoreObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.shooter_40maybe_41Code.eventsList1 = function(runtimeScene) {

{


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].flipX(false);
}
}}

}


{


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( !(gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = true;
        gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[k] = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length = k;}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.shooter_40maybe_41Code.eventsList2 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[0].getPointY("")), 0.1), "", 0);
}}

}


};gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.shooter_40maybe_41Code.GDExitButtonObjects1});gdjs.shooter_40maybe_41Code.eventsList3 = function(runtimeScene) {

{


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.shooter_40maybe_41Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.shooter_40maybe_41Code.GDExitButtonObjects1);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDExitButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.shooter_40maybe_41Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.shooter_40maybe_41Code.GDDoor2Objects1});gdjs.shooter_40maybe_41Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.shooter_40maybe_41Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects1Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}{runtimeScene.getGame().getVariables().get("doorcount").setNumber(6);
}}

}


};gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDHaramPointObjects1Objects = Hashtable.newFrom({"HaramPoint": gdjs.shooter_40maybe_41Code.GDHaramPointObjects1});gdjs.shooter_40maybe_41Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HaramPoint"), gdjs.shooter_40maybe_41Code.GDHaramPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects1Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDHaramPointObjects1Objects, false, runtimeScene, false);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1 */
{gdjs.evtTools.sound.playMusic(runtimeScene, "life lost sound.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "shooter(maybe)", false);
}}

}


};gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.shooter_40maybe_41Code.GDbulletObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.shooter_40maybe_41Code.GDbulletObjects1});gdjs.shooter_40maybe_41Code.eventsList7 = function(runtimeScene) {

{


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Player_shoot_timer");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val = false;
gdjs.shooter_40maybe_41Code.condition2IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( !(gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].isFlippedX()) ) {
        gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val = true;
        gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[k] = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length = k;}if ( gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val ) {
{
gdjs.shooter_40maybe_41Code.condition2IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.35, "Player_shoot_timer");
}}
}
if (gdjs.shooter_40maybe_41Code.condition2IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2 */
gdjs.shooter_40maybe_41Code.GDbulletObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDbulletObjects2Objects, (( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length === 0 ) ? 0 :gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[0].getPointX("")) + 200, (( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length === 0 ) ? 0 :gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[0].getPointY("")) + 120, "");
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects2[i].addForce(2500, 0, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Player_shoot_timer");
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects2[i].setWidth(70);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects2[i].setHeight(20);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "25.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val = false;
gdjs.shooter_40maybe_41Code.condition2IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length;i<l;++i) {
    if ( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[i].isFlippedX() ) {
        gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val = true;
        gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[k] = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length = k;}if ( gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val ) {
{
gdjs.shooter_40maybe_41Code.condition2IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.35, "Player_shoot_timer");
}}
}
if (gdjs.shooter_40maybe_41Code.condition2IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1 */
gdjs.shooter_40maybe_41Code.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDbulletObjects1Objects, (( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[0].getPointX("")) + 100, (( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1[0].getPointY("")) + 120, "");
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects1[i].addForce(-(500), 0, 1);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects1[i].flipX(true);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Player_shoot_timer");
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects1[i].setHeight(20);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects1[i].setWidth(70);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "25.mp3", false, 100, 1);
}}

}


};gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects2Objects = Hashtable.newFrom({"alien": gdjs.shooter_40maybe_41Code.GDalienObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDenemyrightObjects2Objects = Hashtable.newFrom({"enemyright": gdjs.shooter_40maybe_41Code.GDenemyrightObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects2Objects = Hashtable.newFrom({"alien": gdjs.shooter_40maybe_41Code.GDalienObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDenemyLefyObjects2Objects = Hashtable.newFrom({"enemyLefy": gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects2Objects = Hashtable.newFrom({"alien": gdjs.shooter_40maybe_41Code.GDalienObjects2});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.shooter_40maybe_41Code.GDbulletObjects1});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects1Objects = Hashtable.newFrom({"alien": gdjs.shooter_40maybe_41Code.GDalienObjects1});gdjs.shooter_40maybe_41Code.eventsList8 = function(runtimeScene) {

{


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enemyLefy"), gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.shooter_40maybe_41Code.GDenemyrightObjects2);
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDenemyrightObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDenemyrightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("alien"), gdjs.shooter_40maybe_41Code.GDalienObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDalienObjects2.length;i<l;++i) {
    if ( gdjs.shooter_40maybe_41Code.GDalienObjects2[i].getVariableString(gdjs.shooter_40maybe_41Code.GDalienObjects2[i].getVariables().getFromIndex(0)) == "Left" ) {
        gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = true;
        gdjs.shooter_40maybe_41Code.GDalienObjects2[k] = gdjs.shooter_40maybe_41Code.GDalienObjects2[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDalienObjects2.length = k;}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDalienObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects2[i].addForce(-(40), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("alien"), gdjs.shooter_40maybe_41Code.GDalienObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDalienObjects2.length;i<l;++i) {
    if ( gdjs.shooter_40maybe_41Code.GDalienObjects2[i].getVariableString(gdjs.shooter_40maybe_41Code.GDalienObjects2[i].getVariables().getFromIndex(0)) == "Right" ) {
        gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = true;
        gdjs.shooter_40maybe_41Code.GDalienObjects2[k] = gdjs.shooter_40maybe_41Code.GDalienObjects2[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDalienObjects2.length = k;}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDalienObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects2[i].addForce(40, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("alien"), gdjs.shooter_40maybe_41Code.GDalienObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.shooter_40maybe_41Code.GDenemyrightObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects2Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDenemyrightObjects2Objects, false, runtimeScene, true);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDalienObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects2[i].flipX(true);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects2[i].returnVariable(gdjs.shooter_40maybe_41Code.GDalienObjects2[i].getVariables().getFromIndex(0)).setString("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("alien"), gdjs.shooter_40maybe_41Code.GDalienObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyLefy"), gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects2Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDenemyLefyObjects2Objects, false, runtimeScene, true);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDalienObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects2[i].flipX(false);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects2[i].returnVariable(gdjs.shooter_40maybe_41Code.GDalienObjects2[i].getVariables().getFromIndex(0)).setString("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("alien"), gdjs.shooter_40maybe_41Code.GDalienObjects2);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects2Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects2Objects, false, runtimeScene, true);
}if ( gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val = true;
        gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[k] = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.shooter_40maybe_41Code.condition1IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "shooter(maybe)", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("alien"), gdjs.shooter_40maybe_41Code.GDalienObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.shooter_40maybe_41Code.GDbulletObjects1);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDbulletObjects1Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDalienObjects1Objects, false, runtimeScene, true);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDalienObjects1 */
/* Reuse gdjs.shooter_40maybe_41Code.GDbulletObjects1 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDalienObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDalienObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}}

}


};gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1});gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDcoinGoldObjects1Objects = Hashtable.newFrom({"coinGold": gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1});gdjs.shooter_40maybe_41Code.eventsList9 = function(runtimeScene) {

{


gdjs.shooter_40maybe_41Code.eventsList0(runtimeScene);
}


{


gdjs.shooter_40maybe_41Code.eventsList1(runtimeScene);
}


{


gdjs.shooter_40maybe_41Code.eventsList2(runtimeScene);
}


{


gdjs.shooter_40maybe_41Code.eventsList4(runtimeScene);
}


{


gdjs.shooter_40maybe_41Code.eventsList5(runtimeScene);
}


{


gdjs.shooter_40maybe_41Code.eventsList6(runtimeScene);
}


{


{
}

}


{


gdjs.shooter_40maybe_41Code.eventsList7(runtimeScene);
}


{


gdjs.shooter_40maybe_41Code.eventsList8(runtimeScene);
}


{

gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length = 0;


gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
{gdjs.shooter_40maybe_41Code.conditionTrue_1 = gdjs.shooter_40maybe_41Code.condition0IsTrue_0;
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1_1final.length = 0;gdjs.shooter_40maybe_41Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2);
for(var i = 0, k = 0, l = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i].getY() >= 1000 ) {
        gdjs.shooter_40maybe_41Code.condition0IsTrue_1.val = true;
        gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[k] = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length = k;if( gdjs.shooter_40maybe_41Code.condition0IsTrue_1.val ) {
    gdjs.shooter_40maybe_41Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1_1final.push(gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1_1final, gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);
}
}
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "shooter(maybe)", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1);
gdjs.copyArray(runtimeScene.getObjects("coinGold"), gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1);

gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = false;
{
gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDSheikhSpeedObjects1Objects, gdjs.shooter_40maybe_41Code.mapOfGDgdjs_46shooter_9540maybe_9541Code_46GDcoinGoldObjects1Objects, false, runtimeScene, false);
}if (gdjs.shooter_40maybe_41Code.condition0IsTrue_0.val) {
/* Reuse gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1 */
{for(var i = 0, len = gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1.length ;i < len;++i) {
    gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(10);
}}

}


{


{
}

}


};

gdjs.shooter_40maybe_41Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDSheikhSpeedObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDCoinObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDCoinObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDCoinObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDScoreObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDScoreObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDScoreObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDHaramPointObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDHaramPointObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDHaramPointObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDExitButtonObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDExitButtonObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDExitButtonObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDGroundObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDGroundObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDGroundObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDladderObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDladderObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDladderObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDdirtLeftObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDdirtLeftObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDdirtLeftObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDDoor2Objects1.length = 0;
gdjs.shooter_40maybe_41Code.GDDoor2Objects2.length = 0;
gdjs.shooter_40maybe_41Code.GDDoor2Objects3.length = 0;
gdjs.shooter_40maybe_41Code.GDtopOfdoorObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDtopOfdoorObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDtopOfdoorObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDbridgelogsObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDbridgelogsObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDbridgelogsObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDcrookObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDcrookObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDcrookObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDenemyrightObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDenemyrightObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDenemyrightObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDenemyLefyObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDenemyLefyObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDenemyLefyObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject2Objects1.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject2Objects2.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject2Objects3.length = 0;
gdjs.shooter_40maybe_41Code.GDbackButtonObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDbackButtonObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDbackButtonObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDcoinGoldObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDcoinGoldObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDcoinGoldObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDbackgroundObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDbackgroundObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDbackgroundObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDgameoverObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDgameoverObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDgameoverObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDendlessScoreObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDendlessScoreObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDendlessScoreObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDgamestartObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDgamestartObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDgamestartObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDRestartObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDRestartObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDRestartObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDbridgeObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDbridgeObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDbridgeObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObjectObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObjectObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObjectObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject3Objects1.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject3Objects2.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject3Objects3.length = 0;
gdjs.shooter_40maybe_41Code.GDshroommidObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDshroommidObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDshroommidObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject4Objects1.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject4Objects2.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject4Objects3.length = 0;
gdjs.shooter_40maybe_41Code.GDshroomrightObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDshroomrightObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDshroomrightObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDstem_95topObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDstem_95topObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDstem_95topObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDbulletObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDbulletObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDbulletObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDalienObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDalienObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDalienObjects3.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject5Objects1.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject5Objects2.length = 0;
gdjs.shooter_40maybe_41Code.GDNewObject5Objects3.length = 0;
gdjs.shooter_40maybe_41Code.GDOpening_95messaging_95boxObjects1.length = 0;
gdjs.shooter_40maybe_41Code.GDOpening_95messaging_95boxObjects2.length = 0;
gdjs.shooter_40maybe_41Code.GDOpening_95messaging_95boxObjects3.length = 0;

gdjs.shooter_40maybe_41Code.eventsList9(runtimeScene);
return;

}

gdjs['shooter_40maybe_41Code'] = gdjs.shooter_40maybe_41Code;
