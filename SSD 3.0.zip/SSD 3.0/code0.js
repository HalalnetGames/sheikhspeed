gdjs.mainMenuCode = {};
gdjs.mainMenuCode.GDSheikhSpeedObjects1= [];
gdjs.mainMenuCode.GDSheikhSpeedObjects2= [];
gdjs.mainMenuCode.GDSheikhSpeedObjects3= [];
gdjs.mainMenuCode.GDCoinObjects1= [];
gdjs.mainMenuCode.GDCoinObjects2= [];
gdjs.mainMenuCode.GDCoinObjects3= [];
gdjs.mainMenuCode.GDScoreObjects1= [];
gdjs.mainMenuCode.GDScoreObjects2= [];
gdjs.mainMenuCode.GDScoreObjects3= [];
gdjs.mainMenuCode.GDHaramPointObjects1= [];
gdjs.mainMenuCode.GDHaramPointObjects2= [];
gdjs.mainMenuCode.GDHaramPointObjects3= [];
gdjs.mainMenuCode.GDExitButtonObjects1= [];
gdjs.mainMenuCode.GDExitButtonObjects2= [];
gdjs.mainMenuCode.GDExitButtonObjects3= [];
gdjs.mainMenuCode.GDGroundObjects1= [];
gdjs.mainMenuCode.GDGroundObjects2= [];
gdjs.mainMenuCode.GDGroundObjects3= [];
gdjs.mainMenuCode.GDladderObjects1= [];
gdjs.mainMenuCode.GDladderObjects2= [];
gdjs.mainMenuCode.GDladderObjects3= [];
gdjs.mainMenuCode.GDdirtLeftObjects1= [];
gdjs.mainMenuCode.GDdirtLeftObjects2= [];
gdjs.mainMenuCode.GDdirtLeftObjects3= [];
gdjs.mainMenuCode.GDDoor2Objects1= [];
gdjs.mainMenuCode.GDDoor2Objects2= [];
gdjs.mainMenuCode.GDDoor2Objects3= [];
gdjs.mainMenuCode.GDtopOfdoorObjects1= [];
gdjs.mainMenuCode.GDtopOfdoorObjects2= [];
gdjs.mainMenuCode.GDtopOfdoorObjects3= [];
gdjs.mainMenuCode.GDbridgelogsObjects1= [];
gdjs.mainMenuCode.GDbridgelogsObjects2= [];
gdjs.mainMenuCode.GDbridgelogsObjects3= [];
gdjs.mainMenuCode.GDcrookObjects1= [];
gdjs.mainMenuCode.GDcrookObjects2= [];
gdjs.mainMenuCode.GDcrookObjects3= [];
gdjs.mainMenuCode.GDenemyrightObjects1= [];
gdjs.mainMenuCode.GDenemyrightObjects2= [];
gdjs.mainMenuCode.GDenemyrightObjects3= [];
gdjs.mainMenuCode.GDenemyLefyObjects1= [];
gdjs.mainMenuCode.GDenemyLefyObjects2= [];
gdjs.mainMenuCode.GDenemyLefyObjects3= [];
gdjs.mainMenuCode.GDNewObject2Objects1= [];
gdjs.mainMenuCode.GDNewObject2Objects2= [];
gdjs.mainMenuCode.GDNewObject2Objects3= [];
gdjs.mainMenuCode.GDbackButtonObjects1= [];
gdjs.mainMenuCode.GDbackButtonObjects2= [];
gdjs.mainMenuCode.GDbackButtonObjects3= [];
gdjs.mainMenuCode.GDcoinGoldObjects1= [];
gdjs.mainMenuCode.GDcoinGoldObjects2= [];
gdjs.mainMenuCode.GDcoinGoldObjects3= [];
gdjs.mainMenuCode.GDbackgroundObjects1= [];
gdjs.mainMenuCode.GDbackgroundObjects2= [];
gdjs.mainMenuCode.GDbackgroundObjects3= [];
gdjs.mainMenuCode.GDgameoverObjects1= [];
gdjs.mainMenuCode.GDgameoverObjects2= [];
gdjs.mainMenuCode.GDgameoverObjects3= [];
gdjs.mainMenuCode.GDendlessScoreObjects1= [];
gdjs.mainMenuCode.GDendlessScoreObjects2= [];
gdjs.mainMenuCode.GDendlessScoreObjects3= [];
gdjs.mainMenuCode.GDgamestartObjects1= [];
gdjs.mainMenuCode.GDgamestartObjects2= [];
gdjs.mainMenuCode.GDgamestartObjects3= [];
gdjs.mainMenuCode.GDRestartObjects1= [];
gdjs.mainMenuCode.GDRestartObjects2= [];
gdjs.mainMenuCode.GDRestartObjects3= [];
gdjs.mainMenuCode.GDbridgeObjects1= [];
gdjs.mainMenuCode.GDbridgeObjects2= [];
gdjs.mainMenuCode.GDbridgeObjects3= [];
gdjs.mainMenuCode.GDStartButtonObjects1= [];
gdjs.mainMenuCode.GDStartButtonObjects2= [];
gdjs.mainMenuCode.GDStartButtonObjects3= [];
gdjs.mainMenuCode.GDislamicBackgroundObjects1= [];
gdjs.mainMenuCode.GDislamicBackgroundObjects2= [];
gdjs.mainMenuCode.GDislamicBackgroundObjects3= [];
gdjs.mainMenuCode.GDexitButtonObjects1= [];
gdjs.mainMenuCode.GDexitButtonObjects2= [];
gdjs.mainMenuCode.GDexitButtonObjects3= [];
gdjs.mainMenuCode.GDNewObjectObjects1= [];
gdjs.mainMenuCode.GDNewObjectObjects2= [];
gdjs.mainMenuCode.GDNewObjectObjects3= [];
gdjs.mainMenuCode.GDLogoObjects1= [];
gdjs.mainMenuCode.GDLogoObjects2= [];
gdjs.mainMenuCode.GDLogoObjects3= [];

gdjs.mainMenuCode.conditionTrue_0 = {val:false};
gdjs.mainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.mainMenuCode.condition1IsTrue_0 = {val:false};


gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDStartButtonObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.mainMenuCode.GDStartButtonObjects2});gdjs.mainMenuCode.eventsList0 = function(runtimeScene) {

{


gdjs.mainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.mainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}}

}


};gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDStartButtonObjects2Objects = Hashtable.newFrom({"StartButton": gdjs.mainMenuCode.GDStartButtonObjects2});gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDexitButtonObjects2Objects = Hashtable.newFrom({"exitButton": gdjs.mainMenuCode.GDexitButtonObjects2});gdjs.mainMenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.mainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.mainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Credits", false);
}}

}


};gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.mainMenuCode.GDexitButtonObjects1});gdjs.mainMenuCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.mainMenuCode.GDexitButtonObjects2);

gdjs.mainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDexitButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.mainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.mainMenuCode.GDexitButtonObjects2 */
{for(var i = 0, len = gdjs.mainMenuCode.GDexitButtonObjects2.length ;i < len;++i) {
    gdjs.mainMenuCode.GDexitButtonObjects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.mainMenuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.mainMenuCode.GDexitButtonObjects1);

gdjs.mainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDexitButtonObjects1Objects, runtimeScene, true, true);
}if (gdjs.mainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.mainMenuCode.GDexitButtonObjects1 */
{for(var i = 0, len = gdjs.mainMenuCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.mainMenuCode.GDexitButtonObjects1[i].setAnimation(0);
}
}}

}


};gdjs.mainMenuCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.mainMenuCode.GDStartButtonObjects2);

gdjs.mainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDStartButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.mainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.mainMenuCode.GDStartButtonObjects2 */
{for(var i = 0, len = gdjs.mainMenuCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.mainMenuCode.GDStartButtonObjects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.mainMenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.mainMenuCode.GDStartButtonObjects2);

gdjs.mainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.mainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.mainMenuCode.mapOfGDgdjs_46mainMenuCode_46GDStartButtonObjects2Objects, runtimeScene, true, true);
}if (gdjs.mainMenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.mainMenuCode.GDStartButtonObjects2 */
{for(var i = 0, len = gdjs.mainMenuCode.GDStartButtonObjects2.length ;i < len;++i) {
    gdjs.mainMenuCode.GDStartButtonObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.mainMenuCode.eventsList2(runtimeScene);
}


};gdjs.mainMenuCode.eventsList4 = function(runtimeScene) {

{


gdjs.mainMenuCode.eventsList3(runtimeScene);
}


};

gdjs.mainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.mainMenuCode.GDSheikhSpeedObjects1.length = 0;
gdjs.mainMenuCode.GDSheikhSpeedObjects2.length = 0;
gdjs.mainMenuCode.GDSheikhSpeedObjects3.length = 0;
gdjs.mainMenuCode.GDCoinObjects1.length = 0;
gdjs.mainMenuCode.GDCoinObjects2.length = 0;
gdjs.mainMenuCode.GDCoinObjects3.length = 0;
gdjs.mainMenuCode.GDScoreObjects1.length = 0;
gdjs.mainMenuCode.GDScoreObjects2.length = 0;
gdjs.mainMenuCode.GDScoreObjects3.length = 0;
gdjs.mainMenuCode.GDHaramPointObjects1.length = 0;
gdjs.mainMenuCode.GDHaramPointObjects2.length = 0;
gdjs.mainMenuCode.GDHaramPointObjects3.length = 0;
gdjs.mainMenuCode.GDExitButtonObjects1.length = 0;
gdjs.mainMenuCode.GDExitButtonObjects2.length = 0;
gdjs.mainMenuCode.GDExitButtonObjects3.length = 0;
gdjs.mainMenuCode.GDGroundObjects1.length = 0;
gdjs.mainMenuCode.GDGroundObjects2.length = 0;
gdjs.mainMenuCode.GDGroundObjects3.length = 0;
gdjs.mainMenuCode.GDladderObjects1.length = 0;
gdjs.mainMenuCode.GDladderObjects2.length = 0;
gdjs.mainMenuCode.GDladderObjects3.length = 0;
gdjs.mainMenuCode.GDdirtLeftObjects1.length = 0;
gdjs.mainMenuCode.GDdirtLeftObjects2.length = 0;
gdjs.mainMenuCode.GDdirtLeftObjects3.length = 0;
gdjs.mainMenuCode.GDDoor2Objects1.length = 0;
gdjs.mainMenuCode.GDDoor2Objects2.length = 0;
gdjs.mainMenuCode.GDDoor2Objects3.length = 0;
gdjs.mainMenuCode.GDtopOfdoorObjects1.length = 0;
gdjs.mainMenuCode.GDtopOfdoorObjects2.length = 0;
gdjs.mainMenuCode.GDtopOfdoorObjects3.length = 0;
gdjs.mainMenuCode.GDbridgelogsObjects1.length = 0;
gdjs.mainMenuCode.GDbridgelogsObjects2.length = 0;
gdjs.mainMenuCode.GDbridgelogsObjects3.length = 0;
gdjs.mainMenuCode.GDcrookObjects1.length = 0;
gdjs.mainMenuCode.GDcrookObjects2.length = 0;
gdjs.mainMenuCode.GDcrookObjects3.length = 0;
gdjs.mainMenuCode.GDenemyrightObjects1.length = 0;
gdjs.mainMenuCode.GDenemyrightObjects2.length = 0;
gdjs.mainMenuCode.GDenemyrightObjects3.length = 0;
gdjs.mainMenuCode.GDenemyLefyObjects1.length = 0;
gdjs.mainMenuCode.GDenemyLefyObjects2.length = 0;
gdjs.mainMenuCode.GDenemyLefyObjects3.length = 0;
gdjs.mainMenuCode.GDNewObject2Objects1.length = 0;
gdjs.mainMenuCode.GDNewObject2Objects2.length = 0;
gdjs.mainMenuCode.GDNewObject2Objects3.length = 0;
gdjs.mainMenuCode.GDbackButtonObjects1.length = 0;
gdjs.mainMenuCode.GDbackButtonObjects2.length = 0;
gdjs.mainMenuCode.GDbackButtonObjects3.length = 0;
gdjs.mainMenuCode.GDcoinGoldObjects1.length = 0;
gdjs.mainMenuCode.GDcoinGoldObjects2.length = 0;
gdjs.mainMenuCode.GDcoinGoldObjects3.length = 0;
gdjs.mainMenuCode.GDbackgroundObjects1.length = 0;
gdjs.mainMenuCode.GDbackgroundObjects2.length = 0;
gdjs.mainMenuCode.GDbackgroundObjects3.length = 0;
gdjs.mainMenuCode.GDgameoverObjects1.length = 0;
gdjs.mainMenuCode.GDgameoverObjects2.length = 0;
gdjs.mainMenuCode.GDgameoverObjects3.length = 0;
gdjs.mainMenuCode.GDendlessScoreObjects1.length = 0;
gdjs.mainMenuCode.GDendlessScoreObjects2.length = 0;
gdjs.mainMenuCode.GDendlessScoreObjects3.length = 0;
gdjs.mainMenuCode.GDgamestartObjects1.length = 0;
gdjs.mainMenuCode.GDgamestartObjects2.length = 0;
gdjs.mainMenuCode.GDgamestartObjects3.length = 0;
gdjs.mainMenuCode.GDRestartObjects1.length = 0;
gdjs.mainMenuCode.GDRestartObjects2.length = 0;
gdjs.mainMenuCode.GDRestartObjects3.length = 0;
gdjs.mainMenuCode.GDbridgeObjects1.length = 0;
gdjs.mainMenuCode.GDbridgeObjects2.length = 0;
gdjs.mainMenuCode.GDbridgeObjects3.length = 0;
gdjs.mainMenuCode.GDStartButtonObjects1.length = 0;
gdjs.mainMenuCode.GDStartButtonObjects2.length = 0;
gdjs.mainMenuCode.GDStartButtonObjects3.length = 0;
gdjs.mainMenuCode.GDislamicBackgroundObjects1.length = 0;
gdjs.mainMenuCode.GDislamicBackgroundObjects2.length = 0;
gdjs.mainMenuCode.GDislamicBackgroundObjects3.length = 0;
gdjs.mainMenuCode.GDexitButtonObjects1.length = 0;
gdjs.mainMenuCode.GDexitButtonObjects2.length = 0;
gdjs.mainMenuCode.GDexitButtonObjects3.length = 0;
gdjs.mainMenuCode.GDNewObjectObjects1.length = 0;
gdjs.mainMenuCode.GDNewObjectObjects2.length = 0;
gdjs.mainMenuCode.GDNewObjectObjects3.length = 0;
gdjs.mainMenuCode.GDLogoObjects1.length = 0;
gdjs.mainMenuCode.GDLogoObjects2.length = 0;
gdjs.mainMenuCode.GDLogoObjects3.length = 0;

gdjs.mainMenuCode.eventsList4(runtimeScene);
return;

}

gdjs['mainMenuCode'] = gdjs.mainMenuCode;
