gdjs.Endless_95levelCode = {};
gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final = [];

gdjs.Endless_95levelCode.GDSheikhSpeedObjects1= [];
gdjs.Endless_95levelCode.GDSheikhSpeedObjects2= [];
gdjs.Endless_95levelCode.GDSheikhSpeedObjects3= [];
gdjs.Endless_95levelCode.GDCoinObjects1= [];
gdjs.Endless_95levelCode.GDCoinObjects2= [];
gdjs.Endless_95levelCode.GDCoinObjects3= [];
gdjs.Endless_95levelCode.GDScoreObjects1= [];
gdjs.Endless_95levelCode.GDScoreObjects2= [];
gdjs.Endless_95levelCode.GDScoreObjects3= [];
gdjs.Endless_95levelCode.GDHaramPointObjects1= [];
gdjs.Endless_95levelCode.GDHaramPointObjects2= [];
gdjs.Endless_95levelCode.GDHaramPointObjects3= [];
gdjs.Endless_95levelCode.GDExitButtonObjects1= [];
gdjs.Endless_95levelCode.GDExitButtonObjects2= [];
gdjs.Endless_95levelCode.GDExitButtonObjects3= [];
gdjs.Endless_95levelCode.GDGroundObjects1= [];
gdjs.Endless_95levelCode.GDGroundObjects2= [];
gdjs.Endless_95levelCode.GDGroundObjects3= [];
gdjs.Endless_95levelCode.GDladderObjects1= [];
gdjs.Endless_95levelCode.GDladderObjects2= [];
gdjs.Endless_95levelCode.GDladderObjects3= [];
gdjs.Endless_95levelCode.GDdirtLeftObjects1= [];
gdjs.Endless_95levelCode.GDdirtLeftObjects2= [];
gdjs.Endless_95levelCode.GDdirtLeftObjects3= [];
gdjs.Endless_95levelCode.GDDoor2Objects1= [];
gdjs.Endless_95levelCode.GDDoor2Objects2= [];
gdjs.Endless_95levelCode.GDDoor2Objects3= [];
gdjs.Endless_95levelCode.GDtopOfdoorObjects1= [];
gdjs.Endless_95levelCode.GDtopOfdoorObjects2= [];
gdjs.Endless_95levelCode.GDtopOfdoorObjects3= [];
gdjs.Endless_95levelCode.GDbridgelogsObjects1= [];
gdjs.Endless_95levelCode.GDbridgelogsObjects2= [];
gdjs.Endless_95levelCode.GDbridgelogsObjects3= [];
gdjs.Endless_95levelCode.GDcrookObjects1= [];
gdjs.Endless_95levelCode.GDcrookObjects2= [];
gdjs.Endless_95levelCode.GDcrookObjects3= [];
gdjs.Endless_95levelCode.GDenemyrightObjects1= [];
gdjs.Endless_95levelCode.GDenemyrightObjects2= [];
gdjs.Endless_95levelCode.GDenemyrightObjects3= [];
gdjs.Endless_95levelCode.GDenemyLefyObjects1= [];
gdjs.Endless_95levelCode.GDenemyLefyObjects2= [];
gdjs.Endless_95levelCode.GDenemyLefyObjects3= [];
gdjs.Endless_95levelCode.GDNewObject2Objects1= [];
gdjs.Endless_95levelCode.GDNewObject2Objects2= [];
gdjs.Endless_95levelCode.GDNewObject2Objects3= [];
gdjs.Endless_95levelCode.GDbackButtonObjects1= [];
gdjs.Endless_95levelCode.GDbackButtonObjects2= [];
gdjs.Endless_95levelCode.GDbackButtonObjects3= [];
gdjs.Endless_95levelCode.GDcoinGoldObjects1= [];
gdjs.Endless_95levelCode.GDcoinGoldObjects2= [];
gdjs.Endless_95levelCode.GDcoinGoldObjects3= [];
gdjs.Endless_95levelCode.GDbackgroundObjects1= [];
gdjs.Endless_95levelCode.GDbackgroundObjects2= [];
gdjs.Endless_95levelCode.GDbackgroundObjects3= [];
gdjs.Endless_95levelCode.GDgameoverObjects1= [];
gdjs.Endless_95levelCode.GDgameoverObjects2= [];
gdjs.Endless_95levelCode.GDgameoverObjects3= [];
gdjs.Endless_95levelCode.GDendlessScoreObjects1= [];
gdjs.Endless_95levelCode.GDendlessScoreObjects2= [];
gdjs.Endless_95levelCode.GDendlessScoreObjects3= [];
gdjs.Endless_95levelCode.GDgamestartObjects1= [];
gdjs.Endless_95levelCode.GDgamestartObjects2= [];
gdjs.Endless_95levelCode.GDgamestartObjects3= [];
gdjs.Endless_95levelCode.GDRestartObjects1= [];
gdjs.Endless_95levelCode.GDRestartObjects2= [];
gdjs.Endless_95levelCode.GDRestartObjects3= [];
gdjs.Endless_95levelCode.GDbridgeObjects1= [];
gdjs.Endless_95levelCode.GDbridgeObjects2= [];
gdjs.Endless_95levelCode.GDbridgeObjects3= [];
gdjs.Endless_95levelCode.GDNewObjectObjects1= [];
gdjs.Endless_95levelCode.GDNewObjectObjects2= [];
gdjs.Endless_95levelCode.GDNewObjectObjects3= [];

gdjs.Endless_95levelCode.conditionTrue_0 = {val:false};
gdjs.Endless_95levelCode.condition0IsTrue_0 = {val:false};
gdjs.Endless_95levelCode.condition1IsTrue_0 = {val:false};
gdjs.Endless_95levelCode.condition2IsTrue_0 = {val:false};
gdjs.Endless_95levelCode.conditionTrue_1 = {val:false};
gdjs.Endless_95levelCode.condition0IsTrue_1 = {val:false};
gdjs.Endless_95levelCode.condition1IsTrue_1 = {val:false};
gdjs.Endless_95levelCode.condition2IsTrue_1 = {val:false};


gdjs.Endless_95levelCode.eventsList0 = function(runtimeScene) {

{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Endless_95levelCode.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("gameover"), gdjs.Endless_95levelCode.GDgameoverObjects1);
{runtimeScene.getVariables().get("EndlessState").setNumber(0);
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDgameoverObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDgameoverObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDRestartObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "enemy_count");
}}

}


};gdjs.Endless_95levelCode.eventsList1 = function(runtimeScene) {

{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects1);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Endless_95levelCode.condition0IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[k] = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length = k;}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDSheikhSpeedObjects1 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i].addPolarForce(0, 650, 0);
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}}

}


};gdjs.Endless_95levelCode.eventsList2 = function(runtimeScene) {

{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("EndlessState")) == 1;
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.Endless_95levelCode.GDGroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("endlessScore"), gdjs.Endless_95levelCode.GDendlessScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("gamestart"), gdjs.Endless_95levelCode.GDgamestartObjects1);
{for(var i = 0, len = gdjs.Endless_95levelCode.GDGroundObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDGroundObjects1[i].addPolarForce(180, 650, 0);
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDGroundObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDGroundObjects1[i].returnVariable(gdjs.Endless_95levelCode.GDGroundObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDendlessScoreObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDendlessScoreObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.Endless_95levelCode.GDGroundObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Endless_95levelCode.GDGroundObjects1[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDgamestartObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDgamestartObjects1[i].hide();
}
}
{ //Subevents
gdjs.Endless_95levelCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Endless_95levelCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.Endless_95levelCode.GDGroundObjects2);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDGroundObjects2.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDGroundObjects2[i].getX() <= -(200) ) {
        gdjs.Endless_95levelCode.condition0IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDGroundObjects2[k] = gdjs.Endless_95levelCode.GDGroundObjects2[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDGroundObjects2.length = k;}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDGroundObjects2 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDGroundObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDGroundObjects2[i].setX(4256);
}
}}

}


{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if ( gdjs.Endless_95levelCode.condition0IsTrue_0.val ) {
{
gdjs.Endless_95levelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("EndlessState")) == 0;
}}
if (gdjs.Endless_95levelCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().get("EndlessState").setNumber(1);
}}

}


};gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Endless_95levelCode.GDSheikhSpeedObjects1});gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDHaramPointObjects1Objects = Hashtable.newFrom({"HaramPoint": gdjs.Endless_95levelCode.GDHaramPointObjects1});gdjs.Endless_95levelCode.eventsList4 = function(runtimeScene) {

{

gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length = 0;


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
{gdjs.Endless_95levelCode.conditionTrue_1 = gdjs.Endless_95levelCode.condition0IsTrue_0;
gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final.length = 0;gdjs.Endless_95levelCode.condition0IsTrue_1.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects3);
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[i].getX() <= -(50) ) {
        gdjs.Endless_95levelCode.condition0IsTrue_1.val = true;
        gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[k] = gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length = k;if( gdjs.Endless_95levelCode.condition0IsTrue_1.val ) {
    gdjs.Endless_95levelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length;j<jLen;++j) {
        if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final.indexOf(gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[j]) === -1 )
            gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final.push(gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects3);
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[i].getY() >= 600 ) {
        gdjs.Endless_95levelCode.condition1IsTrue_1.val = true;
        gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[k] = gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length = k;if( gdjs.Endless_95levelCode.condition1IsTrue_1.val ) {
    gdjs.Endless_95levelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length;j<jLen;++j) {
        if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final.indexOf(gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[j]) === -1 )
            gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final.push(gdjs.Endless_95levelCode.GDSheikhSpeedObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Endless_95levelCode.GDSheikhSpeedObjects2_1final, gdjs.Endless_95levelCode.GDSheikhSpeedObjects2);
}
}
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Endless_95levelCode.GDRestartObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameover"), gdjs.Endless_95levelCode.GDgameoverObjects2);
{runtimeScene.getVariables().get("EndlessState").setNumber(2);
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDgameoverObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDgameoverObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDRestartObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDRestartObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HaramPoint"), gdjs.Endless_95levelCode.GDHaramPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects1);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDSheikhSpeedObjects1Objects, gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDHaramPointObjects1Objects, false, runtimeScene, false);
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("EndlessState").setNumber(2);
}}

}


};gdjs.Endless_95levelCode.eventsList5 = function(runtimeScene) {

{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("EndlessState")) == 2;
}if ( gdjs.Endless_95levelCode.condition0IsTrue_0.val ) {
{
gdjs.Endless_95levelCode.condition1IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}}
if (gdjs.Endless_95levelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Endless_level", true);
}{runtimeScene.getVariables().get("EndlessState").setNumber(2);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.Endless_95levelCode.GDcrookObjects1);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDcrookObjects1.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDcrookObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Endless_95levelCode.condition0IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDcrookObjects1[k] = gdjs.Endless_95levelCode.GDcrookObjects1[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDcrookObjects1.length = k;}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDcrookObjects1 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDcrookObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDcrookObjects1[i].addPolarForce(0, 0, 0);
}
}}

}


};gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDExitButtonObjects2Objects = Hashtable.newFrom({"ExitButton": gdjs.Endless_95levelCode.GDExitButtonObjects2});gdjs.Endless_95levelCode.eventsList6 = function(runtimeScene) {

{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects1Objects = Hashtable.newFrom({"crook": gdjs.Endless_95levelCode.GDcrookObjects1});gdjs.Endless_95levelCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.Endless_95levelCode.GDExitButtonObjects2);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDExitButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Endless_95levelCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.Endless_95levelCode.GDGroundObjects1);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDGroundObjects1.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDGroundObjects1[i].getX() == 4256 ) {
        gdjs.Endless_95levelCode.condition0IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDGroundObjects1[k] = gdjs.Endless_95levelCode.GDGroundObjects1[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDGroundObjects1.length = k;}if ( gdjs.Endless_95levelCode.condition0IsTrue_0.val ) {
{
gdjs.Endless_95levelCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "enemy_count");
}}
if (gdjs.Endless_95levelCode.condition1IsTrue_0.val) {
gdjs.Endless_95levelCode.GDcrookObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects1Objects, 2000, 300, "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "enemy_count");
}}

}


};gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.Endless_95levelCode.GDcrookObjects2});gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDenemyrightObjects2Objects = Hashtable.newFrom({"enemyright": gdjs.Endless_95levelCode.GDenemyrightObjects2});gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Endless_95levelCode.GDSheikhSpeedObjects2});gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.Endless_95levelCode.GDcrookObjects2});gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Endless_95levelCode.GDSheikhSpeedObjects2});gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.Endless_95levelCode.GDcrookObjects2});gdjs.Endless_95levelCode.eventsList8 = function(runtimeScene) {

{


gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enemyLefy"), gdjs.Endless_95levelCode.GDenemyLefyObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.Endless_95levelCode.GDenemyrightObjects2);
{for(var i = 0, len = gdjs.Endless_95levelCode.GDenemyrightObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDenemyrightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDenemyLefyObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDenemyLefyObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.Endless_95levelCode.GDcrookObjects2);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDcrookObjects2[i].getVariableString(gdjs.Endless_95levelCode.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Left" ) {
        gdjs.Endless_95levelCode.condition0IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDcrookObjects2[k] = gdjs.Endless_95levelCode.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDcrookObjects2.length = k;}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDcrookObjects2 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDcrookObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDcrookObjects2[i].addForce(-(40), 0, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.Endless_95levelCode.GDcrookObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.Endless_95levelCode.GDenemyrightObjects2);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects2Objects, gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDenemyrightObjects2Objects, false, runtimeScene, false);
}if (gdjs.Endless_95levelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDcrookObjects2 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDcrookObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDcrookObjects2[i].flipX(true);
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDcrookObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDcrookObjects2[i].returnVariable(gdjs.Endless_95levelCode.GDcrookObjects2[i].getVariables().getFromIndex(0)).setString("Right");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.Endless_95levelCode.GDcrookObjects2);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDSheikhSpeedObjects2Objects, gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Endless_95levelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Endless_95levelCode.condition1IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[k] = gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.Endless_95levelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Endless_level", true);
}{runtimeScene.getVariables().get("EndlessState").setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.Endless_95levelCode.GDcrookObjects2);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_0.val = false;
{
gdjs.Endless_95levelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDSheikhSpeedObjects2Objects, gdjs.Endless_95levelCode.mapOfGDgdjs_46Endless_9595levelCode_46GDcrookObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Endless_95levelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.Endless_95levelCode.condition1IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[k] = gdjs.Endless_95levelCode.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.Endless_95levelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDcrookObjects2 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDcrookObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDcrookObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Endless_95levelCode.GDcrookObjects2.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDcrookObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.Endless_95levelCode.GDGroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Endless_95levelCode.GDSheikhSpeedObjects1);

gdjs.Endless_95levelCode.condition0IsTrue_0.val = false;
gdjs.Endless_95levelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Endless_95levelCode.condition0IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[k] = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length = k;}if ( gdjs.Endless_95levelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Endless_95levelCode.GDGroundObjects1.length;i<l;++i) {
    if ( gdjs.Endless_95levelCode.GDGroundObjects1[i].getVariableNumber(gdjs.Endless_95levelCode.GDGroundObjects1[i].getVariables().get("Score")) >= 500 ) {
        gdjs.Endless_95levelCode.condition1IsTrue_0.val = true;
        gdjs.Endless_95levelCode.GDGroundObjects1[k] = gdjs.Endless_95levelCode.GDGroundObjects1[i];
        ++k;
    }
}
gdjs.Endless_95levelCode.GDGroundObjects1.length = k;}}
if (gdjs.Endless_95levelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Endless_95levelCode.GDSheikhSpeedObjects1 */
{for(var i = 0, len = gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Endless_95levelCode.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}}

}


};gdjs.Endless_95levelCode.eventsList9 = function(runtimeScene) {

{


{
}

}


{


gdjs.Endless_95levelCode.eventsList0(runtimeScene);
}


{


gdjs.Endless_95levelCode.eventsList2(runtimeScene);
}


{


gdjs.Endless_95levelCode.eventsList3(runtimeScene);
}


{


gdjs.Endless_95levelCode.eventsList4(runtimeScene);
}


{


gdjs.Endless_95levelCode.eventsList5(runtimeScene);
}


{



}


{


gdjs.Endless_95levelCode.eventsList7(runtimeScene);
}


{


gdjs.Endless_95levelCode.eventsList8(runtimeScene);
}


{


{
}

}


};

gdjs.Endless_95levelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Endless_95levelCode.GDSheikhSpeedObjects1.length = 0;
gdjs.Endless_95levelCode.GDSheikhSpeedObjects2.length = 0;
gdjs.Endless_95levelCode.GDSheikhSpeedObjects3.length = 0;
gdjs.Endless_95levelCode.GDCoinObjects1.length = 0;
gdjs.Endless_95levelCode.GDCoinObjects2.length = 0;
gdjs.Endless_95levelCode.GDCoinObjects3.length = 0;
gdjs.Endless_95levelCode.GDScoreObjects1.length = 0;
gdjs.Endless_95levelCode.GDScoreObjects2.length = 0;
gdjs.Endless_95levelCode.GDScoreObjects3.length = 0;
gdjs.Endless_95levelCode.GDHaramPointObjects1.length = 0;
gdjs.Endless_95levelCode.GDHaramPointObjects2.length = 0;
gdjs.Endless_95levelCode.GDHaramPointObjects3.length = 0;
gdjs.Endless_95levelCode.GDExitButtonObjects1.length = 0;
gdjs.Endless_95levelCode.GDExitButtonObjects2.length = 0;
gdjs.Endless_95levelCode.GDExitButtonObjects3.length = 0;
gdjs.Endless_95levelCode.GDGroundObjects1.length = 0;
gdjs.Endless_95levelCode.GDGroundObjects2.length = 0;
gdjs.Endless_95levelCode.GDGroundObjects3.length = 0;
gdjs.Endless_95levelCode.GDladderObjects1.length = 0;
gdjs.Endless_95levelCode.GDladderObjects2.length = 0;
gdjs.Endless_95levelCode.GDladderObjects3.length = 0;
gdjs.Endless_95levelCode.GDdirtLeftObjects1.length = 0;
gdjs.Endless_95levelCode.GDdirtLeftObjects2.length = 0;
gdjs.Endless_95levelCode.GDdirtLeftObjects3.length = 0;
gdjs.Endless_95levelCode.GDDoor2Objects1.length = 0;
gdjs.Endless_95levelCode.GDDoor2Objects2.length = 0;
gdjs.Endless_95levelCode.GDDoor2Objects3.length = 0;
gdjs.Endless_95levelCode.GDtopOfdoorObjects1.length = 0;
gdjs.Endless_95levelCode.GDtopOfdoorObjects2.length = 0;
gdjs.Endless_95levelCode.GDtopOfdoorObjects3.length = 0;
gdjs.Endless_95levelCode.GDbridgelogsObjects1.length = 0;
gdjs.Endless_95levelCode.GDbridgelogsObjects2.length = 0;
gdjs.Endless_95levelCode.GDbridgelogsObjects3.length = 0;
gdjs.Endless_95levelCode.GDcrookObjects1.length = 0;
gdjs.Endless_95levelCode.GDcrookObjects2.length = 0;
gdjs.Endless_95levelCode.GDcrookObjects3.length = 0;
gdjs.Endless_95levelCode.GDenemyrightObjects1.length = 0;
gdjs.Endless_95levelCode.GDenemyrightObjects2.length = 0;
gdjs.Endless_95levelCode.GDenemyrightObjects3.length = 0;
gdjs.Endless_95levelCode.GDenemyLefyObjects1.length = 0;
gdjs.Endless_95levelCode.GDenemyLefyObjects2.length = 0;
gdjs.Endless_95levelCode.GDenemyLefyObjects3.length = 0;
gdjs.Endless_95levelCode.GDNewObject2Objects1.length = 0;
gdjs.Endless_95levelCode.GDNewObject2Objects2.length = 0;
gdjs.Endless_95levelCode.GDNewObject2Objects3.length = 0;
gdjs.Endless_95levelCode.GDbackButtonObjects1.length = 0;
gdjs.Endless_95levelCode.GDbackButtonObjects2.length = 0;
gdjs.Endless_95levelCode.GDbackButtonObjects3.length = 0;
gdjs.Endless_95levelCode.GDcoinGoldObjects1.length = 0;
gdjs.Endless_95levelCode.GDcoinGoldObjects2.length = 0;
gdjs.Endless_95levelCode.GDcoinGoldObjects3.length = 0;
gdjs.Endless_95levelCode.GDbackgroundObjects1.length = 0;
gdjs.Endless_95levelCode.GDbackgroundObjects2.length = 0;
gdjs.Endless_95levelCode.GDbackgroundObjects3.length = 0;
gdjs.Endless_95levelCode.GDgameoverObjects1.length = 0;
gdjs.Endless_95levelCode.GDgameoverObjects2.length = 0;
gdjs.Endless_95levelCode.GDgameoverObjects3.length = 0;
gdjs.Endless_95levelCode.GDendlessScoreObjects1.length = 0;
gdjs.Endless_95levelCode.GDendlessScoreObjects2.length = 0;
gdjs.Endless_95levelCode.GDendlessScoreObjects3.length = 0;
gdjs.Endless_95levelCode.GDgamestartObjects1.length = 0;
gdjs.Endless_95levelCode.GDgamestartObjects2.length = 0;
gdjs.Endless_95levelCode.GDgamestartObjects3.length = 0;
gdjs.Endless_95levelCode.GDRestartObjects1.length = 0;
gdjs.Endless_95levelCode.GDRestartObjects2.length = 0;
gdjs.Endless_95levelCode.GDRestartObjects3.length = 0;
gdjs.Endless_95levelCode.GDbridgeObjects1.length = 0;
gdjs.Endless_95levelCode.GDbridgeObjects2.length = 0;
gdjs.Endless_95levelCode.GDbridgeObjects3.length = 0;
gdjs.Endless_95levelCode.GDNewObjectObjects1.length = 0;
gdjs.Endless_95levelCode.GDNewObjectObjects2.length = 0;
gdjs.Endless_95levelCode.GDNewObjectObjects3.length = 0;

gdjs.Endless_95levelCode.eventsList9(runtimeScene);
return;

}

gdjs['Endless_95levelCode'] = gdjs.Endless_95levelCode;
