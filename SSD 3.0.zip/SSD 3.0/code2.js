gdjs.Level1Code = {};
gdjs.Level1Code.GDSheikhSpeedObjects1_1final = [];

gdjs.Level1Code.GDSheikhSpeedObjects1= [];
gdjs.Level1Code.GDSheikhSpeedObjects2= [];
gdjs.Level1Code.GDSheikhSpeedObjects3= [];
gdjs.Level1Code.GDCoinObjects1= [];
gdjs.Level1Code.GDCoinObjects2= [];
gdjs.Level1Code.GDCoinObjects3= [];
gdjs.Level1Code.GDScoreObjects1= [];
gdjs.Level1Code.GDScoreObjects2= [];
gdjs.Level1Code.GDScoreObjects3= [];
gdjs.Level1Code.GDHaramPointObjects1= [];
gdjs.Level1Code.GDHaramPointObjects2= [];
gdjs.Level1Code.GDHaramPointObjects3= [];
gdjs.Level1Code.GDExitButtonObjects1= [];
gdjs.Level1Code.GDExitButtonObjects2= [];
gdjs.Level1Code.GDExitButtonObjects3= [];
gdjs.Level1Code.GDGroundObjects1= [];
gdjs.Level1Code.GDGroundObjects2= [];
gdjs.Level1Code.GDGroundObjects3= [];
gdjs.Level1Code.GDladderObjects1= [];
gdjs.Level1Code.GDladderObjects2= [];
gdjs.Level1Code.GDladderObjects3= [];
gdjs.Level1Code.GDdirtLeftObjects1= [];
gdjs.Level1Code.GDdirtLeftObjects2= [];
gdjs.Level1Code.GDdirtLeftObjects3= [];
gdjs.Level1Code.GDDoor2Objects1= [];
gdjs.Level1Code.GDDoor2Objects2= [];
gdjs.Level1Code.GDDoor2Objects3= [];
gdjs.Level1Code.GDtopOfdoorObjects1= [];
gdjs.Level1Code.GDtopOfdoorObjects2= [];
gdjs.Level1Code.GDtopOfdoorObjects3= [];
gdjs.Level1Code.GDbridgelogsObjects1= [];
gdjs.Level1Code.GDbridgelogsObjects2= [];
gdjs.Level1Code.GDbridgelogsObjects3= [];
gdjs.Level1Code.GDcrookObjects1= [];
gdjs.Level1Code.GDcrookObjects2= [];
gdjs.Level1Code.GDcrookObjects3= [];
gdjs.Level1Code.GDenemyrightObjects1= [];
gdjs.Level1Code.GDenemyrightObjects2= [];
gdjs.Level1Code.GDenemyrightObjects3= [];
gdjs.Level1Code.GDenemyLefyObjects1= [];
gdjs.Level1Code.GDenemyLefyObjects2= [];
gdjs.Level1Code.GDenemyLefyObjects3= [];
gdjs.Level1Code.GDNewObject2Objects1= [];
gdjs.Level1Code.GDNewObject2Objects2= [];
gdjs.Level1Code.GDNewObject2Objects3= [];
gdjs.Level1Code.GDbackButtonObjects1= [];
gdjs.Level1Code.GDbackButtonObjects2= [];
gdjs.Level1Code.GDbackButtonObjects3= [];
gdjs.Level1Code.GDcoinGoldObjects1= [];
gdjs.Level1Code.GDcoinGoldObjects2= [];
gdjs.Level1Code.GDcoinGoldObjects3= [];
gdjs.Level1Code.GDbackgroundObjects1= [];
gdjs.Level1Code.GDbackgroundObjects2= [];
gdjs.Level1Code.GDbackgroundObjects3= [];
gdjs.Level1Code.GDgameoverObjects1= [];
gdjs.Level1Code.GDgameoverObjects2= [];
gdjs.Level1Code.GDgameoverObjects3= [];
gdjs.Level1Code.GDendlessScoreObjects1= [];
gdjs.Level1Code.GDendlessScoreObjects2= [];
gdjs.Level1Code.GDendlessScoreObjects3= [];
gdjs.Level1Code.GDgamestartObjects1= [];
gdjs.Level1Code.GDgamestartObjects2= [];
gdjs.Level1Code.GDgamestartObjects3= [];
gdjs.Level1Code.GDRestartObjects1= [];
gdjs.Level1Code.GDRestartObjects2= [];
gdjs.Level1Code.GDRestartObjects3= [];
gdjs.Level1Code.GDbridgeObjects1= [];
gdjs.Level1Code.GDbridgeObjects2= [];
gdjs.Level1Code.GDbridgeObjects3= [];
gdjs.Level1Code.GDNewObjectObjects1= [];
gdjs.Level1Code.GDNewObjectObjects2= [];
gdjs.Level1Code.GDNewObjectObjects3= [];
gdjs.Level1Code.GDwelcomeBoxObjects1= [];
gdjs.Level1Code.GDwelcomeBoxObjects2= [];
gdjs.Level1Code.GDwelcomeBoxObjects3= [];
gdjs.Level1Code.GDNewObject2Objects1= [];
gdjs.Level1Code.GDNewObject2Objects2= [];
gdjs.Level1Code.GDNewObject2Objects3= [];
gdjs.Level1Code.GDNewObject3Objects1= [];
gdjs.Level1Code.GDNewObject3Objects2= [];
gdjs.Level1Code.GDNewObject3Objects3= [];
gdjs.Level1Code.GDWelcome_95msgBoxObjects1= [];
gdjs.Level1Code.GDWelcome_95msgBoxObjects2= [];
gdjs.Level1Code.GDWelcome_95msgBoxObjects3= [];
gdjs.Level1Code.GDBackgroundDayObjects1= [];
gdjs.Level1Code.GDBackgroundDayObjects2= [];
gdjs.Level1Code.GDBackgroundDayObjects3= [];
gdjs.Level1Code.GDdayBG_95extensionObjects1= [];
gdjs.Level1Code.GDdayBG_95extensionObjects2= [];
gdjs.Level1Code.GDdayBG_95extensionObjects3= [];
gdjs.Level1Code.GDLevel1FinishObjects1= [];
gdjs.Level1Code.GDLevel1FinishObjects2= [];
gdjs.Level1Code.GDLevel1FinishObjects3= [];

gdjs.Level1Code.conditionTrue_0 = {val:false};
gdjs.Level1Code.condition0IsTrue_0 = {val:false};
gdjs.Level1Code.condition1IsTrue_0 = {val:false};
gdjs.Level1Code.condition2IsTrue_0 = {val:false};
gdjs.Level1Code.condition3IsTrue_0 = {val:false};
gdjs.Level1Code.condition4IsTrue_0 = {val:false};
gdjs.Level1Code.conditionTrue_1 = {val:false};
gdjs.Level1Code.condition0IsTrue_1 = {val:false};
gdjs.Level1Code.condition1IsTrue_1 = {val:false};
gdjs.Level1Code.condition2IsTrue_1 = {val:false};
gdjs.Level1Code.condition3IsTrue_1 = {val:false};
gdjs.Level1Code.condition4IsTrue_1 = {val:false};
gdjs.Level1Code.conditionTrue_2 = {val:false};
gdjs.Level1Code.condition0IsTrue_2 = {val:false};
gdjs.Level1Code.condition1IsTrue_2 = {val:false};
gdjs.Level1Code.condition2IsTrue_2 = {val:false};
gdjs.Level1Code.condition3IsTrue_2 = {val:false};
gdjs.Level1Code.condition4IsTrue_2 = {val:false};


gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].flipX(false);
}
}}

}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level1Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.Level1Code.condition0IsTrue_0.val = true;
        gdjs.Level1Code.GDSheikhSpeedObjects2[k] = gdjs.Level1Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDSheikhSpeedObjects2.length = k;}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.Level1Code.eventsList1 = function(runtimeScene) {

{

gdjs.Level1Code.GDSheikhSpeedObjects1.length = 0;


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
{gdjs.Level1Code.conditionTrue_1 = gdjs.Level1Code.condition0IsTrue_0;
gdjs.Level1Code.GDSheikhSpeedObjects1_1final.length = 0;gdjs.Level1Code.condition0IsTrue_1.val = false;
gdjs.Level1Code.condition1IsTrue_1.val = false;
gdjs.Level1Code.condition2IsTrue_1.val = false;
gdjs.Level1Code.condition3IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
{gdjs.Level1Code.conditionTrue_2 = gdjs.Level1Code.condition0IsTrue_1;
gdjs.Level1Code.condition0IsTrue_2.val = false;
gdjs.Level1Code.condition1IsTrue_2.val = false;
{
gdjs.Level1Code.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs.Level1Code.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.Level1Code.condition1IsTrue_2.val = true;
        gdjs.Level1Code.GDSheikhSpeedObjects2[k] = gdjs.Level1Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDSheikhSpeedObjects2.length = k;}}
gdjs.Level1Code.conditionTrue_2.val = true && gdjs.Level1Code.condition0IsTrue_2.val && gdjs.Level1Code.condition1IsTrue_2.val;
}
if( gdjs.Level1Code.condition0IsTrue_1.val ) {
    gdjs.Level1Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.Level1Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.Level1Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.Level1Code.GDSheikhSpeedObjects1_1final.push(gdjs.Level1Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
{gdjs.Level1Code.conditionTrue_2 = gdjs.Level1Code.condition1IsTrue_1;
gdjs.Level1Code.condition0IsTrue_2.val = false;
gdjs.Level1Code.condition1IsTrue_2.val = false;
{
gdjs.Level1Code.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if ( gdjs.Level1Code.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.Level1Code.condition1IsTrue_2.val = true;
        gdjs.Level1Code.GDSheikhSpeedObjects2[k] = gdjs.Level1Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDSheikhSpeedObjects2.length = k;}}
gdjs.Level1Code.conditionTrue_2.val = true && gdjs.Level1Code.condition0IsTrue_2.val && gdjs.Level1Code.condition1IsTrue_2.val;
}
if( gdjs.Level1Code.condition1IsTrue_1.val ) {
    gdjs.Level1Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.Level1Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.Level1Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.Level1Code.GDSheikhSpeedObjects1_1final.push(gdjs.Level1Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
{gdjs.Level1Code.conditionTrue_2 = gdjs.Level1Code.condition2IsTrue_1;
gdjs.Level1Code.condition0IsTrue_2.val = false;
gdjs.Level1Code.condition1IsTrue_2.val = false;
{
gdjs.Level1Code.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if ( gdjs.Level1Code.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.Level1Code.condition1IsTrue_2.val = true;
        gdjs.Level1Code.GDSheikhSpeedObjects2[k] = gdjs.Level1Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDSheikhSpeedObjects2.length = k;}}
gdjs.Level1Code.conditionTrue_2.val = true && gdjs.Level1Code.condition0IsTrue_2.val && gdjs.Level1Code.condition1IsTrue_2.val;
}
if( gdjs.Level1Code.condition2IsTrue_1.val ) {
    gdjs.Level1Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.Level1Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.Level1Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.Level1Code.GDSheikhSpeedObjects1_1final.push(gdjs.Level1Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
{gdjs.Level1Code.conditionTrue_2 = gdjs.Level1Code.condition3IsTrue_1;
gdjs.Level1Code.condition0IsTrue_2.val = false;
gdjs.Level1Code.condition1IsTrue_2.val = false;
{
gdjs.Level1Code.condition0IsTrue_2.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if ( gdjs.Level1Code.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.Level1Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.Level1Code.condition1IsTrue_2.val = true;
        gdjs.Level1Code.GDSheikhSpeedObjects2[k] = gdjs.Level1Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDSheikhSpeedObjects2.length = k;}}
gdjs.Level1Code.conditionTrue_2.val = true && gdjs.Level1Code.condition0IsTrue_2.val && gdjs.Level1Code.condition1IsTrue_2.val;
}
if( gdjs.Level1Code.condition3IsTrue_1.val ) {
    gdjs.Level1Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.Level1Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.Level1Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.Level1Code.GDSheikhSpeedObjects1_1final.push(gdjs.Level1Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level1Code.GDSheikhSpeedObjects1_1final, gdjs.Level1Code.GDSheikhSpeedObjects1);
}
}
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDSheikhSpeedObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects1[i].setAnimation(4);
}
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects1[i].playAnimation();
}
}}

}


};gdjs.Level1Code.eventsList2 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.Level1Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDSheikhSpeedObjects1[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.Level1Code.GDSheikhSpeedObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDSheikhSpeedObjects1[0].getPointY("")), 0.1), "", 0);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Level1Code.GDSheikhSpeedObjects2});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level1Code.GDCoinObjects2});gdjs.Level1Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level1Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDCoinObjects2Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDCoinObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Level1Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDScoreObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.Level1Code.eventsList4 = function(runtimeScene) {

{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
}

}


};gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.Level1Code.GDExitButtonObjects1});gdjs.Level1Code.eventsList5 = function(runtimeScene) {

{


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.Level1Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.Level1Code.GDExitButtonObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDExitButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Level1Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Level1Code.GDSheikhSpeedObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.Level1Code.GDDoor2Objects1});gdjs.Level1Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.Level1Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Level1Code.GDSheikhSpeedObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDHaramPointObjects1Objects = Hashtable.newFrom({"HaramPoint": gdjs.Level1Code.GDHaramPointObjects1});gdjs.Level1Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HaramPoint"), gdjs.Level1Code.GDHaramPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDHaramPointObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level1Code.GDSheikhSpeedObjects1 */
{gdjs.evtTools.sound.playMusic(runtimeScene, "life lost sound.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.Level1Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDSheikhSpeedObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.Level1Code.GDSheikhSpeedObjects1});gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.Level1Code.GDDoor2Objects1});gdjs.Level1Code.eventsList9 = function(runtimeScene) {

{


gdjs.Level1Code.eventsList0(runtimeScene);
}


{


gdjs.Level1Code.eventsList1(runtimeScene);
}


{


gdjs.Level1Code.eventsList2(runtimeScene);
}


{


gdjs.Level1Code.eventsList3(runtimeScene);
}


{


gdjs.Level1Code.eventsList4(runtimeScene);
}


{


gdjs.Level1Code.eventsList6(runtimeScene);
}


{


gdjs.Level1Code.eventsList7(runtimeScene);
}


{


gdjs.Level1Code.eventsList8(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.Level1Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects1);

gdjs.Level1Code.condition0IsTrue_0.val = false;
{
gdjs.Level1Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDSheikhSpeedObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}}

}


{

gdjs.Level1Code.GDSheikhSpeedObjects1.length = 0;


gdjs.Level1Code.condition0IsTrue_0.val = false;
{
{gdjs.Level1Code.conditionTrue_1 = gdjs.Level1Code.condition0IsTrue_0;
gdjs.Level1Code.GDSheikhSpeedObjects1_1final.length = 0;gdjs.Level1Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.Level1Code.GDSheikhSpeedObjects2);
for(var i = 0, k = 0, l = gdjs.Level1Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDSheikhSpeedObjects2[i].getY() >= 1856 ) {
        gdjs.Level1Code.condition0IsTrue_1.val = true;
        gdjs.Level1Code.GDSheikhSpeedObjects2[k] = gdjs.Level1Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDSheikhSpeedObjects2.length = k;if( gdjs.Level1Code.condition0IsTrue_1.val ) {
    gdjs.Level1Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Level1Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.Level1Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.Level1Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.Level1Code.GDSheikhSpeedObjects1_1final.push(gdjs.Level1Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level1Code.GDSheikhSpeedObjects1_1final, gdjs.Level1Code.GDSheikhSpeedObjects1);
}
}
}if (gdjs.Level1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


{


{
}

}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDSheikhSpeedObjects1.length = 0;
gdjs.Level1Code.GDSheikhSpeedObjects2.length = 0;
gdjs.Level1Code.GDSheikhSpeedObjects3.length = 0;
gdjs.Level1Code.GDCoinObjects1.length = 0;
gdjs.Level1Code.GDCoinObjects2.length = 0;
gdjs.Level1Code.GDCoinObjects3.length = 0;
gdjs.Level1Code.GDScoreObjects1.length = 0;
gdjs.Level1Code.GDScoreObjects2.length = 0;
gdjs.Level1Code.GDScoreObjects3.length = 0;
gdjs.Level1Code.GDHaramPointObjects1.length = 0;
gdjs.Level1Code.GDHaramPointObjects2.length = 0;
gdjs.Level1Code.GDHaramPointObjects3.length = 0;
gdjs.Level1Code.GDExitButtonObjects1.length = 0;
gdjs.Level1Code.GDExitButtonObjects2.length = 0;
gdjs.Level1Code.GDExitButtonObjects3.length = 0;
gdjs.Level1Code.GDGroundObjects1.length = 0;
gdjs.Level1Code.GDGroundObjects2.length = 0;
gdjs.Level1Code.GDGroundObjects3.length = 0;
gdjs.Level1Code.GDladderObjects1.length = 0;
gdjs.Level1Code.GDladderObjects2.length = 0;
gdjs.Level1Code.GDladderObjects3.length = 0;
gdjs.Level1Code.GDdirtLeftObjects1.length = 0;
gdjs.Level1Code.GDdirtLeftObjects2.length = 0;
gdjs.Level1Code.GDdirtLeftObjects3.length = 0;
gdjs.Level1Code.GDDoor2Objects1.length = 0;
gdjs.Level1Code.GDDoor2Objects2.length = 0;
gdjs.Level1Code.GDDoor2Objects3.length = 0;
gdjs.Level1Code.GDtopOfdoorObjects1.length = 0;
gdjs.Level1Code.GDtopOfdoorObjects2.length = 0;
gdjs.Level1Code.GDtopOfdoorObjects3.length = 0;
gdjs.Level1Code.GDbridgelogsObjects1.length = 0;
gdjs.Level1Code.GDbridgelogsObjects2.length = 0;
gdjs.Level1Code.GDbridgelogsObjects3.length = 0;
gdjs.Level1Code.GDcrookObjects1.length = 0;
gdjs.Level1Code.GDcrookObjects2.length = 0;
gdjs.Level1Code.GDcrookObjects3.length = 0;
gdjs.Level1Code.GDenemyrightObjects1.length = 0;
gdjs.Level1Code.GDenemyrightObjects2.length = 0;
gdjs.Level1Code.GDenemyrightObjects3.length = 0;
gdjs.Level1Code.GDenemyLefyObjects1.length = 0;
gdjs.Level1Code.GDenemyLefyObjects2.length = 0;
gdjs.Level1Code.GDenemyLefyObjects3.length = 0;
gdjs.Level1Code.GDNewObject2Objects1.length = 0;
gdjs.Level1Code.GDNewObject2Objects2.length = 0;
gdjs.Level1Code.GDNewObject2Objects3.length = 0;
gdjs.Level1Code.GDbackButtonObjects1.length = 0;
gdjs.Level1Code.GDbackButtonObjects2.length = 0;
gdjs.Level1Code.GDbackButtonObjects3.length = 0;
gdjs.Level1Code.GDcoinGoldObjects1.length = 0;
gdjs.Level1Code.GDcoinGoldObjects2.length = 0;
gdjs.Level1Code.GDcoinGoldObjects3.length = 0;
gdjs.Level1Code.GDbackgroundObjects1.length = 0;
gdjs.Level1Code.GDbackgroundObjects2.length = 0;
gdjs.Level1Code.GDbackgroundObjects3.length = 0;
gdjs.Level1Code.GDgameoverObjects1.length = 0;
gdjs.Level1Code.GDgameoverObjects2.length = 0;
gdjs.Level1Code.GDgameoverObjects3.length = 0;
gdjs.Level1Code.GDendlessScoreObjects1.length = 0;
gdjs.Level1Code.GDendlessScoreObjects2.length = 0;
gdjs.Level1Code.GDendlessScoreObjects3.length = 0;
gdjs.Level1Code.GDgamestartObjects1.length = 0;
gdjs.Level1Code.GDgamestartObjects2.length = 0;
gdjs.Level1Code.GDgamestartObjects3.length = 0;
gdjs.Level1Code.GDRestartObjects1.length = 0;
gdjs.Level1Code.GDRestartObjects2.length = 0;
gdjs.Level1Code.GDRestartObjects3.length = 0;
gdjs.Level1Code.GDbridgeObjects1.length = 0;
gdjs.Level1Code.GDbridgeObjects2.length = 0;
gdjs.Level1Code.GDbridgeObjects3.length = 0;
gdjs.Level1Code.GDNewObjectObjects1.length = 0;
gdjs.Level1Code.GDNewObjectObjects2.length = 0;
gdjs.Level1Code.GDNewObjectObjects3.length = 0;
gdjs.Level1Code.GDwelcomeBoxObjects1.length = 0;
gdjs.Level1Code.GDwelcomeBoxObjects2.length = 0;
gdjs.Level1Code.GDwelcomeBoxObjects3.length = 0;
gdjs.Level1Code.GDNewObject2Objects1.length = 0;
gdjs.Level1Code.GDNewObject2Objects2.length = 0;
gdjs.Level1Code.GDNewObject2Objects3.length = 0;
gdjs.Level1Code.GDNewObject3Objects1.length = 0;
gdjs.Level1Code.GDNewObject3Objects2.length = 0;
gdjs.Level1Code.GDNewObject3Objects3.length = 0;
gdjs.Level1Code.GDWelcome_95msgBoxObjects1.length = 0;
gdjs.Level1Code.GDWelcome_95msgBoxObjects2.length = 0;
gdjs.Level1Code.GDWelcome_95msgBoxObjects3.length = 0;
gdjs.Level1Code.GDBackgroundDayObjects1.length = 0;
gdjs.Level1Code.GDBackgroundDayObjects2.length = 0;
gdjs.Level1Code.GDBackgroundDayObjects3.length = 0;
gdjs.Level1Code.GDdayBG_95extensionObjects1.length = 0;
gdjs.Level1Code.GDdayBG_95extensionObjects2.length = 0;
gdjs.Level1Code.GDdayBG_95extensionObjects3.length = 0;
gdjs.Level1Code.GDLevel1FinishObjects1.length = 0;
gdjs.Level1Code.GDLevel1FinishObjects2.length = 0;
gdjs.Level1Code.GDLevel1FinishObjects3.length = 0;

gdjs.Level1Code.eventsList9(runtimeScene);
return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
