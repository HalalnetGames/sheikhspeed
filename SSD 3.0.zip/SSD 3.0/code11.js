gdjs.lvl3_95secretCode = {};
gdjs.lvl3_95secretCode.GDSheikhSpeedObjects1= [];
gdjs.lvl3_95secretCode.GDSheikhSpeedObjects2= [];
gdjs.lvl3_95secretCode.GDCoinObjects1= [];
gdjs.lvl3_95secretCode.GDCoinObjects2= [];
gdjs.lvl3_95secretCode.GDScoreObjects1= [];
gdjs.lvl3_95secretCode.GDScoreObjects2= [];
gdjs.lvl3_95secretCode.GDHaramPointObjects1= [];
gdjs.lvl3_95secretCode.GDHaramPointObjects2= [];
gdjs.lvl3_95secretCode.GDExitButtonObjects1= [];
gdjs.lvl3_95secretCode.GDExitButtonObjects2= [];
gdjs.lvl3_95secretCode.GDGroundObjects1= [];
gdjs.lvl3_95secretCode.GDGroundObjects2= [];
gdjs.lvl3_95secretCode.GDladderObjects1= [];
gdjs.lvl3_95secretCode.GDladderObjects2= [];
gdjs.lvl3_95secretCode.GDdirtLeftObjects1= [];
gdjs.lvl3_95secretCode.GDdirtLeftObjects2= [];
gdjs.lvl3_95secretCode.GDDoor2Objects1= [];
gdjs.lvl3_95secretCode.GDDoor2Objects2= [];
gdjs.lvl3_95secretCode.GDtopOfdoorObjects1= [];
gdjs.lvl3_95secretCode.GDtopOfdoorObjects2= [];
gdjs.lvl3_95secretCode.GDbridgelogsObjects1= [];
gdjs.lvl3_95secretCode.GDbridgelogsObjects2= [];
gdjs.lvl3_95secretCode.GDcrookObjects1= [];
gdjs.lvl3_95secretCode.GDcrookObjects2= [];
gdjs.lvl3_95secretCode.GDenemyrightObjects1= [];
gdjs.lvl3_95secretCode.GDenemyrightObjects2= [];
gdjs.lvl3_95secretCode.GDenemyLefyObjects1= [];
gdjs.lvl3_95secretCode.GDenemyLefyObjects2= [];
gdjs.lvl3_95secretCode.GDNewObject2Objects1= [];
gdjs.lvl3_95secretCode.GDNewObject2Objects2= [];
gdjs.lvl3_95secretCode.GDbackButtonObjects1= [];
gdjs.lvl3_95secretCode.GDbackButtonObjects2= [];
gdjs.lvl3_95secretCode.GDcoinGoldObjects1= [];
gdjs.lvl3_95secretCode.GDcoinGoldObjects2= [];
gdjs.lvl3_95secretCode.GDbackgroundObjects1= [];
gdjs.lvl3_95secretCode.GDbackgroundObjects2= [];
gdjs.lvl3_95secretCode.GDgameoverObjects1= [];
gdjs.lvl3_95secretCode.GDgameoverObjects2= [];
gdjs.lvl3_95secretCode.GDendlessScoreObjects1= [];
gdjs.lvl3_95secretCode.GDendlessScoreObjects2= [];
gdjs.lvl3_95secretCode.GDgamestartObjects1= [];
gdjs.lvl3_95secretCode.GDgamestartObjects2= [];
gdjs.lvl3_95secretCode.GDRestartObjects1= [];
gdjs.lvl3_95secretCode.GDRestartObjects2= [];
gdjs.lvl3_95secretCode.GDbridgeObjects1= [];
gdjs.lvl3_95secretCode.GDbridgeObjects2= [];
gdjs.lvl3_95secretCode.GDbgObjects1= [];
gdjs.lvl3_95secretCode.GDbgObjects2= [];
gdjs.lvl3_95secretCode.GDNewObjectObjects1= [];
gdjs.lvl3_95secretCode.GDNewObjectObjects2= [];
gdjs.lvl3_95secretCode.GDendless_95unlockObjects1= [];
gdjs.lvl3_95secretCode.GDendless_95unlockObjects2= [];

gdjs.lvl3_95secretCode.conditionTrue_0 = {val:false};
gdjs.lvl3_95secretCode.condition0IsTrue_0 = {val:false};
gdjs.lvl3_95secretCode.condition1IsTrue_0 = {val:false};


gdjs.lvl3_95secretCode.mapOfGDgdjs_46lvl3_9595secretCode_46GDbackButtonObjects1Objects = Hashtable.newFrom({"backButton": gdjs.lvl3_95secretCode.GDbackButtonObjects1});gdjs.lvl3_95secretCode.eventsList0 = function(runtimeScene) {

{


gdjs.lvl3_95secretCode.condition0IsTrue_0.val = false;
{
gdjs.lvl3_95secretCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.lvl3_95secretCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.lvl3_95secretCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.lvl3_95secretCode.GDbackButtonObjects1);

gdjs.lvl3_95secretCode.condition0IsTrue_0.val = false;
{
gdjs.lvl3_95secretCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvl3_95secretCode.mapOfGDgdjs_46lvl3_9595secretCode_46GDbackButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.lvl3_95secretCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvl3_95secretCode.GDbackButtonObjects1 */
{for(var i = 0, len = gdjs.lvl3_95secretCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.lvl3_95secretCode.GDbackButtonObjects1[i].setAnimation(0);
}
}
{ //Subevents
gdjs.lvl3_95secretCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.lvl3_95secretCode.eventsList2 = function(runtimeScene) {

{


gdjs.lvl3_95secretCode.eventsList1(runtimeScene);
}


{


{
}

}


};

gdjs.lvl3_95secretCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl3_95secretCode.GDSheikhSpeedObjects1.length = 0;
gdjs.lvl3_95secretCode.GDSheikhSpeedObjects2.length = 0;
gdjs.lvl3_95secretCode.GDCoinObjects1.length = 0;
gdjs.lvl3_95secretCode.GDCoinObjects2.length = 0;
gdjs.lvl3_95secretCode.GDScoreObjects1.length = 0;
gdjs.lvl3_95secretCode.GDScoreObjects2.length = 0;
gdjs.lvl3_95secretCode.GDHaramPointObjects1.length = 0;
gdjs.lvl3_95secretCode.GDHaramPointObjects2.length = 0;
gdjs.lvl3_95secretCode.GDExitButtonObjects1.length = 0;
gdjs.lvl3_95secretCode.GDExitButtonObjects2.length = 0;
gdjs.lvl3_95secretCode.GDGroundObjects1.length = 0;
gdjs.lvl3_95secretCode.GDGroundObjects2.length = 0;
gdjs.lvl3_95secretCode.GDladderObjects1.length = 0;
gdjs.lvl3_95secretCode.GDladderObjects2.length = 0;
gdjs.lvl3_95secretCode.GDdirtLeftObjects1.length = 0;
gdjs.lvl3_95secretCode.GDdirtLeftObjects2.length = 0;
gdjs.lvl3_95secretCode.GDDoor2Objects1.length = 0;
gdjs.lvl3_95secretCode.GDDoor2Objects2.length = 0;
gdjs.lvl3_95secretCode.GDtopOfdoorObjects1.length = 0;
gdjs.lvl3_95secretCode.GDtopOfdoorObjects2.length = 0;
gdjs.lvl3_95secretCode.GDbridgelogsObjects1.length = 0;
gdjs.lvl3_95secretCode.GDbridgelogsObjects2.length = 0;
gdjs.lvl3_95secretCode.GDcrookObjects1.length = 0;
gdjs.lvl3_95secretCode.GDcrookObjects2.length = 0;
gdjs.lvl3_95secretCode.GDenemyrightObjects1.length = 0;
gdjs.lvl3_95secretCode.GDenemyrightObjects2.length = 0;
gdjs.lvl3_95secretCode.GDenemyLefyObjects1.length = 0;
gdjs.lvl3_95secretCode.GDenemyLefyObjects2.length = 0;
gdjs.lvl3_95secretCode.GDNewObject2Objects1.length = 0;
gdjs.lvl3_95secretCode.GDNewObject2Objects2.length = 0;
gdjs.lvl3_95secretCode.GDbackButtonObjects1.length = 0;
gdjs.lvl3_95secretCode.GDbackButtonObjects2.length = 0;
gdjs.lvl3_95secretCode.GDcoinGoldObjects1.length = 0;
gdjs.lvl3_95secretCode.GDcoinGoldObjects2.length = 0;
gdjs.lvl3_95secretCode.GDbackgroundObjects1.length = 0;
gdjs.lvl3_95secretCode.GDbackgroundObjects2.length = 0;
gdjs.lvl3_95secretCode.GDgameoverObjects1.length = 0;
gdjs.lvl3_95secretCode.GDgameoverObjects2.length = 0;
gdjs.lvl3_95secretCode.GDendlessScoreObjects1.length = 0;
gdjs.lvl3_95secretCode.GDendlessScoreObjects2.length = 0;
gdjs.lvl3_95secretCode.GDgamestartObjects1.length = 0;
gdjs.lvl3_95secretCode.GDgamestartObjects2.length = 0;
gdjs.lvl3_95secretCode.GDRestartObjects1.length = 0;
gdjs.lvl3_95secretCode.GDRestartObjects2.length = 0;
gdjs.lvl3_95secretCode.GDbridgeObjects1.length = 0;
gdjs.lvl3_95secretCode.GDbridgeObjects2.length = 0;
gdjs.lvl3_95secretCode.GDbgObjects1.length = 0;
gdjs.lvl3_95secretCode.GDbgObjects2.length = 0;
gdjs.lvl3_95secretCode.GDNewObjectObjects1.length = 0;
gdjs.lvl3_95secretCode.GDNewObjectObjects2.length = 0;
gdjs.lvl3_95secretCode.GDendless_95unlockObjects1.length = 0;
gdjs.lvl3_95secretCode.GDendless_95unlockObjects2.length = 0;

gdjs.lvl3_95secretCode.eventsList2(runtimeScene);
return;

}

gdjs['lvl3_95secretCode'] = gdjs.lvl3_95secretCode;
