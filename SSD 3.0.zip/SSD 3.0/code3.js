gdjs.level2Code = {};
gdjs.level2Code.GDSheikhSpeedObjects1_1final = [];

gdjs.level2Code.GDSheikhSpeedObjects1= [];
gdjs.level2Code.GDSheikhSpeedObjects2= [];
gdjs.level2Code.GDSheikhSpeedObjects3= [];
gdjs.level2Code.GDCoinObjects1= [];
gdjs.level2Code.GDCoinObjects2= [];
gdjs.level2Code.GDCoinObjects3= [];
gdjs.level2Code.GDScoreObjects1= [];
gdjs.level2Code.GDScoreObjects2= [];
gdjs.level2Code.GDScoreObjects3= [];
gdjs.level2Code.GDHaramPointObjects1= [];
gdjs.level2Code.GDHaramPointObjects2= [];
gdjs.level2Code.GDHaramPointObjects3= [];
gdjs.level2Code.GDExitButtonObjects1= [];
gdjs.level2Code.GDExitButtonObjects2= [];
gdjs.level2Code.GDExitButtonObjects3= [];
gdjs.level2Code.GDGroundObjects1= [];
gdjs.level2Code.GDGroundObjects2= [];
gdjs.level2Code.GDGroundObjects3= [];
gdjs.level2Code.GDladderObjects1= [];
gdjs.level2Code.GDladderObjects2= [];
gdjs.level2Code.GDladderObjects3= [];
gdjs.level2Code.GDdirtLeftObjects1= [];
gdjs.level2Code.GDdirtLeftObjects2= [];
gdjs.level2Code.GDdirtLeftObjects3= [];
gdjs.level2Code.GDDoor2Objects1= [];
gdjs.level2Code.GDDoor2Objects2= [];
gdjs.level2Code.GDDoor2Objects3= [];
gdjs.level2Code.GDtopOfdoorObjects1= [];
gdjs.level2Code.GDtopOfdoorObjects2= [];
gdjs.level2Code.GDtopOfdoorObjects3= [];
gdjs.level2Code.GDbridgelogsObjects1= [];
gdjs.level2Code.GDbridgelogsObjects2= [];
gdjs.level2Code.GDbridgelogsObjects3= [];
gdjs.level2Code.GDcrookObjects1= [];
gdjs.level2Code.GDcrookObjects2= [];
gdjs.level2Code.GDcrookObjects3= [];
gdjs.level2Code.GDenemyrightObjects1= [];
gdjs.level2Code.GDenemyrightObjects2= [];
gdjs.level2Code.GDenemyrightObjects3= [];
gdjs.level2Code.GDenemyLefyObjects1= [];
gdjs.level2Code.GDenemyLefyObjects2= [];
gdjs.level2Code.GDenemyLefyObjects3= [];
gdjs.level2Code.GDNewObject2Objects1= [];
gdjs.level2Code.GDNewObject2Objects2= [];
gdjs.level2Code.GDNewObject2Objects3= [];
gdjs.level2Code.GDbackButtonObjects1= [];
gdjs.level2Code.GDbackButtonObjects2= [];
gdjs.level2Code.GDbackButtonObjects3= [];
gdjs.level2Code.GDcoinGoldObjects1= [];
gdjs.level2Code.GDcoinGoldObjects2= [];
gdjs.level2Code.GDcoinGoldObjects3= [];
gdjs.level2Code.GDbackgroundObjects1= [];
gdjs.level2Code.GDbackgroundObjects2= [];
gdjs.level2Code.GDbackgroundObjects3= [];
gdjs.level2Code.GDgameoverObjects1= [];
gdjs.level2Code.GDgameoverObjects2= [];
gdjs.level2Code.GDgameoverObjects3= [];
gdjs.level2Code.GDendlessScoreObjects1= [];
gdjs.level2Code.GDendlessScoreObjects2= [];
gdjs.level2Code.GDendlessScoreObjects3= [];
gdjs.level2Code.GDgamestartObjects1= [];
gdjs.level2Code.GDgamestartObjects2= [];
gdjs.level2Code.GDgamestartObjects3= [];
gdjs.level2Code.GDRestartObjects1= [];
gdjs.level2Code.GDRestartObjects2= [];
gdjs.level2Code.GDRestartObjects3= [];
gdjs.level2Code.GDbridgeObjects1= [];
gdjs.level2Code.GDbridgeObjects2= [];
gdjs.level2Code.GDbridgeObjects3= [];
gdjs.level2Code.GDNewObjectObjects1= [];
gdjs.level2Code.GDNewObjectObjects2= [];
gdjs.level2Code.GDNewObjectObjects3= [];
gdjs.level2Code.GDNewObject2Objects1= [];
gdjs.level2Code.GDNewObject2Objects2= [];
gdjs.level2Code.GDNewObject2Objects3= [];
gdjs.level2Code.GDdirtCenterObjects1= [];
gdjs.level2Code.GDdirtCenterObjects2= [];
gdjs.level2Code.GDdirtCenterObjects3= [];
gdjs.level2Code.GDblockObjects1= [];
gdjs.level2Code.GDblockObjects2= [];
gdjs.level2Code.GDblockObjects3= [];
gdjs.level2Code.GDenemyBoxObjects1= [];
gdjs.level2Code.GDenemyBoxObjects2= [];
gdjs.level2Code.GDenemyBoxObjects3= [];

gdjs.level2Code.conditionTrue_0 = {val:false};
gdjs.level2Code.condition0IsTrue_0 = {val:false};
gdjs.level2Code.condition1IsTrue_0 = {val:false};
gdjs.level2Code.condition2IsTrue_0 = {val:false};
gdjs.level2Code.conditionTrue_1 = {val:false};
gdjs.level2Code.condition0IsTrue_1 = {val:false};
gdjs.level2Code.condition1IsTrue_1 = {val:false};
gdjs.level2Code.condition2IsTrue_1 = {val:false};


gdjs.level2Code.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.level2Code.GDSheikhSpeedObjects2.length === 0 ) ? 0 :gdjs.level2Code.GDSheikhSpeedObjects2[0].getPointX("")), 0.1), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.level2Code.GDSheikhSpeedObjects2.length === 0 ) ? 0 :gdjs.level2Code.GDSheikhSpeedObjects2[0].getPointY("")), 0.1), "", 0);
}}

}


{


{
}

}


};gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level2Code.GDSheikhSpeedObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.level2Code.GDCoinObjects2});gdjs.level2Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.level2Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects2Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDCoinObjects2Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDCoinObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "coin.wav", false, 40, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.level2Code.GDScoreObjects1);
{for(var i = 0, len = gdjs.level2Code.GDScoreObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDScoreObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.level2Code.GDcrookObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDenemyrightObjects2Objects = Hashtable.newFrom({"enemyright": gdjs.level2Code.GDenemyrightObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.level2Code.GDcrookObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDenemyLefyObjects2Objects = Hashtable.newFrom({"enemyLefy": gdjs.level2Code.GDenemyLefyObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects2Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level2Code.GDSheikhSpeedObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects2Objects = Hashtable.newFrom({"crook": gdjs.level2Code.GDcrookObjects2});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level2Code.GDSheikhSpeedObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects1Objects = Hashtable.newFrom({"crook": gdjs.level2Code.GDcrookObjects1});gdjs.level2Code.eventsList2 = function(runtimeScene) {

{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("enemyLefy"), gdjs.level2Code.GDenemyLefyObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.level2Code.GDenemyrightObjects2);
{for(var i = 0, len = gdjs.level2Code.GDenemyrightObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDenemyrightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.level2Code.GDenemyLefyObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDenemyLefyObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level2Code.GDcrookObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.level2Code.GDcrookObjects2[i].getVariableString(gdjs.level2Code.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Left" ) {
        gdjs.level2Code.condition0IsTrue_0.val = true;
        gdjs.level2Code.GDcrookObjects2[k] = gdjs.level2Code.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.level2Code.GDcrookObjects2.length = k;}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects2[i].addForce(-(40), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level2Code.GDcrookObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDcrookObjects2.length;i<l;++i) {
    if ( gdjs.level2Code.GDcrookObjects2[i].getVariableString(gdjs.level2Code.GDcrookObjects2[i].getVariables().getFromIndex(0)) == "Right" ) {
        gdjs.level2Code.condition0IsTrue_0.val = true;
        gdjs.level2Code.GDcrookObjects2[k] = gdjs.level2Code.GDcrookObjects2[i];
        ++k;
    }
}
gdjs.level2Code.GDcrookObjects2.length = k;}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects2[i].addForce(40, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level2Code.GDcrookObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyright"), gdjs.level2Code.GDenemyrightObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects2Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDenemyrightObjects2Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects2[i].flipX(true);
}
}{for(var i = 0, len = gdjs.level2Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects2[i].returnVariable(gdjs.level2Code.GDcrookObjects2[i].getVariables().getFromIndex(0)).setString("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level2Code.GDcrookObjects2);
gdjs.copyArray(runtimeScene.getObjects("enemyLefy"), gdjs.level2Code.GDenemyLefyObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects2Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDenemyLefyObjects2Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDcrookObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects2[i].flipX(false);
}
}{for(var i = 0, len = gdjs.level2Code.GDcrookObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects2[i].returnVariable(gdjs.level2Code.GDcrookObjects2[i].getVariables().getFromIndex(0)).setString("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level2Code.GDcrookObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
gdjs.level2Code.condition1IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects2Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects2Objects, false, runtimeScene, false);
}if ( gdjs.level2Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.level2Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.level2Code.condition1IsTrue_0.val = true;
        gdjs.level2Code.GDSheikhSpeedObjects2[k] = gdjs.level2Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level2Code.GDSheikhSpeedObjects2.length = k;}}
if (gdjs.level2Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level2", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects1);
gdjs.copyArray(runtimeScene.getObjects("crook"), gdjs.level2Code.GDcrookObjects1);

gdjs.level2Code.condition0IsTrue_0.val = false;
gdjs.level2Code.condition1IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDcrookObjects1Objects, false, runtimeScene, false);
}if ( gdjs.level2Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDSheikhSpeedObjects1.length;i<l;++i) {
    if ( gdjs.level2Code.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.level2Code.condition1IsTrue_0.val = true;
        gdjs.level2Code.GDSheikhSpeedObjects1[k] = gdjs.level2Code.GDSheikhSpeedObjects1[i];
        ++k;
    }
}
gdjs.level2Code.GDSheikhSpeedObjects1.length = k;}}
if (gdjs.level2Code.condition1IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDcrookObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDcrookObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level2Code.GDcrookObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDcrookObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level2Code.GDSheikhSpeedObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.level2Code.GDDoor2Objects1});gdjs.level2Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.level2Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects1);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}}

}


};gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level2Code.GDSheikhSpeedObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDHaramPointObjects1Objects = Hashtable.newFrom({"HaramPoint": gdjs.level2Code.GDHaramPointObjects1});gdjs.level2Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HaramPoint"), gdjs.level2Code.GDHaramPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects1);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDHaramPointObjects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDSheikhSpeedObjects1 */
{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "level2");
}}

}


};gdjs.level2Code.eventsList5 = function(runtimeScene) {

{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].flipX(false);
}
}}

}


{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);
{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.level2Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( !(gdjs.level2Code.GDSheikhSpeedObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.level2Code.condition0IsTrue_0.val = true;
        gdjs.level2Code.GDSheikhSpeedObjects2[k] = gdjs.level2Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level2Code.GDSheikhSpeedObjects2.length = k;}if (gdjs.level2Code.condition0IsTrue_0.val) {
/* Reuse gdjs.level2Code.GDSheikhSpeedObjects2 */
{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects2.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects2[i].setAnimation(0);
}
}}

}


{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.level2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects1);
{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.level2Code.GDSheikhSpeedObjects1.length ;i < len;++i) {
    gdjs.level2Code.GDSheikhSpeedObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


};gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDExitButtonObjects1Objects = Hashtable.newFrom({"ExitButton": gdjs.level2Code.GDExitButtonObjects1});gdjs.level2Code.eventsList6 = function(runtimeScene) {

{


gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.level2Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ExitButton"), gdjs.level2Code.GDExitButtonObjects1);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDExitButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.level2Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects = Hashtable.newFrom({"SheikhSpeed": gdjs.level2Code.GDSheikhSpeedObjects1});gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDDoor2Objects1Objects = Hashtable.newFrom({"Door2": gdjs.level2Code.GDDoor2Objects1});gdjs.level2Code.eventsList8 = function(runtimeScene) {

{


gdjs.level2Code.eventsList0(runtimeScene);
}


{


gdjs.level2Code.eventsList1(runtimeScene);
}


{


gdjs.level2Code.eventsList2(runtimeScene);
}


{


gdjs.level2Code.eventsList3(runtimeScene);
}


{


gdjs.level2Code.eventsList4(runtimeScene);
}


{


gdjs.level2Code.eventsList5(runtimeScene);
}


{


gdjs.level2Code.eventsList7(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Door2"), gdjs.level2Code.GDDoor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects1);

gdjs.level2Code.condition0IsTrue_0.val = false;
{
gdjs.level2Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDSheikhSpeedObjects1Objects, gdjs.level2Code.mapOfGDgdjs_46level2Code_46GDDoor2Objects1Objects, false, runtimeScene, false);
}if (gdjs.level2Code.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}}

}


{

gdjs.level2Code.GDSheikhSpeedObjects1.length = 0;


gdjs.level2Code.condition0IsTrue_0.val = false;
{
{gdjs.level2Code.conditionTrue_1 = gdjs.level2Code.condition0IsTrue_0;
gdjs.level2Code.GDSheikhSpeedObjects1_1final.length = 0;gdjs.level2Code.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("SheikhSpeed"), gdjs.level2Code.GDSheikhSpeedObjects2);
for(var i = 0, k = 0, l = gdjs.level2Code.GDSheikhSpeedObjects2.length;i<l;++i) {
    if ( gdjs.level2Code.GDSheikhSpeedObjects2[i].getY() >= 1000 ) {
        gdjs.level2Code.condition0IsTrue_1.val = true;
        gdjs.level2Code.GDSheikhSpeedObjects2[k] = gdjs.level2Code.GDSheikhSpeedObjects2[i];
        ++k;
    }
}
gdjs.level2Code.GDSheikhSpeedObjects2.length = k;if( gdjs.level2Code.condition0IsTrue_1.val ) {
    gdjs.level2Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.level2Code.GDSheikhSpeedObjects2.length;j<jLen;++j) {
        if ( gdjs.level2Code.GDSheikhSpeedObjects1_1final.indexOf(gdjs.level2Code.GDSheikhSpeedObjects2[j]) === -1 )
            gdjs.level2Code.GDSheikhSpeedObjects1_1final.push(gdjs.level2Code.GDSheikhSpeedObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.level2Code.GDSheikhSpeedObjects1_1final, gdjs.level2Code.GDSheikhSpeedObjects1);
}
}
}if (gdjs.level2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level2", false);
}}

}


{


{
}

}


};

gdjs.level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level2Code.GDSheikhSpeedObjects1.length = 0;
gdjs.level2Code.GDSheikhSpeedObjects2.length = 0;
gdjs.level2Code.GDSheikhSpeedObjects3.length = 0;
gdjs.level2Code.GDCoinObjects1.length = 0;
gdjs.level2Code.GDCoinObjects2.length = 0;
gdjs.level2Code.GDCoinObjects3.length = 0;
gdjs.level2Code.GDScoreObjects1.length = 0;
gdjs.level2Code.GDScoreObjects2.length = 0;
gdjs.level2Code.GDScoreObjects3.length = 0;
gdjs.level2Code.GDHaramPointObjects1.length = 0;
gdjs.level2Code.GDHaramPointObjects2.length = 0;
gdjs.level2Code.GDHaramPointObjects3.length = 0;
gdjs.level2Code.GDExitButtonObjects1.length = 0;
gdjs.level2Code.GDExitButtonObjects2.length = 0;
gdjs.level2Code.GDExitButtonObjects3.length = 0;
gdjs.level2Code.GDGroundObjects1.length = 0;
gdjs.level2Code.GDGroundObjects2.length = 0;
gdjs.level2Code.GDGroundObjects3.length = 0;
gdjs.level2Code.GDladderObjects1.length = 0;
gdjs.level2Code.GDladderObjects2.length = 0;
gdjs.level2Code.GDladderObjects3.length = 0;
gdjs.level2Code.GDdirtLeftObjects1.length = 0;
gdjs.level2Code.GDdirtLeftObjects2.length = 0;
gdjs.level2Code.GDdirtLeftObjects3.length = 0;
gdjs.level2Code.GDDoor2Objects1.length = 0;
gdjs.level2Code.GDDoor2Objects2.length = 0;
gdjs.level2Code.GDDoor2Objects3.length = 0;
gdjs.level2Code.GDtopOfdoorObjects1.length = 0;
gdjs.level2Code.GDtopOfdoorObjects2.length = 0;
gdjs.level2Code.GDtopOfdoorObjects3.length = 0;
gdjs.level2Code.GDbridgelogsObjects1.length = 0;
gdjs.level2Code.GDbridgelogsObjects2.length = 0;
gdjs.level2Code.GDbridgelogsObjects3.length = 0;
gdjs.level2Code.GDcrookObjects1.length = 0;
gdjs.level2Code.GDcrookObjects2.length = 0;
gdjs.level2Code.GDcrookObjects3.length = 0;
gdjs.level2Code.GDenemyrightObjects1.length = 0;
gdjs.level2Code.GDenemyrightObjects2.length = 0;
gdjs.level2Code.GDenemyrightObjects3.length = 0;
gdjs.level2Code.GDenemyLefyObjects1.length = 0;
gdjs.level2Code.GDenemyLefyObjects2.length = 0;
gdjs.level2Code.GDenemyLefyObjects3.length = 0;
gdjs.level2Code.GDNewObject2Objects1.length = 0;
gdjs.level2Code.GDNewObject2Objects2.length = 0;
gdjs.level2Code.GDNewObject2Objects3.length = 0;
gdjs.level2Code.GDbackButtonObjects1.length = 0;
gdjs.level2Code.GDbackButtonObjects2.length = 0;
gdjs.level2Code.GDbackButtonObjects3.length = 0;
gdjs.level2Code.GDcoinGoldObjects1.length = 0;
gdjs.level2Code.GDcoinGoldObjects2.length = 0;
gdjs.level2Code.GDcoinGoldObjects3.length = 0;
gdjs.level2Code.GDbackgroundObjects1.length = 0;
gdjs.level2Code.GDbackgroundObjects2.length = 0;
gdjs.level2Code.GDbackgroundObjects3.length = 0;
gdjs.level2Code.GDgameoverObjects1.length = 0;
gdjs.level2Code.GDgameoverObjects2.length = 0;
gdjs.level2Code.GDgameoverObjects3.length = 0;
gdjs.level2Code.GDendlessScoreObjects1.length = 0;
gdjs.level2Code.GDendlessScoreObjects2.length = 0;
gdjs.level2Code.GDendlessScoreObjects3.length = 0;
gdjs.level2Code.GDgamestartObjects1.length = 0;
gdjs.level2Code.GDgamestartObjects2.length = 0;
gdjs.level2Code.GDgamestartObjects3.length = 0;
gdjs.level2Code.GDRestartObjects1.length = 0;
gdjs.level2Code.GDRestartObjects2.length = 0;
gdjs.level2Code.GDRestartObjects3.length = 0;
gdjs.level2Code.GDbridgeObjects1.length = 0;
gdjs.level2Code.GDbridgeObjects2.length = 0;
gdjs.level2Code.GDbridgeObjects3.length = 0;
gdjs.level2Code.GDNewObjectObjects1.length = 0;
gdjs.level2Code.GDNewObjectObjects2.length = 0;
gdjs.level2Code.GDNewObjectObjects3.length = 0;
gdjs.level2Code.GDNewObject2Objects1.length = 0;
gdjs.level2Code.GDNewObject2Objects2.length = 0;
gdjs.level2Code.GDNewObject2Objects3.length = 0;
gdjs.level2Code.GDdirtCenterObjects1.length = 0;
gdjs.level2Code.GDdirtCenterObjects2.length = 0;
gdjs.level2Code.GDdirtCenterObjects3.length = 0;
gdjs.level2Code.GDblockObjects1.length = 0;
gdjs.level2Code.GDblockObjects2.length = 0;
gdjs.level2Code.GDblockObjects3.length = 0;
gdjs.level2Code.GDenemyBoxObjects1.length = 0;
gdjs.level2Code.GDenemyBoxObjects2.length = 0;
gdjs.level2Code.GDenemyBoxObjects3.length = 0;

gdjs.level2Code.eventsList8(runtimeScene);
return;

}

gdjs['level2Code'] = gdjs.level2Code;
