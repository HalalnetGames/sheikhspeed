gdjs.E_95selectorCode = {};
gdjs.E_95selectorCode.GDSheikhSpeedObjects1= [];
gdjs.E_95selectorCode.GDSheikhSpeedObjects2= [];
gdjs.E_95selectorCode.GDSheikhSpeedObjects3= [];
gdjs.E_95selectorCode.GDCoinObjects1= [];
gdjs.E_95selectorCode.GDCoinObjects2= [];
gdjs.E_95selectorCode.GDCoinObjects3= [];
gdjs.E_95selectorCode.GDScoreObjects1= [];
gdjs.E_95selectorCode.GDScoreObjects2= [];
gdjs.E_95selectorCode.GDScoreObjects3= [];
gdjs.E_95selectorCode.GDHaramPointObjects1= [];
gdjs.E_95selectorCode.GDHaramPointObjects2= [];
gdjs.E_95selectorCode.GDHaramPointObjects3= [];
gdjs.E_95selectorCode.GDExitButtonObjects1= [];
gdjs.E_95selectorCode.GDExitButtonObjects2= [];
gdjs.E_95selectorCode.GDExitButtonObjects3= [];
gdjs.E_95selectorCode.GDGroundObjects1= [];
gdjs.E_95selectorCode.GDGroundObjects2= [];
gdjs.E_95selectorCode.GDGroundObjects3= [];
gdjs.E_95selectorCode.GDladderObjects1= [];
gdjs.E_95selectorCode.GDladderObjects2= [];
gdjs.E_95selectorCode.GDladderObjects3= [];
gdjs.E_95selectorCode.GDdirtLeftObjects1= [];
gdjs.E_95selectorCode.GDdirtLeftObjects2= [];
gdjs.E_95selectorCode.GDdirtLeftObjects3= [];
gdjs.E_95selectorCode.GDDoor2Objects1= [];
gdjs.E_95selectorCode.GDDoor2Objects2= [];
gdjs.E_95selectorCode.GDDoor2Objects3= [];
gdjs.E_95selectorCode.GDtopOfdoorObjects1= [];
gdjs.E_95selectorCode.GDtopOfdoorObjects2= [];
gdjs.E_95selectorCode.GDtopOfdoorObjects3= [];
gdjs.E_95selectorCode.GDbridgelogsObjects1= [];
gdjs.E_95selectorCode.GDbridgelogsObjects2= [];
gdjs.E_95selectorCode.GDbridgelogsObjects3= [];
gdjs.E_95selectorCode.GDcrookObjects1= [];
gdjs.E_95selectorCode.GDcrookObjects2= [];
gdjs.E_95selectorCode.GDcrookObjects3= [];
gdjs.E_95selectorCode.GDenemyrightObjects1= [];
gdjs.E_95selectorCode.GDenemyrightObjects2= [];
gdjs.E_95selectorCode.GDenemyrightObjects3= [];
gdjs.E_95selectorCode.GDenemyLefyObjects1= [];
gdjs.E_95selectorCode.GDenemyLefyObjects2= [];
gdjs.E_95selectorCode.GDenemyLefyObjects3= [];
gdjs.E_95selectorCode.GDNewObject2Objects1= [];
gdjs.E_95selectorCode.GDNewObject2Objects2= [];
gdjs.E_95selectorCode.GDNewObject2Objects3= [];
gdjs.E_95selectorCode.GDbackButtonObjects1= [];
gdjs.E_95selectorCode.GDbackButtonObjects2= [];
gdjs.E_95selectorCode.GDbackButtonObjects3= [];
gdjs.E_95selectorCode.GDcoinGoldObjects1= [];
gdjs.E_95selectorCode.GDcoinGoldObjects2= [];
gdjs.E_95selectorCode.GDcoinGoldObjects3= [];
gdjs.E_95selectorCode.GDbackgroundObjects1= [];
gdjs.E_95selectorCode.GDbackgroundObjects2= [];
gdjs.E_95selectorCode.GDbackgroundObjects3= [];
gdjs.E_95selectorCode.GDgameoverObjects1= [];
gdjs.E_95selectorCode.GDgameoverObjects2= [];
gdjs.E_95selectorCode.GDgameoverObjects3= [];
gdjs.E_95selectorCode.GDendlessScoreObjects1= [];
gdjs.E_95selectorCode.GDendlessScoreObjects2= [];
gdjs.E_95selectorCode.GDendlessScoreObjects3= [];
gdjs.E_95selectorCode.GDgamestartObjects1= [];
gdjs.E_95selectorCode.GDgamestartObjects2= [];
gdjs.E_95selectorCode.GDgamestartObjects3= [];
gdjs.E_95selectorCode.GDRestartObjects1= [];
gdjs.E_95selectorCode.GDRestartObjects2= [];
gdjs.E_95selectorCode.GDRestartObjects3= [];
gdjs.E_95selectorCode.GDbridgeObjects1= [];
gdjs.E_95selectorCode.GDbridgeObjects2= [];
gdjs.E_95selectorCode.GDbridgeObjects3= [];
gdjs.E_95selectorCode.GDgrassButtonObjects1= [];
gdjs.E_95selectorCode.GDgrassButtonObjects2= [];
gdjs.E_95selectorCode.GDgrassButtonObjects3= [];
gdjs.E_95selectorCode.GDcaveButtonObjects1= [];
gdjs.E_95selectorCode.GDcaveButtonObjects2= [];
gdjs.E_95selectorCode.GDcaveButtonObjects3= [];
gdjs.E_95selectorCode.GDNewObjectObjects1= [];
gdjs.E_95selectorCode.GDNewObjectObjects2= [];
gdjs.E_95selectorCode.GDNewObjectObjects3= [];

gdjs.E_95selectorCode.conditionTrue_0 = {val:false};
gdjs.E_95selectorCode.condition0IsTrue_0 = {val:false};
gdjs.E_95selectorCode.condition1IsTrue_0 = {val:false};


gdjs.E_95selectorCode.mapOfGDgdjs_46E_9595selectorCode_46GDgrassButtonObjects2Objects = Hashtable.newFrom({"grassButton": gdjs.E_95selectorCode.GDgrassButtonObjects2});gdjs.E_95selectorCode.eventsList0 = function(runtimeScene) {

{


gdjs.E_95selectorCode.condition0IsTrue_0.val = false;
{
gdjs.E_95selectorCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.E_95selectorCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Endless_level", false);
}}

}


};gdjs.E_95selectorCode.mapOfGDgdjs_46E_9595selectorCode_46GDgrassButtonObjects1Objects = Hashtable.newFrom({"grassButton": gdjs.E_95selectorCode.GDgrassButtonObjects1});gdjs.E_95selectorCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("grassButton"), gdjs.E_95selectorCode.GDgrassButtonObjects2);

gdjs.E_95selectorCode.condition0IsTrue_0.val = false;
{
gdjs.E_95selectorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.E_95selectorCode.mapOfGDgdjs_46E_9595selectorCode_46GDgrassButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.E_95selectorCode.condition0IsTrue_0.val) {
/* Reuse gdjs.E_95selectorCode.GDgrassButtonObjects2 */
{for(var i = 0, len = gdjs.E_95selectorCode.GDgrassButtonObjects2.length ;i < len;++i) {
    gdjs.E_95selectorCode.GDgrassButtonObjects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.E_95selectorCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("grassButton"), gdjs.E_95selectorCode.GDgrassButtonObjects1);

gdjs.E_95selectorCode.condition0IsTrue_0.val = false;
{
gdjs.E_95selectorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.E_95selectorCode.mapOfGDgdjs_46E_9595selectorCode_46GDgrassButtonObjects1Objects, runtimeScene, true, true);
}if (gdjs.E_95selectorCode.condition0IsTrue_0.val) {
/* Reuse gdjs.E_95selectorCode.GDgrassButtonObjects1 */
{for(var i = 0, len = gdjs.E_95selectorCode.GDgrassButtonObjects1.length ;i < len;++i) {
    gdjs.E_95selectorCode.GDgrassButtonObjects1[i].setAnimation(0);
}
}}

}


};gdjs.E_95selectorCode.mapOfGDgdjs_46E_9595selectorCode_46GDbackButtonObjects1Objects = Hashtable.newFrom({"backButton": gdjs.E_95selectorCode.GDbackButtonObjects1});gdjs.E_95selectorCode.eventsList2 = function(runtimeScene) {

{


gdjs.E_95selectorCode.condition0IsTrue_0.val = false;
{
gdjs.E_95selectorCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.E_95selectorCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlSelect", false);
}}

}


};gdjs.E_95selectorCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.E_95selectorCode.GDbackButtonObjects1);

gdjs.E_95selectorCode.condition0IsTrue_0.val = false;
{
gdjs.E_95selectorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.E_95selectorCode.mapOfGDgdjs_46E_9595selectorCode_46GDbackButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.E_95selectorCode.condition0IsTrue_0.val) {
/* Reuse gdjs.E_95selectorCode.GDbackButtonObjects1 */
{for(var i = 0, len = gdjs.E_95selectorCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.E_95selectorCode.GDbackButtonObjects1[i].setAnimation(0);
}
}
{ //Subevents
gdjs.E_95selectorCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.E_95selectorCode.eventsList4 = function(runtimeScene) {

{


gdjs.E_95selectorCode.eventsList1(runtimeScene);
}


{


{
}

}


{


gdjs.E_95selectorCode.eventsList3(runtimeScene);
}


{


{
}

}


};

gdjs.E_95selectorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.E_95selectorCode.GDSheikhSpeedObjects1.length = 0;
gdjs.E_95selectorCode.GDSheikhSpeedObjects2.length = 0;
gdjs.E_95selectorCode.GDSheikhSpeedObjects3.length = 0;
gdjs.E_95selectorCode.GDCoinObjects1.length = 0;
gdjs.E_95selectorCode.GDCoinObjects2.length = 0;
gdjs.E_95selectorCode.GDCoinObjects3.length = 0;
gdjs.E_95selectorCode.GDScoreObjects1.length = 0;
gdjs.E_95selectorCode.GDScoreObjects2.length = 0;
gdjs.E_95selectorCode.GDScoreObjects3.length = 0;
gdjs.E_95selectorCode.GDHaramPointObjects1.length = 0;
gdjs.E_95selectorCode.GDHaramPointObjects2.length = 0;
gdjs.E_95selectorCode.GDHaramPointObjects3.length = 0;
gdjs.E_95selectorCode.GDExitButtonObjects1.length = 0;
gdjs.E_95selectorCode.GDExitButtonObjects2.length = 0;
gdjs.E_95selectorCode.GDExitButtonObjects3.length = 0;
gdjs.E_95selectorCode.GDGroundObjects1.length = 0;
gdjs.E_95selectorCode.GDGroundObjects2.length = 0;
gdjs.E_95selectorCode.GDGroundObjects3.length = 0;
gdjs.E_95selectorCode.GDladderObjects1.length = 0;
gdjs.E_95selectorCode.GDladderObjects2.length = 0;
gdjs.E_95selectorCode.GDladderObjects3.length = 0;
gdjs.E_95selectorCode.GDdirtLeftObjects1.length = 0;
gdjs.E_95selectorCode.GDdirtLeftObjects2.length = 0;
gdjs.E_95selectorCode.GDdirtLeftObjects3.length = 0;
gdjs.E_95selectorCode.GDDoor2Objects1.length = 0;
gdjs.E_95selectorCode.GDDoor2Objects2.length = 0;
gdjs.E_95selectorCode.GDDoor2Objects3.length = 0;
gdjs.E_95selectorCode.GDtopOfdoorObjects1.length = 0;
gdjs.E_95selectorCode.GDtopOfdoorObjects2.length = 0;
gdjs.E_95selectorCode.GDtopOfdoorObjects3.length = 0;
gdjs.E_95selectorCode.GDbridgelogsObjects1.length = 0;
gdjs.E_95selectorCode.GDbridgelogsObjects2.length = 0;
gdjs.E_95selectorCode.GDbridgelogsObjects3.length = 0;
gdjs.E_95selectorCode.GDcrookObjects1.length = 0;
gdjs.E_95selectorCode.GDcrookObjects2.length = 0;
gdjs.E_95selectorCode.GDcrookObjects3.length = 0;
gdjs.E_95selectorCode.GDenemyrightObjects1.length = 0;
gdjs.E_95selectorCode.GDenemyrightObjects2.length = 0;
gdjs.E_95selectorCode.GDenemyrightObjects3.length = 0;
gdjs.E_95selectorCode.GDenemyLefyObjects1.length = 0;
gdjs.E_95selectorCode.GDenemyLefyObjects2.length = 0;
gdjs.E_95selectorCode.GDenemyLefyObjects3.length = 0;
gdjs.E_95selectorCode.GDNewObject2Objects1.length = 0;
gdjs.E_95selectorCode.GDNewObject2Objects2.length = 0;
gdjs.E_95selectorCode.GDNewObject2Objects3.length = 0;
gdjs.E_95selectorCode.GDbackButtonObjects1.length = 0;
gdjs.E_95selectorCode.GDbackButtonObjects2.length = 0;
gdjs.E_95selectorCode.GDbackButtonObjects3.length = 0;
gdjs.E_95selectorCode.GDcoinGoldObjects1.length = 0;
gdjs.E_95selectorCode.GDcoinGoldObjects2.length = 0;
gdjs.E_95selectorCode.GDcoinGoldObjects3.length = 0;
gdjs.E_95selectorCode.GDbackgroundObjects1.length = 0;
gdjs.E_95selectorCode.GDbackgroundObjects2.length = 0;
gdjs.E_95selectorCode.GDbackgroundObjects3.length = 0;
gdjs.E_95selectorCode.GDgameoverObjects1.length = 0;
gdjs.E_95selectorCode.GDgameoverObjects2.length = 0;
gdjs.E_95selectorCode.GDgameoverObjects3.length = 0;
gdjs.E_95selectorCode.GDendlessScoreObjects1.length = 0;
gdjs.E_95selectorCode.GDendlessScoreObjects2.length = 0;
gdjs.E_95selectorCode.GDendlessScoreObjects3.length = 0;
gdjs.E_95selectorCode.GDgamestartObjects1.length = 0;
gdjs.E_95selectorCode.GDgamestartObjects2.length = 0;
gdjs.E_95selectorCode.GDgamestartObjects3.length = 0;
gdjs.E_95selectorCode.GDRestartObjects1.length = 0;
gdjs.E_95selectorCode.GDRestartObjects2.length = 0;
gdjs.E_95selectorCode.GDRestartObjects3.length = 0;
gdjs.E_95selectorCode.GDbridgeObjects1.length = 0;
gdjs.E_95selectorCode.GDbridgeObjects2.length = 0;
gdjs.E_95selectorCode.GDbridgeObjects3.length = 0;
gdjs.E_95selectorCode.GDgrassButtonObjects1.length = 0;
gdjs.E_95selectorCode.GDgrassButtonObjects2.length = 0;
gdjs.E_95selectorCode.GDgrassButtonObjects3.length = 0;
gdjs.E_95selectorCode.GDcaveButtonObjects1.length = 0;
gdjs.E_95selectorCode.GDcaveButtonObjects2.length = 0;
gdjs.E_95selectorCode.GDcaveButtonObjects3.length = 0;
gdjs.E_95selectorCode.GDNewObjectObjects1.length = 0;
gdjs.E_95selectorCode.GDNewObjectObjects2.length = 0;
gdjs.E_95selectorCode.GDNewObjectObjects3.length = 0;

gdjs.E_95selectorCode.eventsList4(runtimeScene);
return;

}

gdjs['E_95selectorCode'] = gdjs.E_95selectorCode;
