gdjs.lvlSelectCode = {};
gdjs.lvlSelectCode.GDSheikhSpeedObjects1= [];
gdjs.lvlSelectCode.GDSheikhSpeedObjects2= [];
gdjs.lvlSelectCode.GDSheikhSpeedObjects3= [];
gdjs.lvlSelectCode.GDSheikhSpeedObjects4= [];
gdjs.lvlSelectCode.GDCoinObjects1= [];
gdjs.lvlSelectCode.GDCoinObjects2= [];
gdjs.lvlSelectCode.GDCoinObjects3= [];
gdjs.lvlSelectCode.GDCoinObjects4= [];
gdjs.lvlSelectCode.GDScoreObjects1= [];
gdjs.lvlSelectCode.GDScoreObjects2= [];
gdjs.lvlSelectCode.GDScoreObjects3= [];
gdjs.lvlSelectCode.GDScoreObjects4= [];
gdjs.lvlSelectCode.GDHaramPointObjects1= [];
gdjs.lvlSelectCode.GDHaramPointObjects2= [];
gdjs.lvlSelectCode.GDHaramPointObjects3= [];
gdjs.lvlSelectCode.GDHaramPointObjects4= [];
gdjs.lvlSelectCode.GDExitButtonObjects1= [];
gdjs.lvlSelectCode.GDExitButtonObjects2= [];
gdjs.lvlSelectCode.GDExitButtonObjects3= [];
gdjs.lvlSelectCode.GDExitButtonObjects4= [];
gdjs.lvlSelectCode.GDGroundObjects1= [];
gdjs.lvlSelectCode.GDGroundObjects2= [];
gdjs.lvlSelectCode.GDGroundObjects3= [];
gdjs.lvlSelectCode.GDGroundObjects4= [];
gdjs.lvlSelectCode.GDladderObjects1= [];
gdjs.lvlSelectCode.GDladderObjects2= [];
gdjs.lvlSelectCode.GDladderObjects3= [];
gdjs.lvlSelectCode.GDladderObjects4= [];
gdjs.lvlSelectCode.GDdirtLeftObjects1= [];
gdjs.lvlSelectCode.GDdirtLeftObjects2= [];
gdjs.lvlSelectCode.GDdirtLeftObjects3= [];
gdjs.lvlSelectCode.GDdirtLeftObjects4= [];
gdjs.lvlSelectCode.GDDoor2Objects1= [];
gdjs.lvlSelectCode.GDDoor2Objects2= [];
gdjs.lvlSelectCode.GDDoor2Objects3= [];
gdjs.lvlSelectCode.GDDoor2Objects4= [];
gdjs.lvlSelectCode.GDtopOfdoorObjects1= [];
gdjs.lvlSelectCode.GDtopOfdoorObjects2= [];
gdjs.lvlSelectCode.GDtopOfdoorObjects3= [];
gdjs.lvlSelectCode.GDtopOfdoorObjects4= [];
gdjs.lvlSelectCode.GDbridgelogsObjects1= [];
gdjs.lvlSelectCode.GDbridgelogsObjects2= [];
gdjs.lvlSelectCode.GDbridgelogsObjects3= [];
gdjs.lvlSelectCode.GDbridgelogsObjects4= [];
gdjs.lvlSelectCode.GDcrookObjects1= [];
gdjs.lvlSelectCode.GDcrookObjects2= [];
gdjs.lvlSelectCode.GDcrookObjects3= [];
gdjs.lvlSelectCode.GDcrookObjects4= [];
gdjs.lvlSelectCode.GDenemyrightObjects1= [];
gdjs.lvlSelectCode.GDenemyrightObjects2= [];
gdjs.lvlSelectCode.GDenemyrightObjects3= [];
gdjs.lvlSelectCode.GDenemyrightObjects4= [];
gdjs.lvlSelectCode.GDenemyLefyObjects1= [];
gdjs.lvlSelectCode.GDenemyLefyObjects2= [];
gdjs.lvlSelectCode.GDenemyLefyObjects3= [];
gdjs.lvlSelectCode.GDenemyLefyObjects4= [];
gdjs.lvlSelectCode.GDNewObject2Objects1= [];
gdjs.lvlSelectCode.GDNewObject2Objects2= [];
gdjs.lvlSelectCode.GDNewObject2Objects3= [];
gdjs.lvlSelectCode.GDNewObject2Objects4= [];
gdjs.lvlSelectCode.GDbackButtonObjects1= [];
gdjs.lvlSelectCode.GDbackButtonObjects2= [];
gdjs.lvlSelectCode.GDbackButtonObjects3= [];
gdjs.lvlSelectCode.GDbackButtonObjects4= [];
gdjs.lvlSelectCode.GDcoinGoldObjects1= [];
gdjs.lvlSelectCode.GDcoinGoldObjects2= [];
gdjs.lvlSelectCode.GDcoinGoldObjects3= [];
gdjs.lvlSelectCode.GDcoinGoldObjects4= [];
gdjs.lvlSelectCode.GDbackgroundObjects1= [];
gdjs.lvlSelectCode.GDbackgroundObjects2= [];
gdjs.lvlSelectCode.GDbackgroundObjects3= [];
gdjs.lvlSelectCode.GDbackgroundObjects4= [];
gdjs.lvlSelectCode.GDgameoverObjects1= [];
gdjs.lvlSelectCode.GDgameoverObjects2= [];
gdjs.lvlSelectCode.GDgameoverObjects3= [];
gdjs.lvlSelectCode.GDgameoverObjects4= [];
gdjs.lvlSelectCode.GDendlessScoreObjects1= [];
gdjs.lvlSelectCode.GDendlessScoreObjects2= [];
gdjs.lvlSelectCode.GDendlessScoreObjects3= [];
gdjs.lvlSelectCode.GDendlessScoreObjects4= [];
gdjs.lvlSelectCode.GDgamestartObjects1= [];
gdjs.lvlSelectCode.GDgamestartObjects2= [];
gdjs.lvlSelectCode.GDgamestartObjects3= [];
gdjs.lvlSelectCode.GDgamestartObjects4= [];
gdjs.lvlSelectCode.GDRestartObjects1= [];
gdjs.lvlSelectCode.GDRestartObjects2= [];
gdjs.lvlSelectCode.GDRestartObjects3= [];
gdjs.lvlSelectCode.GDRestartObjects4= [];
gdjs.lvlSelectCode.GDbridgeObjects1= [];
gdjs.lvlSelectCode.GDbridgeObjects2= [];
gdjs.lvlSelectCode.GDbridgeObjects3= [];
gdjs.lvlSelectCode.GDbridgeObjects4= [];
gdjs.lvlSelectCode.GDL1_951Objects1= [];
gdjs.lvlSelectCode.GDL1_951Objects2= [];
gdjs.lvlSelectCode.GDL1_951Objects3= [];
gdjs.lvlSelectCode.GDL1_951Objects4= [];
gdjs.lvlSelectCode.GDL1_952Objects1= [];
gdjs.lvlSelectCode.GDL1_952Objects2= [];
gdjs.lvlSelectCode.GDL1_952Objects3= [];
gdjs.lvlSelectCode.GDL1_952Objects4= [];
gdjs.lvlSelectCode.GDlvlselect_95textObjects1= [];
gdjs.lvlSelectCode.GDlvlselect_95textObjects2= [];
gdjs.lvlSelectCode.GDlvlselect_95textObjects3= [];
gdjs.lvlSelectCode.GDlvlselect_95textObjects4= [];
gdjs.lvlSelectCode.GDL1_953Objects1= [];
gdjs.lvlSelectCode.GDL1_953Objects2= [];
gdjs.lvlSelectCode.GDL1_953Objects3= [];
gdjs.lvlSelectCode.GDL1_953Objects4= [];
gdjs.lvlSelectCode.GDendlessObjects1= [];
gdjs.lvlSelectCode.GDendlessObjects2= [];
gdjs.lvlSelectCode.GDendlessObjects3= [];
gdjs.lvlSelectCode.GDendlessObjects4= [];
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects1= [];
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects2= [];
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects3= [];
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects4= [];
gdjs.lvlSelectCode.GDNewObjectObjects1= [];
gdjs.lvlSelectCode.GDNewObjectObjects2= [];
gdjs.lvlSelectCode.GDNewObjectObjects3= [];
gdjs.lvlSelectCode.GDNewObjectObjects4= [];
gdjs.lvlSelectCode.GDNewObject3Objects1= [];
gdjs.lvlSelectCode.GDNewObject3Objects2= [];
gdjs.lvlSelectCode.GDNewObject3Objects3= [];
gdjs.lvlSelectCode.GDNewObject3Objects4= [];

gdjs.lvlSelectCode.conditionTrue_0 = {val:false};
gdjs.lvlSelectCode.condition0IsTrue_0 = {val:false};
gdjs.lvlSelectCode.condition1IsTrue_0 = {val:false};
gdjs.lvlSelectCode.condition2IsTrue_0 = {val:false};


gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95951Objects2Objects = Hashtable.newFrom({"L1_1": gdjs.lvlSelectCode.GDL1_951Objects2});gdjs.lvlSelectCode.eventsList0 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95951Objects1Objects = Hashtable.newFrom({"L1_1": gdjs.lvlSelectCode.GDL1_951Objects1});gdjs.lvlSelectCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("L1_1"), gdjs.lvlSelectCode.GDL1_951Objects2);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95951Objects2Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDL1_951Objects2 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDL1_951Objects2.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDL1_951Objects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("L1_1"), gdjs.lvlSelectCode.GDL1_951Objects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95951Objects1Objects, runtimeScene, true, true);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDL1_951Objects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDL1_951Objects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDL1_951Objects1[i].setAnimation(0);
}
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95952Objects2Objects = Hashtable.newFrom({"L1_2": gdjs.lvlSelectCode.GDL1_952Objects2});gdjs.lvlSelectCode.eventsList2 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
gdjs.lvlSelectCode.condition1IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lvlSelectCode.condition0IsTrue_0.val ) {
{
gdjs.lvlSelectCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= 1;
}}
if (gdjs.lvlSelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level2", false);
}}

}


{


{
}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95952Objects1Objects = Hashtable.newFrom({"L1_2": gdjs.lvlSelectCode.GDL1_952Objects1});gdjs.lvlSelectCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("L1_2"), gdjs.lvlSelectCode.GDL1_952Objects2);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95952Objects2Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDL1_952Objects2 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDL1_952Objects2.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDL1_952Objects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("L1_2"), gdjs.lvlSelectCode.GDL1_952Objects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95952Objects1Objects, runtimeScene, true, true);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDL1_952Objects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDL1_952Objects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDL1_952Objects1[i].setAnimation(0);
}
}}

}


};gdjs.lvlSelectCode.eventsList4 = function(runtimeScene) {

{


{
}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95953Objects1Objects = Hashtable.newFrom({"L1_3": gdjs.lvlSelectCode.GDL1_953Objects1});gdjs.lvlSelectCode.eventsList5 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
gdjs.lvlSelectCode.condition1IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lvlSelectCode.condition0IsTrue_0.val ) {
{
gdjs.lvlSelectCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= 2;
}}
if (gdjs.lvlSelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level3", false);
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95953Objects1Objects = Hashtable.newFrom({"L1_3": gdjs.lvlSelectCode.GDL1_953Objects1});gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDbackButtonObjects1Objects = Hashtable.newFrom({"backButton": gdjs.lvlSelectCode.GDbackButtonObjects1});gdjs.lvlSelectCode.eventsList6 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mainMenu", false);
}}

}


};gdjs.lvlSelectCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.lvlSelectCode.GDbackButtonObjects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDbackButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDbackButtonObjects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDbackButtonObjects1[i].setAnimation(0);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDendlessObjects2Objects = Hashtable.newFrom({"endless": gdjs.lvlSelectCode.GDendlessObjects2});gdjs.lvlSelectCode.eventsList8 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
gdjs.lvlSelectCode.condition1IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lvlSelectCode.condition0IsTrue_0.val ) {
{
gdjs.lvlSelectCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) >= 1;
}}
if (gdjs.lvlSelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "E_selector", false);
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDendlessObjects1Objects = Hashtable.newFrom({"endless": gdjs.lvlSelectCode.GDendlessObjects1});gdjs.lvlSelectCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("endless"), gdjs.lvlSelectCode.GDendlessObjects2);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDendlessObjects2Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDendlessObjects2 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDendlessObjects2.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDendlessObjects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("endless"), gdjs.lvlSelectCode.GDendlessObjects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDendlessObjects1Objects, runtimeScene, true, true);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDendlessObjects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDendlessObjects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDendlessObjects1[i].setAnimation(0);
}
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObjectObjects2Objects = Hashtable.newFrom({"NewObject": gdjs.lvlSelectCode.GDNewObjectObjects2});gdjs.lvlSelectCode.eventsList10 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
gdjs.lvlSelectCode.condition1IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lvlSelectCode.condition0IsTrue_0.val ) {
{
gdjs.lvlSelectCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= 3;
}}
if (gdjs.lvlSelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl4", false);
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObjectObjects1Objects = Hashtable.newFrom({"NewObject": gdjs.lvlSelectCode.GDNewObjectObjects1});gdjs.lvlSelectCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.lvlSelectCode.GDNewObjectObjects2);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObjectObjects2Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDNewObjectObjects2 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDNewObjectObjects2.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDNewObjectObjects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.lvlSelectCode.GDNewObjectObjects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObjectObjects1Objects, runtimeScene, true, true);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDNewObjectObjects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDNewObjectObjects1[i].setAnimation(0);
}
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObject3Objects2Objects = Hashtable.newFrom({"NewObject3": gdjs.lvlSelectCode.GDNewObject3Objects2});gdjs.lvlSelectCode.eventsList12 = function(runtimeScene) {

{


gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
gdjs.lvlSelectCode.condition1IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.lvlSelectCode.condition0IsTrue_0.val ) {
{
gdjs.lvlSelectCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) >= 4;
}}
if (gdjs.lvlSelectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "shooter(maybe)", false);
}}

}


};gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObject3Objects1Objects = Hashtable.newFrom({"NewObject3": gdjs.lvlSelectCode.GDNewObject3Objects1});gdjs.lvlSelectCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.lvlSelectCode.GDNewObject3Objects2);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObject3Objects2Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDNewObject3Objects2 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDNewObject3Objects2.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDNewObject3Objects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewObject3"), gdjs.lvlSelectCode.GDNewObject3Objects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDNewObject3Objects1Objects, runtimeScene, true, true);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDNewObject3Objects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDNewObject3Objects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDNewObject3Objects1[i].setAnimation(0);
}
}}

}


};gdjs.lvlSelectCode.eventsList14 = function(runtimeScene) {

{


gdjs.lvlSelectCode.eventsList1(runtimeScene);
}


{


gdjs.lvlSelectCode.eventsList3(runtimeScene);
}


{


gdjs.lvlSelectCode.eventsList4(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("L1_3"), gdjs.lvlSelectCode.GDL1_953Objects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95953Objects1Objects, runtimeScene, true, false);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDL1_953Objects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDL1_953Objects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDL1_953Objects1[i].setAnimation(1);
}
}
{ //Subevents
gdjs.lvlSelectCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("L1_3"), gdjs.lvlSelectCode.GDL1_953Objects1);

gdjs.lvlSelectCode.condition0IsTrue_0.val = false;
{
gdjs.lvlSelectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.lvlSelectCode.mapOfGDgdjs_46lvlSelectCode_46GDL1_95953Objects1Objects, runtimeScene, true, true);
}if (gdjs.lvlSelectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.lvlSelectCode.GDL1_953Objects1 */
{for(var i = 0, len = gdjs.lvlSelectCode.GDL1_953Objects1.length ;i < len;++i) {
    gdjs.lvlSelectCode.GDL1_953Objects1[i].setAnimation(0);
}
}}

}


{


{
}

}


{


gdjs.lvlSelectCode.eventsList7(runtimeScene);
}


{


gdjs.lvlSelectCode.eventsList9(runtimeScene);
}


{


{
}

}


{


gdjs.lvlSelectCode.eventsList11(runtimeScene);
}


{


gdjs.lvlSelectCode.eventsList13(runtimeScene);
}


{


{
}

}


};

gdjs.lvlSelectCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvlSelectCode.GDSheikhSpeedObjects1.length = 0;
gdjs.lvlSelectCode.GDSheikhSpeedObjects2.length = 0;
gdjs.lvlSelectCode.GDSheikhSpeedObjects3.length = 0;
gdjs.lvlSelectCode.GDSheikhSpeedObjects4.length = 0;
gdjs.lvlSelectCode.GDCoinObjects1.length = 0;
gdjs.lvlSelectCode.GDCoinObjects2.length = 0;
gdjs.lvlSelectCode.GDCoinObjects3.length = 0;
gdjs.lvlSelectCode.GDCoinObjects4.length = 0;
gdjs.lvlSelectCode.GDScoreObjects1.length = 0;
gdjs.lvlSelectCode.GDScoreObjects2.length = 0;
gdjs.lvlSelectCode.GDScoreObjects3.length = 0;
gdjs.lvlSelectCode.GDScoreObjects4.length = 0;
gdjs.lvlSelectCode.GDHaramPointObjects1.length = 0;
gdjs.lvlSelectCode.GDHaramPointObjects2.length = 0;
gdjs.lvlSelectCode.GDHaramPointObjects3.length = 0;
gdjs.lvlSelectCode.GDHaramPointObjects4.length = 0;
gdjs.lvlSelectCode.GDExitButtonObjects1.length = 0;
gdjs.lvlSelectCode.GDExitButtonObjects2.length = 0;
gdjs.lvlSelectCode.GDExitButtonObjects3.length = 0;
gdjs.lvlSelectCode.GDExitButtonObjects4.length = 0;
gdjs.lvlSelectCode.GDGroundObjects1.length = 0;
gdjs.lvlSelectCode.GDGroundObjects2.length = 0;
gdjs.lvlSelectCode.GDGroundObjects3.length = 0;
gdjs.lvlSelectCode.GDGroundObjects4.length = 0;
gdjs.lvlSelectCode.GDladderObjects1.length = 0;
gdjs.lvlSelectCode.GDladderObjects2.length = 0;
gdjs.lvlSelectCode.GDladderObjects3.length = 0;
gdjs.lvlSelectCode.GDladderObjects4.length = 0;
gdjs.lvlSelectCode.GDdirtLeftObjects1.length = 0;
gdjs.lvlSelectCode.GDdirtLeftObjects2.length = 0;
gdjs.lvlSelectCode.GDdirtLeftObjects3.length = 0;
gdjs.lvlSelectCode.GDdirtLeftObjects4.length = 0;
gdjs.lvlSelectCode.GDDoor2Objects1.length = 0;
gdjs.lvlSelectCode.GDDoor2Objects2.length = 0;
gdjs.lvlSelectCode.GDDoor2Objects3.length = 0;
gdjs.lvlSelectCode.GDDoor2Objects4.length = 0;
gdjs.lvlSelectCode.GDtopOfdoorObjects1.length = 0;
gdjs.lvlSelectCode.GDtopOfdoorObjects2.length = 0;
gdjs.lvlSelectCode.GDtopOfdoorObjects3.length = 0;
gdjs.lvlSelectCode.GDtopOfdoorObjects4.length = 0;
gdjs.lvlSelectCode.GDbridgelogsObjects1.length = 0;
gdjs.lvlSelectCode.GDbridgelogsObjects2.length = 0;
gdjs.lvlSelectCode.GDbridgelogsObjects3.length = 0;
gdjs.lvlSelectCode.GDbridgelogsObjects4.length = 0;
gdjs.lvlSelectCode.GDcrookObjects1.length = 0;
gdjs.lvlSelectCode.GDcrookObjects2.length = 0;
gdjs.lvlSelectCode.GDcrookObjects3.length = 0;
gdjs.lvlSelectCode.GDcrookObjects4.length = 0;
gdjs.lvlSelectCode.GDenemyrightObjects1.length = 0;
gdjs.lvlSelectCode.GDenemyrightObjects2.length = 0;
gdjs.lvlSelectCode.GDenemyrightObjects3.length = 0;
gdjs.lvlSelectCode.GDenemyrightObjects4.length = 0;
gdjs.lvlSelectCode.GDenemyLefyObjects1.length = 0;
gdjs.lvlSelectCode.GDenemyLefyObjects2.length = 0;
gdjs.lvlSelectCode.GDenemyLefyObjects3.length = 0;
gdjs.lvlSelectCode.GDenemyLefyObjects4.length = 0;
gdjs.lvlSelectCode.GDNewObject2Objects1.length = 0;
gdjs.lvlSelectCode.GDNewObject2Objects2.length = 0;
gdjs.lvlSelectCode.GDNewObject2Objects3.length = 0;
gdjs.lvlSelectCode.GDNewObject2Objects4.length = 0;
gdjs.lvlSelectCode.GDbackButtonObjects1.length = 0;
gdjs.lvlSelectCode.GDbackButtonObjects2.length = 0;
gdjs.lvlSelectCode.GDbackButtonObjects3.length = 0;
gdjs.lvlSelectCode.GDbackButtonObjects4.length = 0;
gdjs.lvlSelectCode.GDcoinGoldObjects1.length = 0;
gdjs.lvlSelectCode.GDcoinGoldObjects2.length = 0;
gdjs.lvlSelectCode.GDcoinGoldObjects3.length = 0;
gdjs.lvlSelectCode.GDcoinGoldObjects4.length = 0;
gdjs.lvlSelectCode.GDbackgroundObjects1.length = 0;
gdjs.lvlSelectCode.GDbackgroundObjects2.length = 0;
gdjs.lvlSelectCode.GDbackgroundObjects3.length = 0;
gdjs.lvlSelectCode.GDbackgroundObjects4.length = 0;
gdjs.lvlSelectCode.GDgameoverObjects1.length = 0;
gdjs.lvlSelectCode.GDgameoverObjects2.length = 0;
gdjs.lvlSelectCode.GDgameoverObjects3.length = 0;
gdjs.lvlSelectCode.GDgameoverObjects4.length = 0;
gdjs.lvlSelectCode.GDendlessScoreObjects1.length = 0;
gdjs.lvlSelectCode.GDendlessScoreObjects2.length = 0;
gdjs.lvlSelectCode.GDendlessScoreObjects3.length = 0;
gdjs.lvlSelectCode.GDendlessScoreObjects4.length = 0;
gdjs.lvlSelectCode.GDgamestartObjects1.length = 0;
gdjs.lvlSelectCode.GDgamestartObjects2.length = 0;
gdjs.lvlSelectCode.GDgamestartObjects3.length = 0;
gdjs.lvlSelectCode.GDgamestartObjects4.length = 0;
gdjs.lvlSelectCode.GDRestartObjects1.length = 0;
gdjs.lvlSelectCode.GDRestartObjects2.length = 0;
gdjs.lvlSelectCode.GDRestartObjects3.length = 0;
gdjs.lvlSelectCode.GDRestartObjects4.length = 0;
gdjs.lvlSelectCode.GDbridgeObjects1.length = 0;
gdjs.lvlSelectCode.GDbridgeObjects2.length = 0;
gdjs.lvlSelectCode.GDbridgeObjects3.length = 0;
gdjs.lvlSelectCode.GDbridgeObjects4.length = 0;
gdjs.lvlSelectCode.GDL1_951Objects1.length = 0;
gdjs.lvlSelectCode.GDL1_951Objects2.length = 0;
gdjs.lvlSelectCode.GDL1_951Objects3.length = 0;
gdjs.lvlSelectCode.GDL1_951Objects4.length = 0;
gdjs.lvlSelectCode.GDL1_952Objects1.length = 0;
gdjs.lvlSelectCode.GDL1_952Objects2.length = 0;
gdjs.lvlSelectCode.GDL1_952Objects3.length = 0;
gdjs.lvlSelectCode.GDL1_952Objects4.length = 0;
gdjs.lvlSelectCode.GDlvlselect_95textObjects1.length = 0;
gdjs.lvlSelectCode.GDlvlselect_95textObjects2.length = 0;
gdjs.lvlSelectCode.GDlvlselect_95textObjects3.length = 0;
gdjs.lvlSelectCode.GDlvlselect_95textObjects4.length = 0;
gdjs.lvlSelectCode.GDL1_953Objects1.length = 0;
gdjs.lvlSelectCode.GDL1_953Objects2.length = 0;
gdjs.lvlSelectCode.GDL1_953Objects3.length = 0;
gdjs.lvlSelectCode.GDL1_953Objects4.length = 0;
gdjs.lvlSelectCode.GDendlessObjects1.length = 0;
gdjs.lvlSelectCode.GDendlessObjects2.length = 0;
gdjs.lvlSelectCode.GDendlessObjects3.length = 0;
gdjs.lvlSelectCode.GDendlessObjects4.length = 0;
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects1.length = 0;
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects2.length = 0;
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects3.length = 0;
gdjs.lvlSelectCode.GDnewlvlSelect_95textObjects4.length = 0;
gdjs.lvlSelectCode.GDNewObjectObjects1.length = 0;
gdjs.lvlSelectCode.GDNewObjectObjects2.length = 0;
gdjs.lvlSelectCode.GDNewObjectObjects3.length = 0;
gdjs.lvlSelectCode.GDNewObjectObjects4.length = 0;
gdjs.lvlSelectCode.GDNewObject3Objects1.length = 0;
gdjs.lvlSelectCode.GDNewObject3Objects2.length = 0;
gdjs.lvlSelectCode.GDNewObject3Objects3.length = 0;
gdjs.lvlSelectCode.GDNewObject3Objects4.length = 0;

gdjs.lvlSelectCode.eventsList14(runtimeScene);
return;

}

gdjs['lvlSelectCode'] = gdjs.lvlSelectCode;
